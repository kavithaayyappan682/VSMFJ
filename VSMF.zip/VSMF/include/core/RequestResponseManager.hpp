// =====================================================================
//  include/core/RequestResponseManager.hpp
//  Correlated request/response with hard timeouts.
//
//  Edge cases: a response that arrives after its timeout is counted and
//  discarded (never written into freed memory); a duplicate response is
//  ignored; shutdown wakes every waiter with an error instead of leaving
//  threads parked forever; the pending table is bounded.
// =====================================================================
#ifndef VSMF_CORE_REQUESTRESPONSEMANAGER_HPP
#define VSMF_CORE_REQUESTRESPONSEMANAGER_HPP

#include <condition_variable>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>

#include "data/Message.hpp"

namespace vsmf {

class RequestResponseManager {
public:
    using SendFn = std::function<bool(const Message&, std::string&)>;

    RequestResponseManager();
    ~RequestResponseManager();

    void setSender(SendFn fn);
    void setSourceName(const std::string& n) { source_ = n; }

    // `type` is REQUEST for normal traffic and PING for heartbeats; both
    // are correlated the same way (RESPONSE/ERROR resp. PONG complete them).
    bool request(const std::string& destination, const std::string& topic,
                 const std::string& payload, int timeoutMs,
                 Message& out, std::string& err, Priority p = Priority::HIGH,
                 MsgType type = MsgType::REQUEST);

    // Called from the transport reader thread for RESPONSE / ERROR frames.
    // Returns false when the correlation id is unknown (late or bogus).
    bool onResponse(const Message& m);

    void cancelAll(const std::string& reason);

    std::size_t   pending() const;
    std::uint64_t sent()      const { return sent_; }
    std::uint64_t succeeded() const { return ok_; }
    std::uint64_t timedOut()  const { return timeouts_; }
    std::uint64_t failed()    const { return failed_; }
    std::uint64_t late()      const { return late_; }

    static constexpr std::size_t kMaxPending = 1024;   // C++17: implicitly inline

private:
    struct Pending {
        std::mutex              mu;
        std::condition_variable cv;
        bool                    done = false;
        bool                    error = false;
        std::string             err;
        Message                 response;
    };
    using PendingPtr = std::shared_ptr<Pending>;

    mutable std::mutex                     mu_;
    std::map<std::uint64_t, PendingPtr>    pending_;
    SendFn                                 send_;
    std::string                            source_;

    std::uint64_t sent_ = 0, ok_ = 0, timeouts_ = 0, failed_ = 0, late_ = 0;
};

}  // namespace vsmf
#endif
