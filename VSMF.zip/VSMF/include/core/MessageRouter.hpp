// =====================================================================
//  include/core/MessageRouter.hpp
//  Single decision point for every frame that reaches the broker.
// =====================================================================
#ifndef VSMF_CORE_MESSAGEROUTER_HPP
#define VSMF_CORE_MESSAGEROUTER_HPP

#include <atomic>
#include <cstdint>
#include <string>

#include "core/IPCManager.hpp"
#include "core/PubSubManager.hpp"
#include "core/ServiceRegistry.hpp"
#include "data/Message.hpp"

namespace vsmf {

class LoggerService;
class PerformanceMonitor;

class MessageRouter {
public:
    MessageRouter(IPCManager& ipc, PubSubManager& ps, ServiceRegistry& reg);

    void setLogger(LoggerService* lg) { logger_ = lg; }
    void setPerf(PerformanceMonitor* pm) { perf_ = pm; }

    void route(const Message& m);

    std::uint64_t routed()    const { return routed_.load(std::memory_order_relaxed); }
    std::uint64_t delivered() const { return delivered_.load(std::memory_order_relaxed); }
    std::uint64_t unrouted()  const { return unrouted_.load(std::memory_order_relaxed); }
    std::uint64_t failed()    const { return failed_.load(std::memory_order_relaxed); }

private:
    void routePublish(const Message& m);
    void routeDirect(const Message& m);
    void sendError(const Message& req, const std::string& reason);

    IPCManager&        ipc_;
    PubSubManager&     ps_;
    ServiceRegistry&   reg_;
    LoggerService*     logger_ = nullptr;
    PerformanceMonitor* perf_ = nullptr;

    std::atomic<std::uint64_t> routed_, delivered_, unrouted_, failed_;
};

}  // namespace vsmf
#endif
