// =====================================================================
//  include/core/CommunicationManager.hpp
//  Facade that wires transport + routing + pub/sub together, and hands
//  each service an Endpoint: its own UDS connection to the broker.
// =====================================================================
#ifndef VSMF_CORE_COMMUNICATIONMANAGER_HPP
#define VSMF_CORE_COMMUNICATIONMANAGER_HPP

#include <atomic>
#include <condition_variable>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "core/IPCManager.hpp"
#include "core/MessageRouter.hpp"
#include "core/PubSubManager.hpp"
#include "core/RequestResponseManager.hpp"
#include "core/ServiceRegistry.hpp"
#include "support/ConfigManager.hpp"

namespace vsmf {

class LoggerService;
class PerformanceMonitor;
class ThreadPool;
class CommunicationManager;

// ---------------------------------------------------------------------
// One attached participant. Owns its socket, its pending-request table,
// and answers PING automatically so health monitoring works for free.
// ---------------------------------------------------------------------
class Endpoint {
public:
    using Handler = std::function<void(const Message&)>;

    Endpoint(const std::string& name, CommunicationManager& cm);
    ~Endpoint();
    Endpoint(const Endpoint&) = delete;
    Endpoint& operator=(const Endpoint&) = delete;

    bool open(std::string& err);
    void close();
    bool isOpen() const { return client_.connected(); }

    void setHandler(Handler h);

    bool subscribe(const std::string& topic, std::string& err);
    bool unsubscribe(const std::string& topic);

    bool publish(const std::string& topic, const std::string& payload,
                 Priority p, std::string& err);
    bool request(const std::string& destination, const std::string& topic,
                 const std::string& payload, int timeoutMs, Message& out, std::string& err);
    bool respond(const Message& req, const std::string& payload, std::string& err);
    bool respondError(const Message& req, const std::string& reason, std::string& err);

    // Heartbeat probe: PING out, PONG back, correlated and timed out like
    // any other request. Used by HealthMonitor.
    bool ping(const std::string& destination, int timeoutMs, std::string& err);

    const std::string&      name() const { return name_; }
    RequestResponseManager& rr() { return rr_; }

    std::size_t requestQueueDepth() const;

private:
    void onFrame(const Message& m);
    void requestWorker();
    void dispatch(const Message& m);

    std::string            name_;
    CommunicationManager&  cm_;
    IPCClient              client_;
    RequestResponseManager rr_;
    Handler                handler_;
    mutable std::mutex     handlerMu_;

    // Inbound REQUESTs run on this dedicated serial thread, never on the
    // reader thread and never on the shared pool. That is what makes a
    // nested request (handler A calls service B) safe: the reader thread
    // stays free to deliver B's response back to A.
    std::atomic<bool>       reqRunning_;
    std::thread             reqTh_;
    mutable std::mutex      reqMu_;
    std::condition_variable reqCv_;
    std::deque<Message>     reqQ_;
    static const std::size_t kMaxRequestQueue = 256;
};
using EndpointPtr = std::shared_ptr<Endpoint>;

// ---------------------------------------------------------------------
class CommunicationManager {
public:
    explicit CommunicationManager(ServiceRegistry& reg);
    ~CommunicationManager();

    // The logger, performance monitor and thread pool are observed, not
    // owned. Each must outlive this CommunicationManager, because stop()
    // logs and counts while tearing the transport down. In main.cpp they
    // are declared earlier than the manager for exactly that reason.
    void setLogger(LoggerService* lg);
    void setPerf(PerformanceMonitor* pm);
    void setThreadPool(ThreadPool* tp) { pool_ = tp; }

    bool start(const Config& cfg, std::string& err);
    void stop();
    bool isRunning() const { return ipc_.isRunning(); }

    // Creates and connects an endpoint. Fails cleanly if the broker is
    // down or the name is already attached.
    EndpointPtr createEndpoint(const std::string& name, std::string& err);
    void        destroyEndpoint(const std::string& name);

    IPCManager&        ipc()      { return ipc_; }
    MessageRouter&     router()   { return router_; }
    PubSubManager&     pubsub()   { return pubsub_; }
    ServiceRegistry&   registry()  { return reg_; }
    LoggerService*     logger()   { return logger_; }
    PerformanceMonitor* perf()    { return perf_; }
    ThreadPool*        pool()     { return pool_; }
    const Config&      config() const { return cfg_; }

private:
    ServiceRegistry&    reg_;
    PubSubManager       pubsub_;
    IPCManager          ipc_;
    MessageRouter       router_;
    Config              cfg_;
    LoggerService*      logger_ = nullptr;
    PerformanceMonitor* perf_ = nullptr;
    ThreadPool*         pool_ = nullptr;

    std::mutex                          epMu_;
    std::map<std::string, EndpointPtr>  endpoints_;
};

}  // namespace vsmf
#endif
