// =====================================================================
//  include/core/PubSubManager.hpp
//  Topic -> subscriber-endpoint table with prefix wildcards ("vehicle.*").
//
//  The subscriber list is always *copied* out before delivery, so a
//  service unsubscribing from inside its own callback cannot invalidate
//  the iterator the router is walking, and no lock is held while a
//  message is delivered (that would be a deadlock waiting to happen).
// =====================================================================
#ifndef VSMF_CORE_PUBSUBMANAGER_HPP
#define VSMF_CORE_PUBSUBMANAGER_HPP

#include <cstdint>
#include <map>
#include <mutex>
#include <set>
#include <string>
#include <vector>

#include "common/Types.hpp"

namespace vsmf {

class PubSubManager {
public:
    // Idempotent: subscribing twice is not an error and does not duplicate
    // delivery. Rejects empty/over-long topics and endpoints.
    bool subscribe(const std::string& topic, const std::string& endpoint, std::string& err);
    bool unsubscribe(const std::string& topic, const std::string& endpoint);
    std::size_t unsubscribeAll(const std::string& endpoint);   // service shutdown

    // Matching subscribers for a concrete topic, wildcards resolved,
    // de-duplicated. Returns a copy by design.
    std::vector<std::string> subscribers(const std::string& topic) const;

    bool                     isSubscribed(const std::string& topic, const std::string& endpoint) const;
    std::vector<std::string> topics() const;
    std::size_t              topicCount() const;
    std::size_t              subscriptionCount() const;
    void                     clear();

    static bool topicMatches(const std::string& pattern, const std::string& topic);

private:
    mutable std::mutex                            mu_;
    std::map<std::string, std::set<std::string> > exact_;
    std::map<std::string, std::set<std::string> > wild_;   // pattern ends in '*'
};

}  // namespace vsmf
#endif
