// =====================================================================
//  include/core/DiscoveryManager.hpp
//  Lookup layer over ServiceRegistry. A service that is registered but
//  not RUNNING is deliberately not "discoverable" for traffic.
// =====================================================================
#ifndef VSMF_CORE_DISCOVERYMANAGER_HPP
#define VSMF_CORE_DISCOVERYMANAGER_HPP

#include <string>
#include <vector>

#include "core/ServiceRegistry.hpp"

namespace vsmf {

class DiscoveryManager {
public:
    explicit DiscoveryManager(ServiceRegistry& reg) : reg_(reg) {}

    // Exact lookup. Returns false when unknown or not usable.
    bool discover(const std::string& name, ServiceInfo& out, std::string& err) const;

    // Ignores state: used by the console `discover` command so an
    // operator can see that a service exists but is STOPPED.
    bool lookup(const std::string& name, ServiceInfo& out) const;

    std::vector<ServiceInfo> discoverByTopic(const std::string& topic) const;
    std::vector<ServiceInfo> discoverByKind(ServiceKind k) const;
    std::vector<std::string> available() const;   // RUNNING services only

    // Blocks (polling) until `name` is RUNNING or the timeout expires.
    bool waitFor(const std::string& name, int timeoutMs) const;

private:
    ServiceRegistry& reg_;
};

}  // namespace vsmf
#endif
