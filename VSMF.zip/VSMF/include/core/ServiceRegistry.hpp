// =====================================================================
//  include/core/ServiceRegistry.hpp
//  The authoritative table of who exists in this vehicle.
// =====================================================================
#ifndef VSMF_CORE_SERVICEREGISTRY_HPP
#define VSMF_CORE_SERVICEREGISTRY_HPP

#include <cstdint>
#include <map>
#include <mutex>
#include <string>
#include <vector>

#include "common/Types.hpp"

namespace vsmf {

enum class ServiceKind : std::uint8_t { Producer = 0, Consumer, Support, Core };
const char* toString(ServiceKind k) noexcept;

struct ServiceInfo {
    std::string              name;
    std::string              endpoint;       // UDS endpoint name
    ServiceKind              kind = ServiceKind::Producer;
    std::vector<std::string> publishes;
    std::vector<std::string> subscribes;
    std::string              version = "1.0";
    ServiceState             state = ServiceState::CREATED;
    HealthState              health = HealthState::UNKNOWN;
    std::uint64_t            registeredAt = 0;    // wall ns
    std::uint64_t            lastHeartbeat = 0;   // steady ns
    std::uint32_t            missedHeartbeats = 0;

    std::string toString() const;
};

class ServiceRegistry {
public:
    // Rejects empty names, over-long names and duplicates.
    bool registerService(const ServiceInfo& info, std::string& err);
    bool unregisterService(const std::string& name);

    bool contains(const std::string& name) const;
    bool get(const std::string& name, ServiceInfo& out) const;

    bool setState(const std::string& name, ServiceState s);
    bool setHealth(const std::string& name, HealthState h);
    bool touchHeartbeat(const std::string& name, std::uint64_t steadyNs);
    bool setMissedHeartbeats(const std::string& name, std::uint32_t n);

    std::vector<ServiceInfo>  list() const;               // snapshot copy
    std::vector<std::string>  names() const;
    std::vector<ServiceInfo>  byKind(ServiceKind k) const;
    std::vector<ServiceInfo>  publishersOf(const std::string& topic) const;
    std::vector<ServiceInfo>  subscribersOf(const std::string& topic) const;
    std::size_t               size() const;
    void                      clear();

private:
    mutable std::mutex                  mu_;
    std::map<std::string, ServiceInfo>  map_;
};

}  // namespace vsmf
#endif
