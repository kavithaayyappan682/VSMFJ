// =====================================================================
//  include/core/IPCManager.hpp
//  Unix Domain Socket transport: a broker (IPCManager) that every
//  endpoint (IPCClient) attaches to.
//
//  Edge cases handled here, because this is where they live:
//    * stale socket file from a crashed run  -> probed, then unlinked
//    * a second instance on the same socket  -> refused with a clear error
//    * sun_path is 108 bytes                 -> path length validated
//    * SIGPIPE on a vanished peer            -> ignored, EPIPE handled
//    * short read / short write              -> full-transfer loops
//    * EINTR anywhere                        -> retried
//    * hostile length prefix                 -> capped at kMaxFrameBytes
//    * blocking write to a wedged peer       -> bounded by poll timeout
//    * reader thread outliving the object    -> joined in stop()/dtor
// =====================================================================
#ifndef VSMF_CORE_IPCMANAGER_HPP
#define VSMF_CORE_IPCMANAGER_HPP

#include <atomic>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "data/Message.hpp"

namespace vsmf {

class LoggerService;

// ---------------------------------------------------------------------
class IPCManager {
public:
    using InboundHandler = std::function<void(const Message&)>;

    IPCManager();
    ~IPCManager();
    IPCManager(const IPCManager&) = delete;
    IPCManager& operator=(const IPCManager&) = delete;

    void setLogger(LoggerService* lg) { logger_ = lg; }
    void setInboundHandler(InboundHandler h);

    bool start(const std::string& socketPath, std::string& err);
    void stop();
    bool isRunning() const { return running_.load(std::memory_order_acquire); }

    // Deliver to a named endpoint. false + err when the endpoint is not
    // attached or the write failed (the connection is then dropped).
    bool deliver(const std::string& endpoint, const Message& m, std::string& err);

    bool                     hasEndpoint(const std::string& name) const;
    std::vector<std::string> endpointNames() const;
    std::size_t              connectionCount() const;

    std::uint64_t framesIn()      const { return framesIn_.load(std::memory_order_relaxed); }
    std::uint64_t framesOut()     const { return framesOut_.load(std::memory_order_relaxed); }
    std::uint64_t framesDropped() const { return framesDropped_.load(std::memory_order_relaxed); }
    std::uint64_t framesBad()     const { return framesBad_.load(std::memory_order_relaxed); }

    const std::string& socketPath() const { return socketPath_; }

private:
    struct Conn {
        int              fd = -1;
        std::string      name;          // set by the HELLO frame
        std::mutex       writeMu;
        std::atomic<bool> alive;
        std::thread      th;
        Conn() : alive(true) {}
    };
    using ConnPtr = std::shared_ptr<Conn>;

    void acceptLoop();
    void readerLoop(ConnPtr c);
    void reap(bool joinAll);
    void dropConn(const ConnPtr& c);
    void log(LogLevel lvl, const std::string& msg);

    std::atomic<bool>       running_;
    int                     listenFd_ = -1;
    std::string             socketPath_;
    std::thread             acceptTh_;
    mutable std::mutex      connMu_;
    std::vector<ConnPtr>    conns_;
    InboundHandler          inbound_;
    std::mutex              handlerMu_;
    LoggerService*          logger_ = nullptr;

    std::atomic<std::uint64_t> framesIn_;
    std::atomic<std::uint64_t> framesOut_;
    std::atomic<std::uint64_t> framesDropped_;
    std::atomic<std::uint64_t> framesBad_;
};

// ---------------------------------------------------------------------
class IPCClient {
public:
    using Handler = std::function<void(const Message&)>;

    IPCClient();
    ~IPCClient();
    IPCClient(const IPCClient&) = delete;
    IPCClient& operator=(const IPCClient&) = delete;

    void setHandler(Handler h);
    bool connect(const std::string& socketPath, const std::string& endpointName,
                 int timeoutMs, std::string& err);
    void disconnect();
    bool connected() const { return connected_.load(std::memory_order_acquire); }
    bool send(const Message& m, std::string& err);

    // Blocking single-shot receive, used by the console client which has
    // no reader thread of its own.
    bool receive(Message& out, int timeoutMs, std::string& err);

    const std::string& name() const { return name_; }

private:
    void readerLoop();

    int                 fd_ = -1;
    std::string         name_;
    std::atomic<bool>   connected_;
    std::atomic<bool>   running_;
    std::thread         th_;
    std::mutex          writeMu_;
    std::mutex          handlerMu_;
    Handler             handler_;
};

// Shared framing primitives (also exercised directly by the unit tests).
enum class FrameStatus { Ok, Timeout, Closed, Error };
FrameStatus readFrame(int fd, std::vector<std::uint8_t>& buf, int timeoutMs, std::string& err);
bool        writeFrame(int fd, const Message& m, std::mutex& wmu, std::string& err);

}  // namespace vsmf
#endif
