// =====================================================================
//  include/common/IService.hpp
//  The one interface every producer, consumer and support service
//  implements. LifecycleManager drives services only through this.
// =====================================================================
#ifndef VSMF_COMMON_ISERVICE_HPP
#define VSMF_COMMON_ISERVICE_HPP

#include <string>

#include "common/Types.hpp"

namespace vsmf {

class IService {
public:
    virtual ~IService() {}

    virtual const std::string& name() const = 0;

    // Must be idempotent and must not throw. Returning false puts the
    // service into FAILED rather than taking the process down.
    virtual bool start() = 0;
    virtual void stop() = 0;

    // Optional: default to a no-op so simple services stay small.
    virtual void pause()  {}
    virtual void resume() {}

    virtual ServiceState state() const = 0;
    virtual bool         isRunning() const { return state() == ServiceState::RUNNING; }
};

}  // namespace vsmf
#endif
