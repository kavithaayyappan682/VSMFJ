// =====================================================================
//  include/common/Utils.hpp : POSIX + string helpers.
//  Every syscall wrapper here is EINTR-safe and partial-transfer-safe.
// =====================================================================
#ifndef VSMF_COMMON_UTILS_HPP
#define VSMF_COMMON_UTILS_HPP

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace vsmf {
namespace util {

// --- process / signal -------------------------------------------------
void ignoreSigPipe() noexcept;   // so a dead peer yields EPIPE, not SIGPIPE

// --- fd helpers -------------------------------------------------------
bool setCloExec(int fd) noexcept;
bool setNonBlocking(int fd, bool on) noexcept;
void closeQuiet(int& fd) noexcept;   // close() retrying EINTR, sets fd = -1

// Transfer exactly n bytes. Retries EINTR and short reads/writes.
// Returns: n on success, 0 on clean EOF (read only), -1 on error (errno set).
std::ptrdiff_t readAll(int fd, void* buf, std::size_t n) noexcept;
std::ptrdiff_t writeAll(int fd, const void* buf, std::size_t n) noexcept;

// poll() one fd for readability with timeout. 1 = ready, 0 = timeout,
// -1 = error (errno set). EINTR is retried with the remaining budget.
int waitReadable(int fd, int timeoutMs) noexcept;
int waitWritable(int fd, int timeoutMs) noexcept;

// --- time -------------------------------------------------------------
std::uint64_t wallNs() noexcept;    // CLOCK_REALTIME, for timestamps
std::uint64_t steadyNs() noexcept;  // CLOCK_MONOTONIC, for durations
std::string   formatWallTime(std::uint64_t ns);  // "YYYY-MM-DD HH:MM:SS.mmm"

// --- filesystem (no <filesystem>: GCC 7.5 ships it as experimental) ---
bool makeDirs(const std::string& path, std::string& err);
bool fileExists(const std::string& path) noexcept;
long fileSize(const std::string& path) noexcept;      // -1 if unknown
std::int64_t fileMTime(const std::string& path) noexcept;  // -1 if unknown
std::string  dirName(const std::string& path);
std::string  joinPath(const std::string& a, const std::string& b);

// --- strings ----------------------------------------------------------
std::string trim(const std::string& s);
std::vector<std::string> splitWhitespace(const std::string& s, std::size_t maxTokens = 0);
bool parseInt(const std::string& s, long long& out) noexcept;
bool parseDouble(const std::string& s, double& out) noexcept;
std::string toLower(std::string s);
std::string sanitize(const std::string& s, std::size_t maxLen);  // strip ctrl chars

template <typename T>
T clampValue(T v, T lo, T hi) { return v < lo ? lo : (v > hi ? hi : v); }

// --- process metrics --------------------------------------------------
bool readProcCpuJiffies(std::uint64_t& jiffies) noexcept;  // utime+stime
bool readProcRssKb(std::uint64_t& rssKb) noexcept;
long clockTicksPerSec() noexcept;

}  // namespace util
}  // namespace vsmf
#endif
