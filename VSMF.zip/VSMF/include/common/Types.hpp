// =====================================================================
//  VSMF - Vehicle Service Management Framework
//  include/common/Types.hpp : framework-wide enums, limits and helpers
// =====================================================================
#ifndef VSMF_COMMON_TYPES_HPP
#define VSMF_COMMON_TYPES_HPP

#include <cstdint>
#include <string>

namespace vsmf {

// ---------------------------------------------------------------------
// Hard limits. Every one of these is enforced somewhere; they exist so a
// malformed/hostile peer cannot make the framework allocate without bound.
// ---------------------------------------------------------------------
namespace limits {
constexpr std::uint32_t kMaxFrameBytes    = 1u << 20;   // 1 MiB wire frame
constexpr std::uint32_t kMaxStringBytes   = 64u * 1024; // per string field
constexpr std::size_t   kMaxEndpointName  = 64;
constexpr std::size_t   kMaxTopicName     = 128;
constexpr std::size_t   kMinThreads       = 1;
constexpr std::size_t   kMaxThreads       = 64;
constexpr std::size_t   kMaxQueueDepth    = 65536;
constexpr std::uint16_t kWireVersion      = 1;
}  // namespace limits

// ---------------------------------------------------------------------
enum class LogLevel : std::uint8_t { TRACE = 0, DEBUG = 1, INFO = 2, WARN = 3, ERROR = 4, FATAL = 5 };

const char* toString(LogLevel l) noexcept;
bool        parseLogLevel(const std::string& s, LogLevel& out) noexcept;

// ---------------------------------------------------------------------
// Message classes carried on the wire.
// ---------------------------------------------------------------------
enum class MsgType : std::uint8_t {
    HELLO    = 0,  // endpoint -> broker, first frame, carries endpoint name
    PUBLISH  = 1,
    REQUEST  = 2,
    RESPONSE = 3,
    PING     = 4,
    PONG     = 5,
    ERROR    = 6,
    BYE      = 7
};
const char* toString(MsgType t) noexcept;
bool        isValidMsgType(std::uint8_t raw) noexcept;

// ---------------------------------------------------------------------
enum class Priority : std::uint8_t { LOW = 0, NORMAL = 1, HIGH = 2, CRITICAL = 3 };
const char* toString(Priority p) noexcept;
bool        isValidPriority(std::uint8_t raw) noexcept;

// ---------------------------------------------------------------------
// Lifecycle state machine. Transitions are validated centrally in
// LifecycleManager::isLegalTransition().
// ---------------------------------------------------------------------
enum class ServiceState : std::uint8_t {
    CREATED = 0,
    STARTING,
    RUNNING,
    PAUSED,
    STOPPING,
    STOPPED,
    FAILED
};
const char* toString(ServiceState s) noexcept;

enum class HealthState : std::uint8_t { UNKNOWN = 0, HEALTHY, DEGRADED, UNHEALTHY };
const char* toString(HealthState h) noexcept;

// ---------------------------------------------------------------------
// Canonical topic names. Kept in one place so a typo is a link error and
// not a message that silently goes nowhere.
// ---------------------------------------------------------------------
namespace topics {
constexpr const char* kSpeed       = "vehicle.speed";
constexpr const char* kEngine      = "vehicle.engine";
constexpr const char* kBattery     = "vehicle.battery";
constexpr const char* kGps         = "vehicle.gps";
constexpr const char* kAlert       = "vehicle.alert";
constexpr const char* kHealth      = "system.health";
constexpr const char* kPerformance = "system.performance";
constexpr const char* kControl     = "system.control";
}  // namespace topics

namespace endpoints {
constexpr const char* kBroker  = "middleware";
constexpr const char* kControl = "ControlService";
}  // namespace endpoints

}  // namespace vsmf
#endif  // VSMF_COMMON_TYPES_HPP
