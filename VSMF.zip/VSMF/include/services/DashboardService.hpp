#ifndef VSMF_SERVICES_DASHBOARD_HPP
#define VSMF_SERVICES_DASHBOARD_HPP

#include <atomic>
#include <mutex>
#include <string>

#include "services/ServiceBase.hpp"

namespace vsmf {

// Everything Terminal 1 draws. Kept as one small struct copied under a
// mutex: the render thread never holds a lock while writing to stdout.
struct DashboardData {
    double        speed = 0.0;
    double        rpm = 0.0;
    double        temperature = 0.0;
    double        battery = 0.0;
    bool          gpsFix = false;
    std::uint32_t satellites = 0;
    double        latitude = 0.0;
    double        longitude = 0.0;
    std::string   health = "UNKNOWN";
    std::string   lastAlert;
    std::uint64_t lastAlertAt = 0;
    double        latencyUs = 0.0;
    double        throughput = 0.0;
    std::uint64_t updates = 0;
    std::uint64_t lastUpdateNs = 0;
};

// Consumer: subscribes to every vehicle topic plus health and
// performance, and keeps the newest picture for the renderer.
class DashboardService : public ServiceBase {
public:
    explicit DashboardService(CommunicationManager& cm);

    DashboardData data() const;
    bool          consumeDirty();       // true once per change, then resets
    void          setPerfLine(double latencyUs, double throughput);

protected:
    void onMessage(const Message& m) override;

private:
    mutable std::mutex mu_;
    DashboardData      d_;
    std::atomic<bool>  dirty_;
};

}  // namespace vsmf
#endif
