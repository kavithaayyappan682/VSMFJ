#ifndef VSMF_SERVICES_SPEEDSENSOR_HPP
#define VSMF_SERVICES_SPEEDSENSOR_HPP

#include "data/DataGenerator.hpp"
#include "services/ServiceBase.hpp"

namespace vsmf {

// Producer: samples the vehicle model and publishes vehicle.speed.
// Also answers a REQUEST with the latest reading, so the topic is not
// the only way to get at the value.
class SpeedSensorService : public ServiceBase {
public:
    SpeedSensorService(CommunicationManager& cm, DataGenerator& gen, int intervalMs);
    std::uint64_t published() const { return count_; }

protected:
    bool onStart(std::string& err) override;
    void onTick() override;
    void onMessage(const Message& m) override;

private:
    DataGenerator&             gen_;
    std::atomic<std::uint64_t> count_;
};

}  // namespace vsmf
#endif
