#ifndef VSMF_SERVICES_GPS_HPP
#define VSMF_SERVICES_GPS_HPP

#include "data/DataGenerator.hpp"
#include "services/ServiceBase.hpp"

namespace vsmf {

// Producer: publishes vehicle.gps. Reports loss of fix as a WARN rather
// than publishing a position it does not have.
class GPSService : public ServiceBase {
public:
    GPSService(CommunicationManager& cm, DataGenerator& gen, int intervalMs);
    bool hasFix() const { return fix_.load(std::memory_order_relaxed); }

protected:
    void onTick() override;
    void onMessage(const Message& m) override;

private:
    DataGenerator&    gen_;
    std::atomic<bool> fix_;
};

}  // namespace vsmf
#endif
