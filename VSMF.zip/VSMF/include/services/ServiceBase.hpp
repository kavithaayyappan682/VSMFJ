// =====================================================================
//  include/services/ServiceBase.hpp
//  Shared machinery for every VSMF service: registration, endpoint,
//  subscriptions, an optional periodic worker, and a guarded lifecycle
//  state machine. Subclasses override the four on*() hooks.
// =====================================================================
#ifndef VSMF_SERVICES_SERVICEBASE_HPP
#define VSMF_SERVICES_SERVICEBASE_HPP

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "common/IService.hpp"
#include "core/CommunicationManager.hpp"
#include "support/LoggerService.hpp"

namespace vsmf {

class ServiceBase : public IService {
public:
    ServiceBase(const std::string& name, ServiceKind kind, CommunicationManager& cm);
    ~ServiceBase() override;

    const std::string& name() const override { return name_; }
    bool  start() override;
    void  stop() override;
    void  pause() override;
    void  resume() override;
    ServiceState state() const override { return static_cast<ServiceState>(state_.load(std::memory_order_acquire)); }

    const std::string& lastError() const { return lastError_; }

protected:
    // Hooks. onStart may fail (-> FAILED); the others must not throw
    // (anything that escapes is caught and logged).
    virtual bool onStart(std::string& err) { (void)err; return true; }
    virtual void onStop() {}
    virtual void onMessage(const Message& m) { (void)m; }
    virtual void onTick() {}

    void setTickInterval(int ms) { tickMs_ = ms; }
    void addPublishedTopic(const std::string& t) { publishes_.push_back(t); }
    void addSubscription(const std::string& t)   { subscribes_.push_back(t); }

    bool publish(const std::string& topic, const std::string& payload,
                 Priority p = Priority::NORMAL);
    void log(LogLevel lvl, const std::string& msg);
    void logTo(LogChannel ch, LogLevel lvl, const std::string& msg);

    CommunicationManager& cm() { return cm_; }
    EndpointPtr           endpoint() { return ep_; }
    double                secondsSinceLastTick() const { return lastDt_; }

private:
    void   workerLoop();
    void   setState(ServiceState s);

    std::string              name_;
    ServiceKind              kind_;
    CommunicationManager&    cm_;
    EndpointPtr              ep_;
    std::vector<std::string> publishes_;
    std::vector<std::string> subscribes_;

    std::atomic<std::uint8_t> state_;
    std::atomic<bool>         running_;
    std::atomic<bool>         paused_;
    std::thread               th_;
    std::mutex                cvMu_;
    std::condition_variable   cv_;
    std::mutex                lifecycleMu_;   // serialises start/stop/pause
    int                       tickMs_ = 0;
    double                    lastDt_ = 0.0;
    std::string               lastError_;
};

}  // namespace vsmf
#endif
