#ifndef VSMF_SERVICES_VEHICLECONTROL_HPP
#define VSMF_SERVICES_VEHICLECONTROL_HPP

#include <mutex>
#include <string>

#include "core/DiscoveryManager.hpp"
#include "services/ServiceBase.hpp"
#include "support/ConfigManager.hpp"

namespace vsmf {

// Consumer + requester: discovers BatteryService, asks it for the pack
// state over request/response, and decides whether to derate.
class VehicleControlService : public ServiceBase {
public:
    VehicleControlService(CommunicationManager& cm, DiscoveryManager& disc,
                          ConfigManager& cfg, int intervalMs);

    std::string   status() const;
    bool          limpMode() const { return limp_.load(std::memory_order_relaxed); }
    std::uint64_t requests() const { return requests_.load(std::memory_order_relaxed); }
    std::uint64_t failures() const { return failures_.load(std::memory_order_relaxed); }

protected:
    void onTick() override;
    void onMessage(const Message& m) override;

private:
    DiscoveryManager&          disc_;
    ConfigManager&             cfg_;
    std::atomic<bool>          limp_;
    std::atomic<std::uint64_t> requests_, failures_;
    mutable std::mutex         mu_;
    std::string                lastDecision_ = "initialising";
    double                     lastSpeed_ = 0.0;
    double                     lastBattery_ = 0.0;
};

}  // namespace vsmf
#endif
