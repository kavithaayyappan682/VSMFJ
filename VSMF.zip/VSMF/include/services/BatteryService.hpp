#ifndef VSMF_SERVICES_BATTERY_HPP
#define VSMF_SERVICES_BATTERY_HPP

#include "data/DataGenerator.hpp"
#include "services/ServiceBase.hpp"

namespace vsmf {

// Producer + responder: publishes vehicle.battery and serves the
// request/response leg used by VehicleControlService and the console.
class BatteryService : public ServiceBase {
public:
    BatteryService(CommunicationManager& cm, DataGenerator& gen, int intervalMs);
    std::uint64_t served() const { return served_; }

protected:
    void onTick() override;
    void onMessage(const Message& m) override;

private:
    DataGenerator&             gen_;
    std::atomic<std::uint64_t> served_;
};

}  // namespace vsmf
#endif
