#ifndef VSMF_SERVICES_ENGINESENSOR_HPP
#define VSMF_SERVICES_ENGINESENSOR_HPP

#include "data/DataGenerator.hpp"
#include "services/ServiceBase.hpp"

namespace vsmf {

// Producer: publishes vehicle.engine (rpm + coolant temperature).
class EngineSensorService : public ServiceBase {
public:
    EngineSensorService(CommunicationManager& cm, DataGenerator& gen, int intervalMs);
    std::uint64_t published() const { return count_; }

protected:
    void onTick() override;
    void onMessage(const Message& m) override;

private:
    DataGenerator&             gen_;
    std::atomic<std::uint64_t> count_;
};

}  // namespace vsmf
#endif
