#ifndef VSMF_SERVICES_DIAGNOSTIC_HPP
#define VSMF_SERVICES_DIAGNOSTIC_HPP

#include <deque>
#include <mutex>
#include <string>
#include <vector>

#include "services/ServiceBase.hpp"
#include "support/ConfigManager.hpp"

namespace vsmf {

struct Alert {
    std::uint64_t ts = 0;
    std::string   severity;
    std::string   topic;
    std::string   text;
};

// Consumer: evaluates telemetry against the *live* ConfigManager values
// (never hardcoded constants) and raises alerts. Alerts are edge
// triggered with hysteresis so a value hovering on a threshold does not
// spam the bus.
class DiagnosticService : public ServiceBase {
public:
    DiagnosticService(CommunicationManager& cm, ConfigManager& cfg);

    std::vector<Alert> recentAlerts(std::size_t n) const;
    std::uint64_t      alertCount() const { return alerts_.load(std::memory_order_relaxed); }
    std::string        summary() const;

protected:
    void onMessage(const Message& m) override;

private:
    void check(const std::string& topic, const std::string& payload);
    void raise(const std::string& severity, const std::string& topic, const std::string& text);

    ConfigManager&             cfg_;
    std::atomic<std::uint64_t> alerts_;
    mutable std::mutex         mu_;
    std::deque<Alert>          recent_;
    bool                       overSpeed_ = false;
    bool                       overTemp_ = false;
    bool                       lowBattery_ = false;
    bool                       overRpm_ = false;
    bool                       noFix_ = false;
    static const std::size_t   kKeep = 64;
};

}  // namespace vsmf
#endif
