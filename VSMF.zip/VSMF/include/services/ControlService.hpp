// =====================================================================
//  include/services/ControlService.hpp
//  Server side of Terminal 2. Every console command arrives as a
//  REQUEST over the same Unix domain socket the services use, is
//  executed here, and the text result goes back as a RESPONSE.
// =====================================================================
#ifndef VSMF_SERVICES_CONTROLSERVICE_HPP
#define VSMF_SERVICES_CONTROLSERVICE_HPP

#include <atomic>
#include <string>

#include "core/DiscoveryManager.hpp"
#include "data/DataGenerator.hpp"
#include "services/DashboardService.hpp"
#include "services/DiagnosticService.hpp"
#include "services/ServiceBase.hpp"
#include "services/VehicleControlService.hpp"
#include "support/ConfigManager.hpp"
#include "support/HealthMonitor.hpp"
#include "support/LifecycleManager.hpp"
#include "support/PerformanceMonitor.hpp"
#include "support/ThreadPool.hpp"

namespace vsmf {

// Every collaborator the console can reach. Pointers, not references,
// so the struct can be assembled incrementally in main().
struct SystemContext {
    ConfigManager*         cfg = nullptr;
    ServiceRegistry*       registry = nullptr;
    DiscoveryManager*      discovery = nullptr;
    CommunicationManager*  comm = nullptr;
    ThreadPool*            pool = nullptr;
    LoggerService*         logger = nullptr;
    PerformanceMonitor*    perf = nullptr;
    HealthMonitor*         health = nullptr;
    LifecycleManager*      lifecycle = nullptr;
    DataGenerator*         generator = nullptr;
    DashboardService*      dashboard = nullptr;
    DiagnosticService*     diagnostics = nullptr;
    VehicleControlService* control = nullptr;
    std::atomic<bool>*     shutdownFlag = nullptr;
};

class ControlService : public ServiceBase {
public:
    ControlService(CommunicationManager& cm, const SystemContext& ctx);

    // Public so the unit tests can drive commands without a socket.
    std::string execute(const std::string& line);

protected:
    void onMessage(const Message& m) override;

private:
    std::string cmdServices() const;
    std::string cmdDiscover(const std::string& name) const;
    std::string cmdPublishSpeed(const std::string& arg);
    std::string cmdBattery();
    std::string cmdDiagnostics() const;
    std::string cmdMetrics() const;
    std::string cmdLogs(const std::vector<std::string>& args) const;
    std::string cmdStatus() const;
    std::string cmdHealth() const;
    std::string cmdConfig() const;
    std::string cmdReload();
    std::string cmdLifecycle(const std::string& verb, const std::string& name);
    static std::string help();

    SystemContext ctx_;
};

}  // namespace vsmf
#endif
