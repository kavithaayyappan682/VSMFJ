// =====================================================================
//  include/support/ThreadPool.hpp
//  Fixed-size pool with a bounded, priority-aware queue.
//
//  Guarantees:
//    * submit() never blocks: it returns false and counts a drop when the
//      queue is full (backpressure is visible, not hidden as latency)
//    * a task that throws cannot kill a worker
//    * stop() is idempotent, joins every worker exactly once, and is safe
//      to call from a task (it will not self-join)
// =====================================================================
#ifndef VSMF_SUPPORT_THREADPOOL_HPP
#define VSMF_SUPPORT_THREADPOOL_HPP

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "common/Types.hpp"

namespace vsmf {

class LoggerService;

class ThreadPool {
public:
    using Task = std::function<void()>;

    ThreadPool();
    ~ThreadPool();
    ThreadPool(const ThreadPool&) = delete;
    ThreadPool& operator=(const ThreadPool&) = delete;

    void setLogger(LoggerService* lg) { logger_ = lg; }

    // threads is clamped to [kMinThreads, kMaxThreads]; capacity to
    // [16, kMaxQueueDepth]. Returns false if already started.
    bool start(std::size_t threads, std::size_t capacity);

    // drain=true finishes queued work first; false discards it.
    void stop(bool drain = true);

    bool submit(Task t, Priority p = Priority::NORMAL);

    bool        isRunning() const { return running_.load(std::memory_order_acquire); }
    std::size_t threadCount() const { return workers_.size(); }
    std::size_t queueDepth() const;
    std::size_t capacity() const { return capacity_; }

    std::uint64_t submitted() const { return submitted_.load(std::memory_order_relaxed); }
    std::uint64_t completed() const { return completed_.load(std::memory_order_relaxed); }
    std::uint64_t dropped()   const { return dropped_.load(std::memory_order_relaxed); }
    std::uint64_t failed()    const { return failed_.load(std::memory_order_relaxed); }
    std::size_t   peakDepth() const;

private:
    struct Item {
        Task          fn;
        Priority      prio;
        std::uint64_t seq;      // keeps FIFO order inside a priority class
    };

    void worker();

    mutable std::mutex      mu_;
    std::condition_variable cv_;
    std::deque<Item>        q_;
    std::vector<std::thread> workers_;
    std::atomic<bool>       running_;
    std::atomic<bool>       drain_;
    std::size_t             capacity_ = 4096;
    std::uint64_t           seq_ = 0;
    std::size_t             peak_ = 0;

    std::atomic<std::uint64_t> submitted_;
    std::atomic<std::uint64_t> completed_;
    std::atomic<std::uint64_t> dropped_;
    std::atomic<std::uint64_t> failed_;
    LoggerService*             logger_ = nullptr;
};

}  // namespace vsmf
#endif
