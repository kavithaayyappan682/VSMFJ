// =====================================================================
//  include/support/HealthMonitor.hpp
//  PING/PONG liveness over the same UDS transport the services use, so
//  a service that answers a heartbeat has really proven its socket, its
//  reader thread and its process are all alive.
// =====================================================================
#ifndef VSMF_SUPPORT_HEALTHMONITOR_HPP
#define VSMF_SUPPORT_HEALTHMONITOR_HPP

#include <atomic>
#include <cstdint>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "core/CommunicationManager.hpp"
#include "core/ServiceRegistry.hpp"
#include "support/ConfigManager.hpp"

namespace vsmf {

class LoggerService;

struct HealthReport {
    HealthState                                  overall = HealthState::UNKNOWN;
    std::size_t                                  healthy = 0;
    std::size_t                                  degraded = 0;
    std::size_t                                  unhealthy = 0;
    std::vector<std::pair<std::string, HealthState> > perService;
    std::uint64_t                                rounds = 0;
    std::string toString() const;
};

class HealthMonitor {
public:
    HealthMonitor(CommunicationManager& cm, ServiceRegistry& reg, ConfigManager& cfg);
    ~HealthMonitor();

    bool start(std::string& err);
    void stop();
    bool isRunning() const { return running_.load(std::memory_order_acquire); }

    HealthReport report() const;
    HealthState  overall() const;

    // One synchronous sweep. Exposed so tests do not have to wait for the
    // heartbeat thread to come round.
    void checkOnce();

    static const char* kEndpointName;

private:
    void loop();

    CommunicationManager& cm_;
    ServiceRegistry&      reg_;
    ConfigManager&        cfg_;
    EndpointPtr           ep_;
    std::atomic<bool>     running_;
    std::thread           th_;

    mutable std::mutex    mu_;
    HealthReport          report_;
};

}  // namespace vsmf
#endif
