// =====================================================================
//  include/support/LoggerService.hpp
//  Asynchronous, bounded, rotating logger.
//
//  Design rule: logging must never block a producer thread and must
//  never be the reason a message is late. When the queue is full we drop
//  and count - and we say so in the file once the pressure passes.
// =====================================================================
#ifndef VSMF_SUPPORT_LOGGERSERVICE_HPP
#define VSMF_SUPPORT_LOGGERSERVICE_HPP

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <fstream>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "common/IService.hpp"

namespace vsmf {

enum class LogChannel : std::uint8_t { Middleware = 0, Performance = 1, Diagnostics = 2, Health = 3 };

class LoggerService : public IService {
public:
    LoggerService();
    ~LoggerService();

    // Creates logDir if needed. Returns false with err on unusable dir.
    bool configure(const std::string& logDir, LogLevel minLevel, long maxBytes,
                   std::size_t queueCapacity, std::string& err);

    void setMinLevel(LogLevel l) { minLevel_.store(static_cast<std::uint8_t>(l), std::memory_order_relaxed); }
    LogLevel minLevel() const { return static_cast<LogLevel>(minLevel_.load(std::memory_order_relaxed)); }
    void setEchoToConsole(bool on) { echo_.store(on, std::memory_order_relaxed); }

    const std::string& name() const override { return name_; }
    bool  start() override;
    void  stop() override;
    ServiceState state() const override { return static_cast<ServiceState>(state_.load(std::memory_order_acquire)); }

    void log(LogLevel lvl, const std::string& source, const std::string& msg);
    void logTo(LogChannel ch, LogLevel lvl, const std::string& source, const std::string& msg);

    void flush();                                     // blocks until drained
    std::uint64_t dropped() const { return dropped_.load(std::memory_order_relaxed); }
    std::uint64_t written() const { return written_.load(std::memory_order_relaxed); }

    // Last `n` lines of a channel, for the `logs` console command.
    std::vector<std::string> tail(LogChannel ch, std::size_t n) const;
    std::string              fileFor(LogChannel ch) const;

private:
    struct Entry {
        LogChannel  ch;
        LogLevel    lvl;
        std::uint64_t ts;
        std::string source;
        std::string msg;
    };

    void   worker();
    void   writeEntry(const Entry& e);
    void   rotateIfNeeded(std::size_t idx);
    bool   openStream(std::size_t idx, std::string& err);

    static const std::size_t kChannels = 4;

    std::string       name_ = "LoggerService";
    std::string       dir_ = "logs";
    long              maxBytes_ = 5L * 1024 * 1024;
    std::size_t       capacity_ = 4096;

    std::atomic<std::uint8_t> state_;
    std::atomic<std::uint8_t> minLevel_;
    std::atomic<bool>         echo_;
    std::atomic<bool>         running_;
    std::atomic<std::uint64_t> dropped_;
    std::atomic<std::uint64_t> written_;

    mutable std::mutex      mu_;
    std::condition_variable cv_;
    std::condition_variable drained_;
    std::deque<Entry>       queue_;
    bool                    inFlight_ = false;   // an entry popped but not yet written
    std::thread             th_;

    mutable std::mutex fileMu_;
    std::ofstream      out_[kChannels];
    long               size_[kChannels];
    std::string        path_[kChannels];
};

}  // namespace vsmf
#endif
