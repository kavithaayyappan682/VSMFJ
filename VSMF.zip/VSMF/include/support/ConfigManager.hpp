// =====================================================================
//  include/support/ConfigManager.hpp
//  Loads config/vsmf_config.json. Never throws and never aborts boot:
//  a missing or corrupt file degrades to documented defaults and the
//  reason is reported back to the caller.
// =====================================================================
#ifndef VSMF_SUPPORT_CONFIGMANAGER_HPP
#define VSMF_SUPPORT_CONFIGMANAGER_HPP

#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

#include "common/Types.hpp"
#include "support/Json.hpp"

namespace vsmf {

struct Config {
    // --- values named by the specification ---------------------------
    double      speedLimit        = 180.0;   // km/h
    double      temperatureLimit  = 100.0;   // degC
    double      batteryLimit      = 15.0;    // %
    int         heartbeatInterval = 2;       // seconds
    std::size_t threadPoolSize    = 4;
    LogLevel    logLevel          = LogLevel::INFO;

    // --- operational values (defaulted, overridable from JSON) -------
    std::string socketPath        = "/tmp/vsmf/vsmf.sock";
    std::string logDir            = "logs";
    int         requestTimeoutMs  = 1000;
    int         publishIntervalMs = 200;
    int         metricsIntervalMs = 2000;
    std::size_t queueCapacity     = 4096;
    long        maxLogBytes       = 5L * 1024 * 1024;
    int         missedHeartbeats  = 3;       // consecutive misses -> UNHEALTHY
    double      rpmLimit          = 6500.0;

    std::string toString() const;
};

class ConfigManager {
public:
    ConfigManager() {}

    // Reads and parses `path`. Returns false (config left at defaults,
    // `err` explaining) if the file is missing or malformed.
    bool load(const std::string& path, std::string& err);

    // Re-reads only if st_mtime moved. Returns true when values changed.
    bool reloadIfChanged(std::string& err);

    // Applies an already-parsed document. Out-of-range values are clamped
    // and recorded in warnings(); wrong-typed values are ignored.
    bool applyJson(const JsonValue& doc, std::string& err);

    Config      get() const;      // thread-safe snapshot copy
    std::string path() const;
    std::vector<std::string> warnings() const;

private:
    mutable std::mutex       mu_;
    Config                   cfg_;
    std::string              path_;
    std::int64_t             mtime_ = -1;
    std::vector<std::string> warnings_;
};

}  // namespace vsmf
#endif
