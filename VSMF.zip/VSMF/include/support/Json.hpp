// =====================================================================
//  include/support/Json.hpp
//  Dependency-free RFC-8259 JSON reader/writer.
//  Ubuntu 18.04 / GCC 7.5 boxes rarely have nlohmann installed, and a
//  middleware must not fail to boot because a header is missing.
// =====================================================================
#ifndef VSMF_SUPPORT_JSON_HPP
#define VSMF_SUPPORT_JSON_HPP

#include <map>
#include <memory>
#include <string>
#include <vector>

namespace vsmf {

class JsonValue {
public:
    enum class Type { Null, Bool, Number, String, Array, Object };

    JsonValue() : type_(Type::Null), bool_(false), num_(0.0) {}

    Type type() const { return type_; }
    bool isNull()   const { return type_ == Type::Null; }
    bool isBool()   const { return type_ == Type::Bool; }
    bool isNumber() const { return type_ == Type::Number; }
    bool isString() const { return type_ == Type::String; }
    bool isArray()  const { return type_ == Type::Array; }
    bool isObject() const { return type_ == Type::Object; }

    static JsonValue makeNull();
    static JsonValue makeBool(bool v);
    static JsonValue makeNumber(double v);
    static JsonValue makeString(const std::string& v);
    static JsonValue makeArray();
    static JsonValue makeObject();

    bool               asBool(bool def = false) const;
    double             asNumber(double def = 0.0) const;
    const std::string& asString() const;                // "" when not a string
    const std::vector<JsonValue>& asArray() const;      // empty when not array

    // Object access. has() is const-safe and never inserts.
    bool has(const std::string& key) const;
    const JsonValue* find(const std::string& key) const;
    void set(const std::string& key, const JsonValue& v);
    void push(const JsonValue& v);
    std::vector<std::string> keys() const;
    std::size_t size() const;

    std::string dump(int indent = 2) const;

    // Parse. Returns false and fills err ("line L col C: msg") on failure.
    static bool parse(const std::string& text, JsonValue& out, std::string& err);
    static bool parseFile(const std::string& path, JsonValue& out, std::string& err);

private:
    Type                               type_;
    bool                               bool_;
    double                             num_;
    std::string                        str_;
    std::vector<JsonValue>             arr_;
    std::map<std::string, JsonValue>   obj_;
    std::vector<std::string>           order_;   // preserve insertion order

    void dumpTo(std::string& out, int indent, int depth) const;
    static void escapeTo(std::string& out, const std::string& s);
};

}  // namespace vsmf
#endif
