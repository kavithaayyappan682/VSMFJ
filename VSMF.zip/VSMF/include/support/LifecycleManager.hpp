// =====================================================================
//  include/support/LifecycleManager.hpp
//  Ordered start-up, reverse-ordered shutdown, and per-service
//  start/stop/pause/resume/restart with transition validation.
// =====================================================================
#ifndef VSMF_SUPPORT_LIFECYCLEMANAGER_HPP
#define VSMF_SUPPORT_LIFECYCLEMANAGER_HPP

#include <mutex>
#include <string>
#include <vector>

#include "common/IService.hpp"
#include "core/ServiceRegistry.hpp"

namespace vsmf {

class LoggerService;

class LifecycleManager {
public:
    explicit LifecycleManager(ServiceRegistry& reg) : reg_(reg) {}

    void setLogger(LoggerService* lg) { logger_ = lg; }

    // Services are started in the order added and stopped in reverse.
    // Ownership stays with the caller.
    bool add(IService* s, std::string& err);

    bool startAll(std::string& err);     // false if any service failed
    void stopAll();

    bool start(const std::string& name, std::string& err);
    bool stop(const std::string& name, std::string& err);
    bool pause(const std::string& name, std::string& err);
    bool resume(const std::string& name, std::string& err);
    bool restart(const std::string& name, std::string& err);

    IService*                find(const std::string& name) const;
    std::vector<std::string> names() const;
    std::size_t              size() const;

    static bool        isLegalTransition(ServiceState from, ServiceState to);
    static const char* transitionError(ServiceState from, ServiceState to);

private:
    IService* findLocked(const std::string& name) const;
    void      log(LogLevel lvl, const std::string& msg);

    mutable std::mutex      mu_;
    std::vector<IService*>  services_;
    ServiceRegistry&        reg_;
    LoggerService*          logger_ = nullptr;
};

}  // namespace vsmf
#endif
