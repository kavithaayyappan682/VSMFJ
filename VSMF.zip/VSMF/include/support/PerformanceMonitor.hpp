// =====================================================================
//  include/support/PerformanceMonitor.hpp
//  Throughput, latency, CPU, RSS, queue depth, drops.
//  All hot-path counters are lock-free; only the latency reservoir takes
//  a mutex, and never on the delivery path for longer than a push_back.
// =====================================================================
#ifndef VSMF_SUPPORT_PERFORMANCEMONITOR_HPP
#define VSMF_SUPPORT_PERFORMANCEMONITOR_HPP

#include <atomic>
#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "common/Types.hpp"

namespace vsmf {

class LoggerService;

struct PerfSnapshot {
    double        throughputMsgPerSec = 0.0;
    double        avgLatencyUs = 0.0;
    double        minLatencyUs = 0.0;
    double        maxLatencyUs = 0.0;
    double        p95LatencyUs = 0.0;
    double        cpuPercent = 0.0;
    std::uint64_t rssKb = 0;
    std::size_t   queueDepth = 0;
    std::size_t   peakQueueDepth = 0;
    std::uint64_t published = 0;
    std::uint64_t routed = 0;
    std::uint64_t processed = 0;
    std::uint64_t dropped = 0;
    std::uint64_t requests = 0;
    std::uint64_t responses = 0;
    std::uint64_t timeouts = 0;
    double        uptimeSec = 0.0;

    std::string toString() const;
};

class PerformanceMonitor {
public:
    using DepthFn  = std::function<std::size_t()>;
    using PeakFn   = std::function<std::size_t()>;
    using ReportFn = std::function<void(const PerfSnapshot&)>;

    PerformanceMonitor();
    ~PerformanceMonitor();

    void setLogger(LoggerService* lg) { logger_ = lg; }
    void setQueueDepthProvider(DepthFn d, PeakFn p);
    void setReportSink(ReportFn r);

    bool start(int intervalMs);
    void stop();

    // Hot path.
    void onPublished()               { published_.fetch_add(1, std::memory_order_relaxed); }
    void onRouted()                  { routed_.fetch_add(1, std::memory_order_relaxed); }
    void onDropped()                 { dropped_.fetch_add(1, std::memory_order_relaxed); }
    void onRequest()                 { requests_.fetch_add(1, std::memory_order_relaxed); }
    void onResponse()                { responses_.fetch_add(1, std::memory_order_relaxed); }
    void onTimeout()                 { timeouts_.fetch_add(1, std::memory_order_relaxed); }
    void onDelivered(std::uint64_t latencyNs);

    PerfSnapshot snapshot() const;
    void         reset();

private:
    void sampler(int intervalMs);

    std::atomic<bool>          running_;
    std::thread                th_;
    std::atomic<std::uint64_t> published_, routed_, processed_, dropped_;
    std::atomic<std::uint64_t> requests_, responses_, timeouts_;
    std::atomic<std::uint64_t> latSumNs_, latMinNs_, latMaxNs_, latCount_;

    mutable std::mutex         resMu_;
    std::vector<std::uint64_t> reservoir_;      // last N latencies, for p95
    std::size_t                resPos_ = 0;

    mutable std::mutex         sampMu_;
    double                     throughput_ = 0.0;
    double                     cpuPercent_ = 0.0;
    std::uint64_t              rssKb_ = 0;
    std::uint64_t              lastJiffies_ = 0;
    std::uint64_t              lastSampleNs_ = 0;
    std::uint64_t              lastProcessed_ = 0;

    std::uint64_t              startNs_ = 0;
    DepthFn                    depthFn_;
    PeakFn                     peakFn_;
    ReportFn                   report_;
    mutable std::mutex         fnMu_;
    LoggerService*             logger_ = nullptr;

    static const std::size_t kReservoir = 512;
};

}  // namespace vsmf
#endif
