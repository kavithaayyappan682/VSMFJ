// =====================================================================
//  include/data/DataGenerator.hpp
//  Physically-plausible, correlated vehicle telemetry: RPM follows speed
//  through a gearbox, coolant temperature follows load, the pack drains
//  with demand. Deterministic when seeded, so tests are reproducible.
// =====================================================================
#ifndef VSMF_DATA_DATAGENERATOR_HPP
#define VSMF_DATA_DATAGENERATOR_HPP

#include <cstdint>
#include <mutex>
#include <string>

namespace vsmf {

struct VehicleSample {
    double        speedKph    = 0.0;
    double        rpm         = 800.0;
    double        coolantC    = 70.0;
    double        batteryPct  = 100.0;
    double        latitude    = 13.0827;    // Chennai, as a plausible origin
    double        longitude   = 80.2707;
    int           gear        = 1;
    bool          gpsFix      = true;
    std::uint32_t satellites  = 9;
    std::uint64_t timestamp   = 0;
};

class DataGenerator {
public:
    explicit DataGenerator(std::uint64_t seed = 0x5EED1234ULL);

    // Advances the model by dtSec. dt is clamped to [1ms, 5s] so a
    // scheduling stall cannot teleport the vehicle.
    VehicleSample step(double dtSec);
    VehicleSample current() const;

    // Operator override from the console (`publish_speed 80`). Clamped to
    // the physical range; also nudges the internal target so the model
    // does not immediately fight the operator.
    bool setSpeed(double kph, std::string& err);
    void setTargetSpeed(double kph);
    void injectFault(bool overheat, bool batteryFault);
    void reset();

    static const double kMaxSpeedKph;
    static const double kMaxRpm;

private:
    double nextUniform();      // [0,1)
    double nextNoise(double amplitude);

    mutable std::mutex mu_;
    VehicleSample      s_;
    double             targetSpeed_ = 60.0;
    double             phase_ = 0.0;
    std::uint64_t      rng_;
    bool               faultOverheat_ = false;
    bool               faultBattery_ = false;
};

// Payload encoding shared by producers and consumers (compact JSON).
std::string encodeSpeed(const VehicleSample& s);
std::string encodeEngine(const VehicleSample& s);
std::string encodeBattery(const VehicleSample& s);
std::string encodeGps(const VehicleSample& s);

// Tolerant field extraction: returns false if absent or not a number.
bool decodeNumber(const std::string& json, const char* key, double& out);
bool decodeString(const std::string& json, const char* key, std::string& out);

}  // namespace vsmf
#endif
