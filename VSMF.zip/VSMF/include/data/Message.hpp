// =====================================================================
//  include/data/Message.hpp
//  The unit of exchange. Wire format is explicit, versioned and
//  bounds-checked: a truncated or hostile frame must be rejected, not
//  trusted into a heap allocation.
//
//  frame := u32 payloadLen (big endian)  ||  payload
//  payload := u16 version | u8 type | u8 priority
//             | u64 messageId | u64 correlationId | u64 timestampNs
//             | str sourceService | str destination | str topic | str payload
//  str   := u32 len (big endian) || bytes
// =====================================================================
#ifndef VSMF_DATA_MESSAGE_HPP
#define VSMF_DATA_MESSAGE_HPP

#include <cstdint>
#include <string>
#include <vector>

#include "common/Types.hpp"

namespace vsmf {

class Message {
public:
    std::uint64_t messageId     = 0;
    std::uint64_t correlationId = 0;   // ties RESPONSE/PONG to its REQUEST/PING
    std::uint64_t timestamp     = 0;   // wall clock ns, for logs
    std::uint64_t steadyStamp   = 0;   // monotonic ns, for latency maths
    MsgType       type          = MsgType::PUBLISH;
    Priority      priority      = Priority::NORMAL;
    std::string   sourceService;
    std::string   destination;         // "" for PUBLISH
    std::string   topic;
    std::string   payload;

    Message() {}
    Message(MsgType t, const std::string& src, const std::string& topic_,
            const std::string& payload_, Priority p = Priority::NORMAL);

    static std::uint64_t nextId() noexcept;   // process-wide, lock-free

    // Serialise into `out` (appended). False only if a field exceeds the
    // per-field / per-frame limits, which is a programming error upstream.
    bool serialize(std::vector<std::uint8_t>& out, std::string& err) const;

    // Parse a *payload* (without the u32 length prefix). This is what the
    // transport calls: it has already consumed the prefix to decide how
    // many bytes to read.
    static bool deserialize(const std::uint8_t* data, std::size_t len,
                            Message& out, std::string& err);

    // Symmetric counterpart of serialize(): parses a complete frame,
    // prefix included, and checks the prefix against the buffer length.
    static bool deserializeFrame(const std::uint8_t* frame, std::size_t len,
                                 Message& out, std::string& err);

    std::string toLogString() const;
    bool        isValid(std::string& why) const;
};

}  // namespace vsmf
#endif
