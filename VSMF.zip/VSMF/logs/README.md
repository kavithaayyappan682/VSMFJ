# Log files are written here at runtime:
# middleware.log, performance.log, diagnostics.log, health.log
