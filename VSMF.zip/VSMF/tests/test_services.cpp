// =====================================================================
//  Unit tests: ServiceBase, the four producers, the three consumers,
//              HealthMonitor, ControlService, and a full-system
//              integration test over the real Unix domain socket.
// =====================================================================
#include <gtest/gtest.h>

#include <atomic>
#include <set>
#include <string>
#include <vector>

#include "TestUtil.hpp"
#include "core/CommunicationManager.hpp"
#include "core/DiscoveryManager.hpp"
#include "core/ServiceRegistry.hpp"
#include "data/DataGenerator.hpp"
#include "services/BatteryService.hpp"
#include "services/ControlService.hpp"
#include "services/DashboardService.hpp"
#include "services/DiagnosticService.hpp"
#include "services/EngineSensorService.hpp"
#include "services/GPSService.hpp"
#include "services/SpeedSensorService.hpp"
#include "services/VehicleControlService.hpp"
#include "support/ConfigManager.hpp"
#include "support/HealthMonitor.hpp"
#include "support/LifecycleManager.hpp"
#include "support/LoggerService.hpp"
#include "support/PerformanceMonitor.hpp"
#include "support/ThreadPool.hpp"

using namespace vsmf;
using namespace vsmftest;

namespace {

// A running middleware with the thread pool attached: everything the
// services need, on a private socket, torn down in the destructor.
struct Rig {
    ServiceRegistry      reg;
    DiscoveryManager     disc;
    CommunicationManager cm;
    ThreadPool           pool;
    ConfigManager        cfgMgr;
    DataGenerator        gen;
    std::string          sock;
    bool                 up = false;
    std::string          err;

    Rig() : disc(reg), cm(reg), sock(uniquePath("rig", ".sock")) {
        pool.start(4, 4096);
        cm.setThreadPool(&pool);
        Config cfg;
        cfg.socketPath = sock;
        cfg.requestTimeoutMs = 1500;
        up = cm.start(cfg, err);
    }
    ~Rig() {
        cm.stop();
        pool.stop(false);
        std::remove(sock.c_str());
    }
};

}  // namespace

// ------------------------------------------------------------- ServiceBase
TEST(ServiceBase, StartRegistersAndStopUnregistersCleanly) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    SpeedSensorService s(r.cm, r.gen, 50);
    EXPECT_EQ(ServiceState::CREATED, s.state());
    ASSERT_TRUE(s.start());
    EXPECT_EQ(ServiceState::RUNNING, s.state());
    EXPECT_TRUE(s.isRunning());
    EXPECT_TRUE(r.reg.contains("SpeedSensorService"));

    ServiceInfo si;
    ASSERT_TRUE(r.reg.get("SpeedSensorService", si));
    EXPECT_EQ(ServiceKind::Producer, si.kind);
    ASSERT_FALSE(si.publishes.empty());
    EXPECT_EQ(topics::kSpeed, si.publishes[0]);

    s.stop();
    EXPECT_EQ(ServiceState::STOPPED, s.state());
}

TEST(ServiceBase, StartAndStopAreIdempotent) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    GPSService s(r.cm, r.gen, 50);
    EXPECT_TRUE(s.start());
    EXPECT_TRUE(s.start());                   // second call is a no-op, not an error
    s.stop();
    s.stop();
    EXPECT_EQ(ServiceState::STOPPED, s.state());
}

TEST(ServiceBase, PausedServiceStopsPublishingAndResumes) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    SpeedSensorService s(r.cm, r.gen, 20);
    ASSERT_TRUE(s.start());
    ASSERT_TRUE(waitUntil([&s] { return s.published() > 2; }, 3000));

    s.pause();
    EXPECT_EQ(ServiceState::PAUSED, s.state());
    std::uint64_t frozen = s.published();
    sleepMs(200);
    EXPECT_EQ(frozen, s.published());          // really quiet while paused

    s.resume();
    EXPECT_EQ(ServiceState::RUNNING, s.state());
    EXPECT_TRUE(waitUntil([&s, frozen] { return s.published() > frozen; }, 3000));
    s.stop();
}

TEST(ServiceBase, RestartAfterStopWorks) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    BatteryService s(r.cm, r.gen, 30);
    ASSERT_TRUE(s.start());
    s.stop();
    ASSERT_TRUE(s.start());                    // endpoint name must be reusable
    EXPECT_EQ(ServiceState::RUNNING, s.state());
    s.stop();
}

TEST(ServiceBase, StartFailsGracefullyWhenTheTransportIsDown) {
    ServiceRegistry reg;
    CommunicationManager cm(reg);              // never started
    DataGenerator gen;
    SpeedSensorService s(cm, gen, 50);
    EXPECT_FALSE(s.start());
    EXPECT_EQ(ServiceState::FAILED, s.state());
    EXPECT_FALSE(s.lastError().empty());
    s.stop();                                   // must still be safe
}

// --------------------------------------------------------------- Producers
TEST(SpeedSensorService, PublishesSpeedSamplesOnItsTopic) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string err;
    EndpointPtr sub = r.cm.createEndpoint("TestSubscriber", err);
    ASSERT_TRUE(sub) << err;

    std::mutex mu;
    std::vector<Message> got;
    sub->setHandler([&mu, &got](const Message& m) {
        std::lock_guard<std::mutex> lk(mu);
        got.push_back(m);
    });
    ASSERT_TRUE(sub->subscribe(topics::kSpeed, err)) << err;

    SpeedSensorService s(r.cm, r.gen, 20);
    ASSERT_TRUE(s.start());
    EXPECT_TRUE(waitUntil([&mu, &got] {
        std::lock_guard<std::mutex> lk(mu);
        return got.size() >= 3;
    }, 4000));
    s.stop();

    std::lock_guard<std::mutex> lk(mu);
    ASSERT_FALSE(got.empty());
    EXPECT_EQ("SpeedSensorService", got[0].sourceService);
    EXPECT_EQ(topics::kSpeed, got[0].topic);
    double v = -1.0;
    EXPECT_TRUE(decodeNumber(got[0].payload, "speed", v));
    EXPECT_GE(v, 0.0);
}

TEST(Producers, EngineBatteryAndGpsAllPublishTheirTopics) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string err;
    EndpointPtr sub = r.cm.createEndpoint("Collector", err);
    ASSERT_TRUE(sub) << err;

    std::mutex mu;
    std::set<std::string> seen;
    sub->setHandler([&mu, &seen](const Message& m) {
        std::lock_guard<std::mutex> lk(mu);
        seen.insert(m.topic);
    });
    ASSERT_TRUE(sub->subscribe("vehicle.*", err)) << err;

    SpeedSensorService  speed(r.cm, r.gen, 20);
    EngineSensorService engine(r.cm, r.gen, 20);
    BatteryService      battery(r.cm, r.gen, 20);
    GPSService          gps(r.cm, r.gen, 20);
    ASSERT_TRUE(speed.start());
    ASSERT_TRUE(engine.start());
    ASSERT_TRUE(battery.start());
    ASSERT_TRUE(gps.start());

    EXPECT_TRUE(waitUntil([&mu, &seen] {
        std::lock_guard<std::mutex> lk(mu);
        return seen.size() >= 4;
    }, 5000));

    gps.stop();
    battery.stop();
    engine.stop();
    speed.stop();

    std::lock_guard<std::mutex> lk(mu);
    EXPECT_EQ(1u, seen.count(topics::kSpeed));
    EXPECT_EQ(1u, seen.count(topics::kEngine));
    EXPECT_EQ(1u, seen.count(topics::kBattery));
    EXPECT_EQ(1u, seen.count(topics::kGps));
}

TEST(BatteryService, AnswersRequestResponseQueries) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    BatteryService battery(r.cm, r.gen, 50);
    ASSERT_TRUE(battery.start());

    std::string err;
    EndpointPtr caller = r.cm.createEndpoint("Caller", err);
    ASSERT_TRUE(caller) << err;

    Message out;
    ASSERT_TRUE(caller->request("BatteryService", topics::kBattery, "level", 3000, out, err)) << err;
    double pct = -1.0;
    EXPECT_TRUE(decodeNumber(out.payload, "battery", pct));
    EXPECT_GE(pct, 0.0);
    EXPECT_LE(pct, 100.0);
    EXPECT_EQ(1u, battery.served());
    battery.stop();
}

TEST(BatteryService, PausedServiceAnswersWithAnErrorRatherThanHanging) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    BatteryService battery(r.cm, r.gen, 50);
    ASSERT_TRUE(battery.start());
    battery.pause();

    std::string err;
    EndpointPtr caller = r.cm.createEndpoint("Caller", err);
    ASSERT_TRUE(caller) << err;
    Message out;
    std::uint64_t t0 = util::steadyNs();
    EXPECT_FALSE(caller->request("BatteryService", topics::kBattery, "level", 3000, out, err));
    EXPECT_LT(static_cast<double>(util::steadyNs() - t0) / 1e6, 2500.0);
    EXPECT_FALSE(err.empty());
    battery.stop();
}

// --------------------------------------------------------------- Consumers
TEST(DashboardService, AggregatesEveryVehicleTopic) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    DashboardService dash(r.cm);
    ASSERT_TRUE(dash.start());

    SpeedSensorService  speed(r.cm, r.gen, 20);
    EngineSensorService engine(r.cm, r.gen, 20);
    BatteryService      battery(r.cm, r.gen, 20);
    GPSService          gps(r.cm, r.gen, 20);
    ASSERT_TRUE(speed.start());
    ASSERT_TRUE(engine.start());
    ASSERT_TRUE(battery.start());
    ASSERT_TRUE(gps.start());

    EXPECT_TRUE(waitUntil([&dash] {
        DashboardData d = dash.data();
        return d.rpm > 0.0 && d.battery > 0.0 && d.gpsFix && d.updates > 4;
    }, 6000));

    DashboardData d = dash.data();
    EXPECT_GE(d.speed, 0.0);
    EXPECT_GT(d.temperature, -50.0);
    EXPECT_NE(0.0, d.latitude);
    EXPECT_NE(0u, d.lastUpdateNs);

    dash.setPerfLine(123.4, 55.5);
    EXPECT_NEAR(123.4, dash.data().latencyUs, 1e-6);
    EXPECT_NEAR(55.5, dash.data().throughput, 1e-6);

    gps.stop(); battery.stop(); engine.stop(); speed.stop();
    dash.stop();
}

TEST(DashboardService, DirtyFlagFiresOncePerChange) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    DashboardService dash(r.cm);
    ASSERT_TRUE(dash.start());
    dash.consumeDirty();                         // clear whatever start left
    EXPECT_FALSE(dash.consumeDirty());
    dash.setPerfLine(1.0, 2.0);
    EXPECT_TRUE(dash.consumeDirty());
    EXPECT_FALSE(dash.consumeDirty());           // consumed exactly once
    dash.stop();
}

TEST(DiagnosticService, RaisesAlertsFromConfiguredLimitsNotConstants) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    // A deliberately low speed limit: the alert must follow the config.
    std::string cfgPath = uniquePath("diagcfg", ".json");
    ASSERT_TRUE(writeFile(cfgPath, "{\"speed_limit\":30,\"temperature_limit\":100,"
                                   "\"battery_limit\":15}"));
    std::string err;
    ASSERT_TRUE(r.cfgMgr.load(cfgPath, err)) << err;

    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());

    EndpointPtr pub = r.cm.createEndpoint("FakeSpeedSensor", err);
    ASSERT_TRUE(pub) << err;
    ASSERT_TRUE(pub->publish(topics::kSpeed, "{\"speed\":80.0,\"gear\":4}", Priority::HIGH, err));

    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() > 0; }, 4000));
    std::vector<Alert> alerts = diag.recentAlerts(10);
    ASSERT_FALSE(alerts.empty());
    EXPECT_EQ(topics::kSpeed, alerts.back().topic);
    EXPECT_NE(std::string::npos, alerts.back().text.find("80"));
    EXPECT_FALSE(diag.summary().empty());
    diag.stop();
    std::remove(cfgPath.c_str());
}

TEST(DiagnosticService, AlertsAreEdgeTriggeredNotRepeatedEverySample) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string cfgPath = uniquePath("diagcfg2", ".json");
    ASSERT_TRUE(writeFile(cfgPath, "{\"speed_limit\":50}"));
    std::string err;
    ASSERT_TRUE(r.cfgMgr.load(cfgPath, err)) << err;

    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());
    EndpointPtr pub = r.cm.createEndpoint("FakeSensor", err);
    ASSERT_TRUE(pub) << err;

    for (int i = 0; i < 20; ++i)
        pub->publish(topics::kSpeed, "{\"speed\":90.0}", Priority::HIGH, err);
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() >= 1; }, 4000));
    sleepMs(300);
    EXPECT_EQ(1u, diag.alertCount());            // one edge, one alert

    // Dropping back below the limit and rising again is a new edge.
    for (int i = 0; i < 5; ++i)
        pub->publish(topics::kSpeed, "{\"speed\":10.0}", Priority::HIGH, err);
    sleepMs(200);
    for (int i = 0; i < 5; ++i)
        pub->publish(topics::kSpeed, "{\"speed\":95.0}", Priority::HIGH, err);
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() >= 2; }, 4000));
    diag.stop();
    std::remove(cfgPath.c_str());
}

TEST(DiagnosticService, MalformedPayloadsAreIgnoredWithoutCrashing) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());
    std::string err;
    EndpointPtr pub = r.cm.createEndpoint("Noise", err);
    ASSERT_TRUE(pub) << err;

    const char* junk[] = {"", "not json", "{}", "{\"speed\":\"fast\"}", "[1,2,3]",
                          "{\"speed\":null}", "{\"speed\":1e400}"};
    for (std::size_t i = 0; i < sizeof(junk) / sizeof(junk[0]); ++i)
        pub->publish(topics::kSpeed, junk[i], Priority::NORMAL, err);
    sleepMs(300);
    EXPECT_EQ(0u, diag.alertCount());
    EXPECT_EQ(ServiceState::RUNNING, diag.state());
    diag.stop();
}

TEST(DiagnosticService, AlertHistoryIsBounded) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string cfgPath = uniquePath("diagcfg3", ".json");
    ASSERT_TRUE(writeFile(cfgPath, "{\"speed_limit\":50}"));
    std::string err;
    r.cfgMgr.load(cfgPath, err);

    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());
    EndpointPtr pub = r.cm.createEndpoint("Flapper", err);
    ASSERT_TRUE(pub) << err;

    for (int i = 0; i < 200; ++i) {           // flap across the limit repeatedly
        pub->publish(topics::kSpeed, "{\"speed\":95.0}", Priority::HIGH, err);
        pub->publish(topics::kSpeed, "{\"speed\":5.0}", Priority::HIGH, err);
    }
    sleepMs(800);
    EXPECT_LE(diag.recentAlerts(1000).size(), 64u);   // history never grows forever
    diag.stop();
    std::remove(cfgPath.c_str());
}

TEST(VehicleControlService, QueriesBatteryAndReportsStatus) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    BatteryService battery(r.cm, r.gen, 30);
    ASSERT_TRUE(battery.start());

    VehicleControlService vc(r.cm, r.disc, r.cfgMgr, 60);
    ASSERT_TRUE(vc.start());
    EXPECT_TRUE(waitUntil([&vc] { return vc.requests() > 0; }, 5000));
    EXPECT_FALSE(vc.status().empty());
    EXPECT_FALSE(vc.limpMode());               // a full pack is not limp mode
    vc.stop();
    battery.stop();
}

TEST(VehicleControlService, SurvivesTheBatteryServiceBeingAbsent) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    VehicleControlService vc(r.cm, r.disc, r.cfgMgr, 50);
    ASSERT_TRUE(vc.start());                   // nothing to discover
    sleepMs(400);
    EXPECT_EQ(ServiceState::RUNNING, vc.state());
    EXPECT_FALSE(vc.status().empty());
    vc.stop();
}

// ------------------------------------------------------------ HealthMonitor
TEST(HealthMonitor, ReportsRunningServicesAsHealthy) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    SpeedSensorService speed(r.cm, r.gen, 50);
    BatteryService     battery(r.cm, r.gen, 50);
    ASSERT_TRUE(speed.start());
    ASSERT_TRUE(battery.start());

    HealthMonitor hm(r.cm, r.reg, r.cfgMgr);
    std::string err;
    ASSERT_TRUE(hm.start(err)) << err;
    hm.checkOnce();

    HealthReport rep = hm.report();
    EXPECT_EQ(2u, rep.perService.size());
    EXPECT_EQ(0u, rep.unhealthy);
    EXPECT_EQ(HealthState::HEALTHY, hm.overall());
    EXPECT_FALSE(rep.toString().empty());
    hm.stop();
    hm.stop();                                  // idempotent
    battery.stop();
    speed.stop();
}

TEST(HealthMonitor, MarksAServiceUnhealthyAfterRepeatedMissedBeats) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    // A registered service with no live endpoint: it can never answer a PING.
    ServiceInfo ghost;
    ghost.name = "GhostService";
    ghost.endpoint = "GhostService";
    ghost.state = ServiceState::RUNNING;
    std::string err;
    ASSERT_TRUE(r.reg.registerService(ghost, err)) << err;

    HealthMonitor hm(r.cm, r.reg, r.cfgMgr);
    ASSERT_TRUE(hm.start(err)) << err;
    for (int i = 0; i < 5; ++i) hm.checkOnce();

    ServiceInfo si;
    ASSERT_TRUE(r.reg.get("GhostService", si));
    EXPECT_GT(si.missedHeartbeats, 0u);
    EXPECT_EQ(HealthState::UNHEALTHY, si.health);
    EXPECT_NE(HealthState::HEALTHY, hm.overall());
    hm.stop();
}

TEST(HealthMonitor, PublishesItsReportOnTheHealthTopic) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string err;
    EndpointPtr sub = r.cm.createEndpoint("HealthWatcher", err);
    ASSERT_TRUE(sub) << err;
    std::atomic<int> n(0);
    sub->setHandler([&n](const Message& m) {
        if (m.topic == topics::kHealth) n.fetch_add(1);
    });
    ASSERT_TRUE(sub->subscribe(topics::kHealth, err)) << err;

    SpeedSensorService speed(r.cm, r.gen, 50);
    ASSERT_TRUE(speed.start());
    HealthMonitor hm(r.cm, r.reg, r.cfgMgr);
    ASSERT_TRUE(hm.start(err)) << err;
    hm.checkOnce();
    EXPECT_TRUE(waitUntil([&n] { return n.load() > 0; }, 4000));
    hm.stop();
    speed.stop();
}

// ----------------------------------------------------------- ControlService
namespace {

// Builds the full SystemContext the console commands operate on.
struct Console {
    // Declaration order is load-bearing: members are destroyed in reverse,
    // so the logger and the performance monitor must be declared BEFORE the
    // Rig whose CommunicationManager holds pointers to them.
    LoggerService         logger;
    PerformanceMonitor    perf;
    Rig                   rig;
    LifecycleManager      lifecycle;
    DashboardService      dashboard;
    DiagnosticService     diagnostics;
    VehicleControlService control;
    SpeedSensorService    speed;
    BatteryService        battery;
    HealthMonitor         health;
    std::atomic<bool>     shutdownFlag;
    SystemContext         ctx;
    std::string           logDir;

    Console()
        : lifecycle(rig.reg),
          dashboard(rig.cm),
          diagnostics(rig.cm, rig.cfgMgr),
          control(rig.cm, rig.disc, rig.cfgMgr, 100),
          speed(rig.cm, rig.gen, 50),
          battery(rig.cm, rig.gen, 50),
          health(rig.cm, rig.reg, rig.cfgMgr),
          shutdownFlag(false),
          logDir(uniqueDir("consolelogs")) {
        std::string err;
        logger.configure(logDir, LogLevel::TRACE, 1 << 20, 4096, err);
        logger.start();

        ctx.cfg = &rig.cfgMgr;
        ctx.registry = &rig.reg;
        ctx.discovery = &rig.disc;
        ctx.comm = &rig.cm;
        ctx.pool = &rig.pool;
        ctx.logger = &logger;
        ctx.perf = &perf;
        ctx.health = &health;
        ctx.lifecycle = &lifecycle;
        ctx.generator = &rig.gen;
        ctx.dashboard = &dashboard;
        ctx.diagnostics = &diagnostics;
        ctx.control = &control;
        ctx.shutdownFlag = &shutdownFlag;
    }
    ~Console() {
        lifecycle.stopAll();
        health.stop();
        logger.stop();
        removeTree(logDir);
    }
};

}  // namespace

TEST(ControlService, AnswersEveryDocumentedCommand) {
    Console c;
    ASSERT_TRUE(c.rig.up) << c.rig.err;
    std::string err;
    ASSERT_TRUE(c.health.start(err)) << err;

    ControlService console(c.rig.cm, c.ctx);
    IService* order[] = {&c.dashboard, &c.diagnostics, &c.control,
                         &console, &c.speed, &c.battery};
    for (std::size_t i = 0; i < sizeof(order) / sizeof(order[0]); ++i)
        ASSERT_TRUE(c.lifecycle.add(order[i], err)) << err;
    ASSERT_TRUE(c.lifecycle.startAll(err)) << err;

    EXPECT_NE(std::string::npos, console.execute("services").find("SpeedSensorService"));
    EXPECT_NE(std::string::npos, console.execute("discover BatteryService").find("BatteryService"));
    EXPECT_NE(std::string::npos, console.execute("publish_speed 80").find("80"));
    EXPECT_NE(std::string::npos, console.execute("battery").find("BatteryService"));
    EXPECT_FALSE(console.execute("diagnostics").empty());
    EXPECT_FALSE(console.execute("metrics").empty());
    EXPECT_FALSE(console.execute("status").empty());
    EXPECT_FALSE(console.execute("health").empty());
    EXPECT_NE(std::string::npos, console.execute("config").find("speed_limit"));
    EXPECT_FALSE(console.execute("logs").empty());
    EXPECT_FALSE(console.execute("logs performance 3").empty());
    EXPECT_NE(std::string::npos, console.execute("help").find("publish_speed"));
}

TEST(ControlService, RejectsBadInputWithoutMisbehaving) {
    Console c;
    ASSERT_TRUE(c.rig.up) << c.rig.err;
    ControlService console(c.rig.cm, c.ctx);
    std::string err;
    ASSERT_TRUE(c.lifecycle.add(&console, err)) << err;
    ASSERT_TRUE(console.start());

    EXPECT_NE(std::string::npos, console.execute("bogus").find("unknown"));
    EXPECT_NE(std::string::npos, console.execute("discover").find("usage"));
    EXPECT_NE(std::string::npos, console.execute("discover NoSuchService").find("not found"));
    EXPECT_NE(std::string::npos, console.execute("publish_speed").find("usage"));
    EXPECT_FALSE(console.execute("publish_speed abc").empty());
    EXPECT_FALSE(console.execute("publish_speed -20").empty());
    EXPECT_FALSE(console.execute("publish_speed 99999").empty());
    EXPECT_FALSE(console.execute("restart NoSuchService").empty());
    EXPECT_FALSE(console.execute("logs nosuchchannel").empty());
    EXPECT_TRUE(console.execute("").empty() || !console.execute("").empty());
    EXPECT_FALSE(console.execute(std::string(10000, 'x')).empty());   // no overflow
    EXPECT_EQ(ServiceState::RUNNING, console.state());
    console.stop();
}

TEST(ControlService, RestartsAServiceThroughTheLifecycleManager) {
    Console c;
    ASSERT_TRUE(c.rig.up) << c.rig.err;
    ControlService console(c.rig.cm, c.ctx);
    std::string err;
    ASSERT_TRUE(c.lifecycle.add(&c.diagnostics, err)) << err;
    ASSERT_TRUE(c.lifecycle.add(&console, err)) << err;
    ASSERT_TRUE(c.lifecycle.startAll(err)) << err;

    EXPECT_NE(std::string::npos, console.execute("pause DiagnosticService").find("pause"));
    EXPECT_EQ(ServiceState::PAUSED, c.diagnostics.state());
    EXPECT_NE(std::string::npos, console.execute("resume DiagnosticService").find("resume"));
    EXPECT_EQ(ServiceState::RUNNING, c.diagnostics.state());
    EXPECT_NE(std::string::npos, console.execute("restart DiagnosticService").find("restart"));
    EXPECT_EQ(ServiceState::RUNNING, c.diagnostics.state());
}

TEST(ControlService, ShutdownSetsTheFlagRatherThanKillingTheProcess) {
    Console c;
    ASSERT_TRUE(c.rig.up) << c.rig.err;
    ControlService console(c.rig.cm, c.ctx);
    ASSERT_TRUE(console.start());
    EXPECT_FALSE(c.shutdownFlag.load());
    console.execute("shutdown");
    EXPECT_TRUE(c.shutdownFlag.load());
    console.stop();
}

// -------------------------------------------------------------- Integration
TEST(Integration, TheWholeFrameworkRunsPublishSubscribeAndRequestResponse) {
    // Declared before the Rig on purpose: the CommunicationManager inside
    // the Rig keeps raw pointers to both, and destruction runs in reverse
    // declaration order.
    LoggerService      logger;
    PerformanceMonitor perf;

    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string logDir = uniqueDir("integlogs");
    std::string err;
    ASSERT_TRUE(logger.configure(logDir, LogLevel::INFO, 1 << 20, 4096, err)) << err;
    ASSERT_TRUE(logger.start());
    r.cm.setLogger(&logger);

    perf.setLogger(&logger);
    r.cm.setPerf(&perf);
    ASSERT_TRUE(perf.start(100));

    // Consumers first, then producers: exactly the boot order main.cpp uses.
    DashboardService      dash(r.cm);
    DiagnosticService     diag(r.cm, r.cfgMgr);
    VehicleControlService vc(r.cm, r.disc, r.cfgMgr, 100);
    SpeedSensorService    speed(r.cm, r.gen, 40);
    EngineSensorService   engine(r.cm, r.gen, 40);
    BatteryService        battery(r.cm, r.gen, 40);
    GPSService            gps(r.cm, r.gen, 40);

    LifecycleManager lifecycle(r.reg);
    lifecycle.setLogger(&logger);
    IService* order[] = {&dash, &diag, &vc, &speed, &engine, &battery, &gps};
    for (std::size_t i = 0; i < sizeof(order) / sizeof(order[0]); ++i)
        ASSERT_TRUE(lifecycle.add(order[i], err)) << err;
    ASSERT_TRUE(lifecycle.startAll(err)) << err;
    EXPECT_EQ(7u, r.reg.size());

    HealthMonitor health(r.cm, r.reg, r.cfgMgr);
    ASSERT_TRUE(health.start(err)) << err;

    // Pub/sub reached the dashboard, and req/resp reached the battery.
    EXPECT_TRUE(waitUntil([&dash] {
        DashboardData d = dash.data();
        return d.updates > 8 && d.rpm > 0.0 && d.battery > 0.0;
    }, 8000));
    EXPECT_TRUE(waitUntil([&vc] { return vc.requests() > 0; }, 8000));

    health.checkOnce();
    EXPECT_EQ(HealthState::HEALTHY, health.overall());

    PerfSnapshot s = perf.snapshot();
    EXPECT_GT(s.published, 0u);
    EXPECT_GT(s.processed, 0u);
    EXPECT_EQ(0u, s.dropped);
    EXPECT_GT(s.avgLatencyUs, 0.0);

    // Ordered shutdown must be quiet and complete.
    health.stop();
    perf.stop();
    lifecycle.stopAll();
    for (std::size_t i = 0; i < sizeof(order) / sizeof(order[0]); ++i)
        EXPECT_EQ(ServiceState::STOPPED, order[i]->state());

    logger.flush();
    EXPECT_TRUE(util::fileExists(logDir + "/middleware.log"));
    EXPECT_TRUE(util::fileExists(logDir + "/health.log"));
    logger.stop();
    removeTree(logDir);
}

TEST(Integration, RepeatedStartStopCyclesDoNotLeakEndpointsOrThreads) {
    Rig r;
    ASSERT_TRUE(r.up) << r.err;
    for (int cycle = 0; cycle < 5; ++cycle) {
        DashboardService   dash(r.cm);
        SpeedSensorService speed(r.cm, r.gen, 20);
        BatteryService     battery(r.cm, r.gen, 20);
        ASSERT_TRUE(dash.start());
        ASSERT_TRUE(speed.start());
        ASSERT_TRUE(battery.start());
        EXPECT_TRUE(waitUntil([&dash] { return dash.data().updates > 0; }, 4000));
        battery.stop();
        speed.stop();
        dash.stop();
        // The registry keeps stopped services on purpose, so the console can
        // still list and restart them; what must be released is the socket
        // connection and the endpoint behind it.
        EXPECT_EQ(3u, r.reg.size());
        ServiceInfo si;
        ASSERT_TRUE(r.reg.get("SpeedSensorService", si));
        EXPECT_EQ(ServiceState::STOPPED, si.state);
        EXPECT_TRUE(waitUntil([&r] { return r.cm.ipc().connectionCount() == 0; }, 3000));
    }
}
