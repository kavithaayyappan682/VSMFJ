// Shared helpers for the VSMF unit tests.
#ifndef VSMF_TESTS_TESTUTIL_HPP
#define VSMF_TESTS_TESTUTIL_HPP

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <thread>
#include <unistd.h>

#include "common/Utils.hpp"

namespace vsmftest {

inline void sleepMs(int ms) {
    std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}

// Unique per-test paths so parallel or repeated runs never collide, and so
// a crashed run cannot poison the next one with a stale socket.
inline std::string uniquePath(const char* stem, const char* ext) {
    static int counter = 0;
    char buf[256];
    std::snprintf(buf, sizeof(buf), "/tmp/vsmf_test_%s_%ld_%d%s",
                  stem, static_cast<long>(::getpid()), ++counter, ext);
    return std::string(buf);
}

inline std::string uniqueDir(const char* stem) {
    std::string d = uniquePath(stem, "");
    std::string err;
    vsmf::util::makeDirs(d, err);
    return d;
}

inline void removeTree(const std::string& path) {
    std::string cmd = "rm -rf '" + path + "'";
    if (std::system(cmd.c_str()) != 0) { /* best effort */ }
}

inline bool writeFile(const std::string& path, const std::string& text) {
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (f == nullptr) return false;
    std::size_t n = std::fwrite(text.data(), 1, text.size(), f);
    std::fclose(f);
    return n == text.size();
}

// Spin until pred() is true or the budget expires. Used instead of fixed
// sleeps so the tests are not flaky on a loaded build machine.
template <typename Pred>
bool waitUntil(Pred pred, int timeoutMs, int stepMs = 5) {
    const std::uint64_t deadline =
        vsmf::util::steadyNs() + static_cast<std::uint64_t>(timeoutMs) * 1000000ULL;
    for (;;) {
        if (pred()) return true;
        if (vsmf::util::steadyNs() >= deadline) return false;
        sleepMs(stepMs);
    }
}

}  // namespace vsmftest

#endif
