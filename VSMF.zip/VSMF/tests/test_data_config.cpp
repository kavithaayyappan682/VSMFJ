// =====================================================================
//  Unit tests: Message, DataGenerator, Json, ConfigManager
// =====================================================================
#include <gtest/gtest.h>

#include <cmath>
#include <limits>
#include <string>
#include <vector>

#include "TestUtil.hpp"
#include "data/DataGenerator.hpp"
#include "data/Message.hpp"
#include "support/ConfigManager.hpp"
#include "support/Json.hpp"

using namespace vsmf;
using namespace vsmftest;

// ---------------------------------------------------------------- Message
TEST(Message, ConstructorFillsIdentityAndStamps) {
    Message m(MsgType::PUBLISH, "SpeedSensorService", topics::kSpeed, "{\"v\":1}");
    EXPECT_NE(0u, m.messageId);
    EXPECT_NE(0u, m.timestamp);
    EXPECT_NE(0u, m.steadyStamp);
    EXPECT_EQ(MsgType::PUBLISH, m.type);
    EXPECT_EQ(Priority::NORMAL, m.priority);
    EXPECT_EQ("SpeedSensorService", m.sourceService);
}

TEST(Message, IdsAreUniqueAndMonotonic) {
    std::uint64_t a = Message::nextId();
    std::uint64_t b = Message::nextId();
    EXPECT_LT(a, b);
}

TEST(Message, RoundTripsThroughTheWireFormat) {
    Message m(MsgType::REQUEST, "VehicleControlService", topics::kBattery, "level?", Priority::HIGH);
    m.destination   = "BatteryService";
    m.correlationId = 4242;

    std::vector<std::uint8_t> buf;
    std::string err;
    ASSERT_TRUE(m.serialize(buf, err)) << err;
    ASSERT_FALSE(buf.empty());

    Message out;
    ASSERT_TRUE(Message::deserializeFrame(buf.data(), buf.size(), out, err)) << err;
    EXPECT_EQ(m.messageId, out.messageId);
    EXPECT_EQ(m.correlationId, out.correlationId);
    EXPECT_EQ(m.timestamp, out.timestamp);
    EXPECT_EQ(m.steadyStamp, out.steadyStamp);
    EXPECT_EQ(m.type, out.type);
    EXPECT_EQ(m.priority, out.priority);
    EXPECT_EQ(m.sourceService, out.sourceService);
    EXPECT_EQ(m.destination, out.destination);
    EXPECT_EQ(m.topic, out.topic);
    EXPECT_EQ(m.payload, out.payload);
}

TEST(Message, BinaryPayloadSurvivesIntact) {
    std::string blob;
    for (int i = 0; i < 256; ++i) blob.push_back(static_cast<char>(i));
    Message m(MsgType::PUBLISH, "svc", "t", blob);
    std::vector<std::uint8_t> buf;
    std::string err;
    ASSERT_TRUE(m.serialize(buf, err));
    Message out;
    ASSERT_TRUE(Message::deserializeFrame(buf.data(), buf.size(), out, err)) << err;
    EXPECT_EQ(blob, out.payload);
}

TEST(Message, TruncatedFrameIsRejectedNotCrashed) {
    Message m(MsgType::PUBLISH, "svc", "t", "0123456789");
    std::vector<std::uint8_t> buf;
    std::string err;
    ASSERT_TRUE(m.serialize(buf, err));
    for (std::size_t cut = 0; cut < buf.size(); ++cut) {
        Message out;
        std::string e;
        EXPECT_FALSE(Message::deserializeFrame(buf.data(), cut, out, e)) << "cut=" << cut;
    }
}

TEST(Message, GarbageBytesAreRejected) {
    std::vector<std::uint8_t> junk(64, 0xEE);
    Message out;
    std::string err;
    EXPECT_FALSE(Message::deserializeFrame(junk.data(), junk.size(), out, err));
    EXPECT_FALSE(err.empty());
    EXPECT_FALSE(Message::deserialize(junk.data(), junk.size(), out, err));
    EXPECT_FALSE(Message::deserialize(nullptr, 0, out, err));
}

TEST(Message, OversizedFieldsAreRefusedBeforeSending) {
    Message m(MsgType::PUBLISH, "svc", "t", std::string(limits::kMaxStringBytes + 1, 'x'));
    std::vector<std::uint8_t> buf;
    std::string err;
    EXPECT_FALSE(m.serialize(buf, err));
}

TEST(Message, ValidationRejectsEmptyAndOverlongNames) {
    Message ok(MsgType::PUBLISH, "svc", topics::kSpeed, "{}");
    std::string why;
    EXPECT_TRUE(ok.isValid(why)) << why;

    Message noSource;
    noSource.type = MsgType::PUBLISH;
    noSource.topic = "t";
    EXPECT_FALSE(noSource.isValid(why));

    Message longTopic(MsgType::PUBLISH, "svc",
                      std::string(limits::kMaxTopicName + 1, 't'), "{}");
    EXPECT_FALSE(longTopic.isValid(why));
}

TEST(Message, LogStringIsSingleLineAndBounded) {
    Message m(MsgType::PUBLISH, "svc", "t", std::string(4096, 'z'));
    std::string s = m.toLogString();
    EXPECT_EQ(std::string::npos, s.find('\n'));
    EXPECT_LT(s.size(), 512u);
}

// ----------------------------------------------------------- DataGenerator
TEST(DataGenerator, IsDeterministicForAGivenSeed) {
    DataGenerator a(1234), b(1234);
    for (int i = 0; i < 50; ++i) {
        VehicleSample x = a.step(0.1), y = b.step(0.1);
        EXPECT_DOUBLE_EQ(x.speedKph, y.speedKph);
        EXPECT_DOUBLE_EQ(x.rpm, y.rpm);
    }
}

TEST(DataGenerator, StaysInsidePhysicalLimits) {
    DataGenerator g;
    g.setTargetSpeed(1e9);                       // absurd request, must clamp
    for (int i = 0; i < 2000; ++i) {
        VehicleSample s = g.step(0.05);
        EXPECT_GE(s.speedKph, 0.0);
        EXPECT_LE(s.speedKph, DataGenerator::kMaxSpeedKph);
        EXPECT_GE(s.rpm, 0.0);
        EXPECT_LE(s.rpm, DataGenerator::kMaxRpm);
        EXPECT_GE(s.batteryPct, 0.0);
        EXPECT_LE(s.batteryPct, 100.0);
        EXPECT_GE(s.coolantC, -50.0);
        EXPECT_LE(s.coolantC, 200.0);
    }
}

TEST(DataGenerator, RejectsNonsenseSpeedAndAcceptsSaneOnes) {
    DataGenerator g;
    std::string err;
    EXPECT_FALSE(g.setSpeed(-5.0, err));
    EXPECT_FALSE(err.empty());
    EXPECT_FALSE(g.setSpeed(1e6, err));
    EXPECT_TRUE(g.setSpeed(88.0, err)) << err;
    EXPECT_NEAR(88.0, g.current().speedKph, 1e-9);
}

TEST(DataGenerator, ClampsNonPositiveAndAbsurdTimeSteps) {
    DataGenerator g;
    // A zero, negative or NaN dt is treated as the minimum tick rather than
    // being propagated into the physics, and a huge dt (a suspended process
    // or a clock jump) is capped instead of integrating a giant step.
    g.step(0.0);
    g.step(-1.0);
    double nan = std::numeric_limits<double>::quiet_NaN();
    g.step(nan);
    VehicleSample a = g.current();
    EXPECT_FALSE(std::isnan(a.speedKph));
    EXPECT_LT(a.speedKph, 1.0);                   // barely moved
    g.step(1e9);
    VehicleSample b = g.current();
    EXPECT_FALSE(std::isnan(b.speedKph));
    EXPECT_LE(b.speedKph, DataGenerator::kMaxSpeedKph);
    EXPECT_LE(b.rpm, DataGenerator::kMaxRpm);
}

TEST(DataGenerator, FaultInjectionDrivesTemperatureAndBattery) {
    DataGenerator healthy(99), faulty(99);
    faulty.injectFault(true, true);
    for (int i = 0; i < 4000; ++i) { healthy.step(0.1); faulty.step(0.1); }

    EXPECT_GT(faulty.current().coolantC, healthy.current().coolantC + 30.0);
    EXPECT_LT(faulty.current().batteryPct, healthy.current().batteryPct);
    EXPECT_LT(faulty.current().batteryPct, 15.0);      // low-battery alert range

    faulty.reset();
    EXPECT_NEAR(100.0, faulty.current().batteryPct, 1e-9);
}

TEST(DataGenerator, EncodeDecodeRoundTrip) {
    DataGenerator g;
    VehicleSample s = g.step(0.2);

    double v = 0.0;
    ASSERT_TRUE(decodeNumber(encodeSpeed(s), "speed", v));
    EXPECT_NEAR(s.speedKph, v, 0.05);
    ASSERT_TRUE(decodeNumber(encodeEngine(s), "rpm", v));
    EXPECT_NEAR(s.rpm, v, 1.0);
    ASSERT_TRUE(decodeNumber(encodeBattery(s), "battery", v));
    EXPECT_NEAR(s.batteryPct, v, 0.05);
    ASSERT_TRUE(decodeNumber(encodeGps(s), "lat", v));
    EXPECT_NEAR(s.latitude, v, 0.001);

    EXPECT_TRUE(decodeNumber(encodeGps(s), "satellites", v));
    std::string notAString;
    EXPECT_FALSE(decodeString(encodeSpeed(s), "speed", notAString));   // wrong type
    EXPECT_FALSE(decodeNumber(encodeSpeed(s), "no_such_key", v));
    EXPECT_FALSE(decodeNumber("not json at all", "speed", v));
}

// ------------------------------------------------------------------- Json
TEST(Json, ParsesAllScalarTypes) {
    JsonValue v;
    std::string err;
    ASSERT_TRUE(JsonValue::parse(
        "{\"n\":42.5,\"s\":\"hi\",\"b\":true,\"z\":null,\"a\":[1,2,3]}", v, err)) << err;
    EXPECT_TRUE(v.isObject());
    EXPECT_DOUBLE_EQ(42.5, v.find("n")->asNumber());
    EXPECT_EQ("hi", v.find("s")->asString());
    EXPECT_TRUE(v.find("b")->asBool());
    EXPECT_TRUE(v.find("z")->isNull());
    ASSERT_TRUE(v.find("a")->isArray());
    EXPECT_EQ(3u, v.find("a")->size());
}

TEST(Json, HandlesEscapesAndUnicode) {
    JsonValue v;
    std::string err;
    ASSERT_TRUE(JsonValue::parse("{\"s\":\"a\\\"b\\\\c\\nd\\u00e9\"}", v, err)) << err;
    std::string s = v.find("s")->asString();
    EXPECT_NE(std::string::npos, s.find('"'));
    EXPECT_NE(std::string::npos, s.find('\n'));
    EXPECT_NE(std::string::npos, s.find("\xc3\xa9"));   // e-acute as UTF-8
}

TEST(Json, RejectsMalformedInput) {
    const char* bad[] = {
        "", "   ", "{", "}", "[1,2", "{\"a\":}", "{\"a\" 1}", "{'a':1}",
        "{\"a\":1,}", "[1,2,]", "tru", "01", "1.2.3", "\"unterminated",
        "{\"a\":1} trailing", "[1 2]", "{\"a\":\"\\u00\"}"
    };
    for (std::size_t i = 0; i < sizeof(bad) / sizeof(bad[0]); ++i) {
        JsonValue v;
        std::string err;
        EXPECT_FALSE(JsonValue::parse(bad[i], v, err)) << "input #" << i << ": " << bad[i];
        EXPECT_FALSE(err.empty());
    }
}

TEST(Json, DeeplyNestedInputIsRefusedNotStackOverflowed) {
    std::string deep;
    for (int i = 0; i < 5000; ++i) deep += "[";
    for (int i = 0; i < 5000; ++i) deep += "]";
    JsonValue v;
    std::string err;
    EXPECT_FALSE(JsonValue::parse(deep, v, err));
}

TEST(Json, TypeMismatchesReturnDefaultsInsteadOfThrowing) {
    JsonValue v;
    std::string err;
    ASSERT_TRUE(JsonValue::parse("{\"a\":\"text\"}", v, err));
    const JsonValue* a = v.find("a");
    ASSERT_NE(nullptr, a);
    EXPECT_DOUBLE_EQ(7.0, a->asNumber(7.0));
    EXPECT_TRUE(a->asArray().empty());
    EXPECT_EQ(nullptr, v.find("missing"));
    EXPECT_FALSE(v.has("missing"));
}

TEST(Json, DumpAndReparseArePreserving) {
    JsonValue o = JsonValue::makeObject();
    o.set("speed_limit", JsonValue::makeNumber(180));
    o.set("log_level", JsonValue::makeString("INFO"));
    JsonValue arr = JsonValue::makeArray();
    arr.push(JsonValue::makeNumber(1));
    arr.push(JsonValue::makeBool(false));
    o.set("list", arr);

    JsonValue back;
    std::string err;
    ASSERT_TRUE(JsonValue::parse(o.dump(), back, err)) << err;
    EXPECT_DOUBLE_EQ(180.0, back.find("speed_limit")->asNumber());
    EXPECT_EQ("INFO", back.find("log_level")->asString());
    EXPECT_EQ(2u, back.find("list")->size());
}

// ---------------------------------------------------------- ConfigManager
TEST(ConfigManager, LoadsTheSpecifiedKeys) {
    std::string p = uniquePath("cfg", ".json");
    ASSERT_TRUE(writeFile(p,
        "{\"speed_limit\":180,\"temperature_limit\":100,\"battery_limit\":15,"
        "\"heartbeat_interval\":2,\"thread_pool_size\":4,\"log_level\":\"INFO\"}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(p, err)) << err;
    Config c = cm.get();
    EXPECT_DOUBLE_EQ(180.0, c.speedLimit);
    EXPECT_DOUBLE_EQ(100.0, c.temperatureLimit);
    EXPECT_DOUBLE_EQ(15.0, c.batteryLimit);
    EXPECT_EQ(2, c.heartbeatInterval);
    EXPECT_EQ(4u, c.threadPoolSize);
    EXPECT_EQ(LogLevel::INFO, c.logLevel);
    std::remove(p.c_str());
}

TEST(ConfigManager, MissingFileFallsBackToDefaultsAndKeepsBooting) {
    ConfigManager cm;
    std::string err;
    EXPECT_FALSE(cm.load("/tmp/vsmf_definitely_missing_9182.json", err));
    EXPECT_FALSE(err.empty());
    Config c = cm.get();
    EXPECT_DOUBLE_EQ(180.0, c.speedLimit);          // documented default
    EXPECT_EQ(4u, c.threadPoolSize);
}

TEST(ConfigManager, CorruptFileKeepsDefaults) {
    std::string p = uniquePath("cfgbad", ".json");
    ASSERT_TRUE(writeFile(p, "{ this is not json"));
    ConfigManager cm;
    std::string err;
    EXPECT_FALSE(cm.load(p, err));
    EXPECT_DOUBLE_EQ(100.0, cm.get().temperatureLimit);
    std::remove(p.c_str());
}

TEST(ConfigManager, OutOfRangeValuesAreClampedWithWarnings) {
    std::string p = uniquePath("cfgrange", ".json");
    ASSERT_TRUE(writeFile(p,
        "{\"speed_limit\":-40,\"thread_pool_size\":100000,"
        "\"heartbeat_interval\":0,\"battery_limit\":900}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(p, err)) << err;
    Config c = cm.get();
    EXPECT_GT(c.speedLimit, 0.0);
    EXPECT_LE(c.threadPoolSize, limits::kMaxThreads);
    EXPECT_GE(c.heartbeatInterval, 1);
    EXPECT_LE(c.batteryLimit, 100.0);
    EXPECT_FALSE(cm.warnings().empty());
    std::remove(p.c_str());
}

TEST(ConfigManager, WrongTypedValuesAreIgnored) {
    std::string p = uniquePath("cfgtype", ".json");
    ASSERT_TRUE(writeFile(p, "{\"speed_limit\":\"fast\",\"thread_pool_size\":true,"
                             "\"log_level\":42}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(p, err)) << err;
    Config c = cm.get();
    EXPECT_DOUBLE_EQ(180.0, c.speedLimit);
    EXPECT_EQ(4u, c.threadPoolSize);
    EXPECT_FALSE(cm.warnings().empty());
    std::remove(p.c_str());
}

TEST(ConfigManager, TolerantOfAUtf8ByteOrderMark) {
    std::string p = uniquePath("cfgbom", ".json");
    ASSERT_TRUE(writeFile(p, std::string("\xEF\xBB\xBF") + "{\"speed_limit\":120}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(p, err)) << err;
    EXPECT_DOUBLE_EQ(120.0, cm.get().speedLimit);
    std::remove(p.c_str());
}

TEST(ConfigManager, HotReloadOnlyAppliesWhenTheFileActuallyChanged) {
    std::string p = uniquePath("cfgreload", ".json");
    ASSERT_TRUE(writeFile(p, "{\"speed_limit\":150}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(p, err)) << err;
    EXPECT_FALSE(cm.reloadIfChanged(err));          // nothing changed yet

    sleepMs(1100);                                   // mtime has 1 s resolution
    ASSERT_TRUE(writeFile(p, "{\"speed_limit\":90}"));
    EXPECT_TRUE(cm.reloadIfChanged(err)) << err;
    EXPECT_DOUBLE_EQ(90.0, cm.get().speedLimit);
    std::remove(p.c_str());
}

TEST(ConfigManager, BadReloadKeepsTheLastGoodConfiguration) {
    std::string p = uniquePath("cfgreload2", ".json");
    ASSERT_TRUE(writeFile(p, "{\"speed_limit\":150}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(p, err)) << err;

    sleepMs(1100);
    ASSERT_TRUE(writeFile(p, "{ half written"));     // e.g. editor mid-save
    EXPECT_FALSE(cm.reloadIfChanged(err));
    EXPECT_DOUBLE_EQ(150.0, cm.get().speedLimit);    // still the good one
    std::remove(p.c_str());
}

TEST(ConfigManager, SnapshotsAreIndependentCopies) {
    ConfigManager cm;
    Config a = cm.get();
    a.speedLimit = 1.0;
    EXPECT_DOUBLE_EQ(180.0, cm.get().speedLimit);
    EXPECT_FALSE(cm.get().toString().empty());
}
