// =====================================================================
//  Unit tests: ThreadPool, LoggerService, PerformanceMonitor,
//              LifecycleManager, IService contract
// =====================================================================
#include <gtest/gtest.h>

#include <atomic>
#include <cstdio>
#include <set>
#include <string>
#include <vector>

#include "TestUtil.hpp"
#include "common/IService.hpp"
#include "core/ServiceRegistry.hpp"
#include "support/LifecycleManager.hpp"
#include "support/LoggerService.hpp"
#include "support/PerformanceMonitor.hpp"
#include "support/ThreadPool.hpp"

using namespace vsmf;
using namespace vsmftest;

// ---------------------------------------------------------------- ThreadPool
TEST(ThreadPool, RunsEverySubmittedTask) {
    ThreadPool p;
    ASSERT_TRUE(p.start(4, 1024));
    std::atomic<int> n(0);
    for (int i = 0; i < 500; ++i) p.submit([&n] { n.fetch_add(1); });
    p.stop(true);
    EXPECT_EQ(500, n.load());
    EXPECT_EQ(500u, p.completed());
    EXPECT_EQ(0u, p.dropped());
}

TEST(ThreadPool, ThreadCountIsClampedToSaneBounds) {
    ThreadPool a;
    ASSERT_TRUE(a.start(0, 16));                       // 0 is nonsense
    EXPECT_GE(a.threadCount(), limits::kMinThreads);
    a.stop();

    ThreadPool b;
    ASSERT_TRUE(b.start(100000, 16));                  // absurd
    EXPECT_LE(b.threadCount(), limits::kMaxThreads);
    b.stop();
}

TEST(ThreadPool, DropsInsteadOfBlockingWhenTheQueueIsFull) {
    ThreadPool p;
    ASSERT_TRUE(p.start(1, 4));                        // deliberately tiny
    std::atomic<bool> release(false);
    p.submit([&release] { waitUntil([&] { return release.load(); }, 5000); });

    int accepted = 0;
    for (int i = 0; i < 200; ++i)
        if (p.submit([] {})) ++accepted;

    // Bounded by the (clamped) capacity, never unbounded.
    EXPECT_LE(static_cast<std::size_t>(accepted), p.capacity() + 1);
    EXPECT_GT(p.dropped(), 0u);
    release.store(true);
    p.stop(true);
}

TEST(ThreadPool, CriticalWorkEvictsLowPriorityWorkWhenSaturated) {
    ThreadPool p;
    ASSERT_TRUE(p.start(1, 4));
    std::atomic<bool> release(false);
    p.submit([&release] { waitUntil([&] { return release.load(); }, 5000); });

    for (int i = 0; i < 8; ++i) p.submit([] {}, Priority::LOW);
    std::atomic<bool> criticalRan(false);
    EXPECT_TRUE(p.submit([&criticalRan] { criticalRan.store(true); }, Priority::CRITICAL));

    release.store(true);
    p.stop(true);
    EXPECT_TRUE(criticalRan.load());
}

TEST(ThreadPool, HigherPriorityRunsFirst) {
    ThreadPool p;
    ASSERT_TRUE(p.start(1, 256));
    std::atomic<bool> release(false);
    p.submit([&release] { waitUntil([&] { return release.load(); }, 5000); });

    std::mutex mu;
    std::vector<int> order;
    for (int i = 0; i < 5; ++i)
        p.submit([&mu, &order] { std::lock_guard<std::mutex> lk(mu); order.push_back(0); }, Priority::LOW);
    p.submit([&mu, &order] { std::lock_guard<std::mutex> lk(mu); order.push_back(3); }, Priority::CRITICAL);

    release.store(true);
    p.stop(true);
    ASSERT_FALSE(order.empty());
    EXPECT_EQ(3, order.front());
}

TEST(ThreadPool, ATaskThatThrowsDoesNotKillTheWorker) {
    ThreadPool p;
    ASSERT_TRUE(p.start(2, 64));
    p.submit([] { throw std::runtime_error("boom"); });
    p.submit([] { throw 42; });
    std::atomic<int> after(0);
    for (int i = 0; i < 20; ++i) p.submit([&after] { after.fetch_add(1); });
    p.stop(true);
    EXPECT_EQ(20, after.load());
    EXPECT_EQ(2u, p.failed());
}

TEST(ThreadPool, StopIsIdempotentAndSubmitAfterStopIsRefused) {
    ThreadPool p;
    ASSERT_TRUE(p.start(2, 16));
    p.stop();
    p.stop();
    p.stop(false);
    EXPECT_FALSE(p.isRunning());
    EXPECT_FALSE(p.submit([] {}));
}

TEST(ThreadPool, SubmitBeforeStartIsRefused) {
    ThreadPool p;
    EXPECT_FALSE(p.submit([] {}));
    EXPECT_FALSE(p.isRunning());
}

TEST(ThreadPool, NonDrainingStopDiscardsQueuedWork) {
    ThreadPool p;
    ASSERT_TRUE(p.start(1, 512));
    std::atomic<bool> release(false);
    std::atomic<int> ran(0);
    p.submit([&release] { waitUntil([&] { return release.load(); }, 3000); });
    for (int i = 0; i < 200; ++i) p.submit([&ran] { ran.fetch_add(1); });
    release.store(true);
    p.stop(false);
    EXPECT_LT(ran.load(), 200);
}

TEST(ThreadPool, RestartAfterStopWorks) {
    ThreadPool p;
    ASSERT_TRUE(p.start(2, 32));
    p.stop();
    ASSERT_TRUE(p.start(2, 32));
    std::atomic<int> n(0);
    p.submit([&n] { n.fetch_add(1); });
    p.stop(true);
    EXPECT_EQ(1, n.load());
}

// ------------------------------------------------------------- LoggerService
TEST(LoggerService, WritesTheFourRequiredChannels) {
    std::string dir = uniqueDir("logs");
    LoggerService lg;
    std::string err;
    ASSERT_TRUE(lg.configure(dir, LogLevel::TRACE, 1 << 20, 1024, err)) << err;
    ASSERT_TRUE(lg.start());

    lg.log(LogLevel::INFO, "unit", "middleware line");
    lg.logTo(LogChannel::Performance, LogLevel::INFO, "unit", "perf line");
    lg.logTo(LogChannel::Diagnostics, LogLevel::WARN, "unit", "diag line");
    lg.logTo(LogChannel::Health, LogLevel::INFO, "unit", "health line");
    lg.flush();

    EXPECT_TRUE(util::fileExists(dir + "/middleware.log"));
    EXPECT_TRUE(util::fileExists(dir + "/performance.log"));
    EXPECT_TRUE(util::fileExists(dir + "/diagnostics.log"));
    EXPECT_TRUE(util::fileExists(dir + "/health.log"));
    // The four explicit lines plus the logger's own start banner: after
    // flush() every one of them is on disk, none still in flight.
    EXPECT_EQ(5u, lg.written());
    EXPECT_EQ(0u, lg.dropped());

    std::vector<std::string> t = lg.tail(LogChannel::Diagnostics, 5);
    ASSERT_FALSE(t.empty());
    EXPECT_NE(std::string::npos, t.back().find("diag line"));
    lg.stop();
    removeTree(dir);
}

TEST(LoggerService, RespectsTheMinimumLevel) {
    std::string dir = uniqueDir("loglevel");
    LoggerService lg;
    std::string err;
    ASSERT_TRUE(lg.configure(dir, LogLevel::WARN, 1 << 20, 1024, err));
    ASSERT_TRUE(lg.start());
    lg.log(LogLevel::DEBUG, "unit", "should not appear");
    lg.log(LogLevel::ERROR, "unit", "should appear");
    lg.flush();
    std::vector<std::string> t = lg.tail(LogChannel::Middleware, 50);
    for (std::size_t i = 0; i < t.size(); ++i)
        EXPECT_EQ(std::string::npos, t[i].find("should not appear"));
    EXPECT_EQ(1u, lg.written());
    lg.stop();
    removeTree(dir);
}

TEST(LoggerService, LevelCanBeChangedAtRuntime) {
    std::string dir = uniqueDir("loglevel2");
    LoggerService lg;
    std::string err;
    ASSERT_TRUE(lg.configure(dir, LogLevel::ERROR, 1 << 20, 1024, err));
    ASSERT_TRUE(lg.start());
    lg.log(LogLevel::INFO, "unit", "hidden");
    lg.setMinLevel(LogLevel::DEBUG);
    lg.log(LogLevel::INFO, "unit", "visible");
    lg.flush();
    EXPECT_EQ(1u, lg.written());
    EXPECT_EQ(LogLevel::DEBUG, lg.minLevel());
    lg.stop();
    removeTree(dir);
}

TEST(LoggerService, RotatesWhenTheFileGrowsPastTheLimit) {
    std::string dir = uniqueDir("logrot");
    LoggerService lg;
    std::string err;
    ASSERT_TRUE(lg.configure(dir, LogLevel::TRACE, 4096, 4096, err));
    ASSERT_TRUE(lg.start());
    for (int i = 0; i < 400; ++i) lg.log(LogLevel::INFO, "unit", std::string(120, 'x'));
    lg.flush();
    lg.stop();
    EXPECT_TRUE(util::fileExists(dir + "/middleware.log.1"));
    EXPECT_LE(util::fileSize(dir + "/middleware.log"), 8192);
    removeTree(dir);
}

TEST(LoggerService, LogsWrittenBeforeStartAndAfterStopAreNotLost) {
    std::string dir = uniqueDir("logearly");
    LoggerService lg;
    std::string err;
    ASSERT_TRUE(lg.configure(dir, LogLevel::TRACE, 1 << 20, 1024, err));
    lg.log(LogLevel::INFO, "unit", "before start");        // synchronous path
    ASSERT_TRUE(lg.start());
    lg.log(LogLevel::INFO, "unit", "while running");
    lg.stop();
    lg.log(LogLevel::INFO, "unit", "after stop");
    std::vector<std::string> t = lg.tail(LogChannel::Middleware, 20);
    ASSERT_GE(t.size(), 3u);
    EXPECT_NE(std::string::npos, t.front().find("before start"));
    EXPECT_NE(std::string::npos, t.back().find("after stop"));
    removeTree(dir);
}

TEST(LoggerService, UnusableDirectoryDoesNotAbortTheProcess) {
    LoggerService lg;
    std::string err;
    // /proc is not writable; configure must report it, not throw or crash.
    bool ok = lg.configure("/proc/vsmf_cannot_create_this", LogLevel::INFO, 4096, 64, err);
    EXPECT_FALSE(ok);
    EXPECT_FALSE(err.empty());
    lg.setEchoToConsole(false);
    lg.start();
    lg.log(LogLevel::ERROR, "unit", "still alive");
    lg.flush();
    lg.stop();
}

TEST(LoggerService, DropsRatherThanGrowsWithoutBound) {
    std::string dir = uniqueDir("logdrop");
    LoggerService lg;
    std::string err;
    ASSERT_TRUE(lg.configure(dir, LogLevel::TRACE, 1 << 20, 8, err));   // tiny queue
    ASSERT_TRUE(lg.start());
    for (int i = 0; i < 20000; ++i) lg.log(LogLevel::INFO, "unit", "flood");
    lg.flush();
    lg.stop();
    // Every line is either written or explicitly counted as dropped; the
    // extra entry is the logger's own start banner.
    EXPECT_GE(lg.written() + lg.dropped(), 20000u);
    EXPECT_GT(lg.dropped(), 0u);
    removeTree(dir);
}

TEST(LoggerService, IsSafeFromManyThreadsAtOnce) {
    std::string dir = uniqueDir("logmt");
    LoggerService lg;
    std::string err;
    ASSERT_TRUE(lg.configure(dir, LogLevel::TRACE, 1 << 20, 65536, err));
    ASSERT_TRUE(lg.start());

    std::vector<std::thread> th;
    for (int t = 0; t < 8; ++t)
        th.push_back(std::thread([&lg, t] {
            for (int i = 0; i < 500; ++i)
                lg.log(LogLevel::INFO, "t" + std::to_string(t), "line " + std::to_string(i));
        }));
    for (std::size_t i = 0; i < th.size(); ++i) th[i].join();
    lg.flush();
    lg.stop();
    EXPECT_GE(lg.written() + lg.dropped(), 4000u);
    removeTree(dir);
}

TEST(LoggerService, ControlCharactersAreNotWrittenRaw) {
    std::string dir = uniqueDir("logctl");
    LoggerService lg;
    std::string err;
    ASSERT_TRUE(lg.configure(dir, LogLevel::TRACE, 1 << 20, 64, err));
    ASSERT_TRUE(lg.start());
    lg.log(LogLevel::INFO, "unit", "line one\nline two\r\x01");
    lg.flush();
    lg.stop();
    std::vector<std::string> t = lg.tail(LogChannel::Middleware, 10);
    ASSERT_FALSE(t.empty());
    // One entry stays exactly one line and carries no raw control bytes.
    EXPECT_NE(std::string::npos, t.back().find("line one line two"));
    for (std::size_t i = 0; i < t.back().size(); ++i) {
        unsigned char c = static_cast<unsigned char>(t.back()[i]);
        EXPECT_TRUE(c >= 0x20 || c == '\t');
    }
    removeTree(dir);
}

// -------------------------------------------------------- PerformanceMonitor
TEST(PerformanceMonitor, CountsAndAveragesLatency) {
    PerformanceMonitor pm;
    pm.onPublished();
    pm.onRouted();
    pm.onRequest();
    pm.onResponse();
    pm.onTimeout();
    pm.onDropped();
    pm.onDelivered(1000000);           // 1 ms
    pm.onDelivered(3000000);           // 3 ms
    PerfSnapshot s = pm.snapshot();
    EXPECT_EQ(1u, s.published);
    EXPECT_EQ(1u, s.routed);
    EXPECT_EQ(1u, s.requests);
    EXPECT_EQ(1u, s.responses);
    EXPECT_EQ(1u, s.timeouts);
    EXPECT_EQ(1u, s.dropped);
    EXPECT_EQ(2u, s.processed);
    EXPECT_NEAR(2000.0, s.avgLatencyUs, 1.0);
    EXPECT_NEAR(1000.0, s.minLatencyUs, 1.0);
    EXPECT_NEAR(3000.0, s.maxLatencyUs, 1.0);
    EXPECT_FALSE(s.toString().empty());
}

TEST(PerformanceMonitor, IgnoresImpossibleLatencies) {
    PerformanceMonitor pm;
    pm.onDelivered(0);
    pm.onDelivered(120ULL * 1000000000ULL);       // 2 minutes: a clock jump
    pm.onDelivered(2000000);
    PerfSnapshot s = pm.snapshot();
    EXPECT_LE(s.maxLatencyUs, 60.0 * 1000000.0);
    EXPECT_NEAR(2000.0, s.avgLatencyUs, 1500.0);
}

TEST(PerformanceMonitor, ResetClearsEverything) {
    PerformanceMonitor pm;
    for (int i = 0; i < 10; ++i) { pm.onPublished(); pm.onDelivered(1000000); }
    pm.reset();
    PerfSnapshot s = pm.snapshot();
    EXPECT_EQ(0u, s.published);
    EXPECT_EQ(0u, s.processed);
    EXPECT_DOUBLE_EQ(0.0, s.avgLatencyUs);
}

TEST(PerformanceMonitor, SamplerProducesReportsAndStopsCleanly) {
    PerformanceMonitor pm;
    std::atomic<int> reports(0);
    pm.setReportSink([&reports](const PerfSnapshot&) { reports.fetch_add(1); });
    pm.setQueueDepthProvider([] { return static_cast<std::size_t>(7); },
                             [] { return static_cast<std::size_t>(9); });
    ASSERT_TRUE(pm.start(50));
    for (int i = 0; i < 100; ++i) pm.onDelivered(500000);
    EXPECT_TRUE(waitUntil([&reports] { return reports.load() >= 2; }, 3000));
    PerfSnapshot s = pm.snapshot();
    EXPECT_EQ(7u, s.queueDepth);
    EXPECT_EQ(9u, s.peakQueueDepth);
    EXPECT_GT(s.throughputMsgPerSec, 0.0);
    pm.stop();
    pm.stop();                                    // idempotent
    int seen = reports.load();
    sleepMs(150);
    EXPECT_EQ(seen, reports.load());              // really stopped
}

TEST(PerformanceMonitor, AThrowingReportSinkIsContained) {
    PerformanceMonitor pm;
    pm.setReportSink([](const PerfSnapshot&) { throw std::runtime_error("sink"); });
    ASSERT_TRUE(pm.start(30));
    sleepMs(150);
    pm.stop();
    SUCCEED();                                     // reaching here is the test
}

TEST(PerformanceMonitor, P95IsBetweenMinAndMax) {
    PerformanceMonitor pm;
    for (int i = 1; i <= 1000; ++i) pm.onDelivered(static_cast<std::uint64_t>(i) * 1000);
    PerfSnapshot s = pm.snapshot();
    EXPECT_GE(s.p95LatencyUs, s.minLatencyUs);
    EXPECT_LE(s.p95LatencyUs, s.maxLatencyUs);
}

// --------------------------------------------------------- LifecycleManager
namespace {
class FakeService : public IService {
public:
    explicit FakeService(const std::string& n, bool failStart = false)
        : name_(n), state_(ServiceState::CREATED), failStart_(failStart) {}
    const std::string& name() const override { return name_; }
    bool start() override {
        ++starts;
        if (failStart_) { state_ = ServiceState::FAILED; return false; }
        state_ = ServiceState::RUNNING;
        return true;
    }
    void stop() override { ++stops; state_ = ServiceState::STOPPED; }
    void pause() override { if (state_ == ServiceState::RUNNING) state_ = ServiceState::PAUSED; }
    void resume() override { if (state_ == ServiceState::PAUSED) state_ = ServiceState::RUNNING; }
    ServiceState state() const override { return state_; }
    int starts = 0;
    int stops = 0;
private:
    std::string  name_;
    ServiceState state_;
    bool         failStart_;
};
}  // namespace

TEST(LifecycleManager, StartsInOrderAndStopsInReverse) {
    ServiceRegistry reg;
    LifecycleManager lm(reg);
    FakeService a("A"), b("B"), c("C");
    std::string err;
    ASSERT_TRUE(lm.add(&a, err));
    ASSERT_TRUE(lm.add(&b, err));
    ASSERT_TRUE(lm.add(&c, err));
    EXPECT_EQ(3u, lm.size());
    ASSERT_TRUE(lm.startAll(err)) << err;
    EXPECT_EQ(ServiceState::RUNNING, c.state());
    lm.stopAll();
    EXPECT_EQ(ServiceState::STOPPED, a.state());
    EXPECT_EQ(1, a.stops);
}

TEST(LifecycleManager, DuplicateAndNullRegistrationsAreRefused) {
    ServiceRegistry reg;
    LifecycleManager lm(reg);
    FakeService a("A"), a2("A");
    std::string err;
    ASSERT_TRUE(lm.add(&a, err));
    EXPECT_FALSE(lm.add(&a2, err));
    EXPECT_FALSE(err.empty());
    EXPECT_FALSE(lm.add(nullptr, err));
    EXPECT_EQ(1u, lm.size());
}

TEST(LifecycleManager, OneFailedServiceDoesNotAbortTheRest) {
    ServiceRegistry reg;
    LifecycleManager lm(reg);
    FakeService good("Good"), bad("Bad", true), also("Also");
    std::string err;
    lm.add(&good, err);
    lm.add(&bad, err);
    lm.add(&also, err);
    EXPECT_FALSE(lm.startAll(err));               // reports the failure
    EXPECT_FALSE(err.empty());
    EXPECT_EQ(ServiceState::RUNNING, good.state());
    EXPECT_EQ(ServiceState::RUNNING, also.state());   // still started
    lm.stopAll();
}

TEST(LifecycleManager, PerServiceControlAndUnknownNames) {
    ServiceRegistry reg;
    LifecycleManager lm(reg);
    FakeService a("A");
    std::string err;
    lm.add(&a, err);
    ASSERT_TRUE(lm.start("A", err)) << err;
    EXPECT_TRUE(lm.pause("A", err));
    EXPECT_EQ(ServiceState::PAUSED, a.state());
    EXPECT_TRUE(lm.resume("A", err));
    EXPECT_TRUE(lm.restart("A", err));
    EXPECT_EQ(1, a.stops);                        // restart = one stop + one start
    EXPECT_EQ(2, a.starts);                       // the explicit start plus the restart
    EXPECT_EQ(ServiceState::RUNNING, a.state());
    EXPECT_TRUE(lm.stop("A", err));

    EXPECT_FALSE(lm.start("Nope", err));
    EXPECT_FALSE(lm.stop("Nope", err));
    EXPECT_FALSE(lm.restart("Nope", err));
    EXPECT_EQ(nullptr, lm.find("Nope"));
    EXPECT_NE(nullptr, lm.find("A"));
}

TEST(LifecycleManager, IllegalTransitionsAreRejected) {
    // The state machine is CREATED -> STARTING -> RUNNING -> {PAUSED} ->
    // STOPPING -> STOPPED, with FAILED reachable from STARTING or RUNNING.
    EXPECT_TRUE(LifecycleManager::isLegalTransition(ServiceState::CREATED, ServiceState::STARTING));
    EXPECT_TRUE(LifecycleManager::isLegalTransition(ServiceState::STARTING, ServiceState::RUNNING));
    EXPECT_TRUE(LifecycleManager::isLegalTransition(ServiceState::RUNNING, ServiceState::PAUSED));
    EXPECT_TRUE(LifecycleManager::isLegalTransition(ServiceState::PAUSED, ServiceState::RUNNING));
    EXPECT_TRUE(LifecycleManager::isLegalTransition(ServiceState::STOPPED, ServiceState::STARTING));
    EXPECT_TRUE(LifecycleManager::isLegalTransition(ServiceState::FAILED, ServiceState::STARTING));
    EXPECT_TRUE(LifecycleManager::isLegalTransition(ServiceState::RUNNING, ServiceState::RUNNING));

    EXPECT_FALSE(LifecycleManager::isLegalTransition(ServiceState::CREATED, ServiceState::PAUSED));
    EXPECT_FALSE(LifecycleManager::isLegalTransition(ServiceState::STOPPED, ServiceState::PAUSED));
    EXPECT_FALSE(LifecycleManager::isLegalTransition(ServiceState::STOPPING, ServiceState::RUNNING));
    EXPECT_NE(nullptr, LifecycleManager::transitionError(ServiceState::STOPPED, ServiceState::STARTING));
}

TEST(LifecycleManager, PausingAStoppedServiceIsRefusedNotUndefined) {
    ServiceRegistry reg;
    LifecycleManager lm(reg);
    FakeService a("A");
    std::string err;
    lm.add(&a, err);
    EXPECT_FALSE(lm.pause("A", err));             // never started
    EXPECT_FALSE(err.empty());
    EXPECT_EQ(ServiceState::CREATED, a.state());
}

TEST(LifecycleManager, StopAllIsSafeToCallTwice) {
    ServiceRegistry reg;
    LifecycleManager lm(reg);
    FakeService a("A");
    std::string err;
    lm.add(&a, err);
    lm.startAll(err);
    lm.stopAll();
    lm.stopAll();
    EXPECT_EQ(ServiceState::STOPPED, a.state());
}

TEST(LifecycleManager, NamesReflectRegistrationOrder) {
    ServiceRegistry reg;
    LifecycleManager lm(reg);
    FakeService a("First"), b("Second");
    std::string err;
    lm.add(&a, err);
    lm.add(&b, err);
    std::vector<std::string> n = lm.names();
    ASSERT_EQ(2u, n.size());
    EXPECT_EQ("First", n[0]);
    EXPECT_EQ("Second", n[1]);
}
