// =====================================================================
//  Unit tests: ServiceRegistry, DiscoveryManager, PubSubManager,
//              RequestResponseManager, IPCManager/IPCClient,
//              MessageRouter, CommunicationManager
// =====================================================================
#include <gtest/gtest.h>

#include <atomic>
#include <mutex>
#include <set>
#include <string>
#include <thread>
#include <vector>

#include <cstring>
#include <sys/socket.h>
#include <sys/un.h>

#include "TestUtil.hpp"
#include "core/CommunicationManager.hpp"
#include "core/DiscoveryManager.hpp"
#include "core/IPCManager.hpp"
#include "core/PubSubManager.hpp"
#include "core/RequestResponseManager.hpp"
#include "core/ServiceRegistry.hpp"

using namespace vsmf;
using namespace vsmftest;

namespace {

ServiceInfo makeInfo(const std::string& name, ServiceKind kind = ServiceKind::Producer) {
    ServiceInfo si;
    si.name = name;
    si.endpoint = name;
    si.kind = kind;
    si.state = ServiceState::RUNNING;
    si.health = HealthState::HEALTHY;
    return si;
}

// A CommunicationManager wired onto a private socket, torn down reliably
// even when a test fails part way through.
struct Fixture {
    ServiceRegistry      reg;
    DiscoveryManager     disc;
    CommunicationManager cm;
    std::string          sock;

    Fixture() : disc(reg), cm(reg), sock(uniquePath("sock", ".sock")) {
        Config cfg;
        cfg.socketPath = sock;
        cfg.requestTimeoutMs = 1000;
        std::string err;
        started = cm.start(cfg, err);
        startErr = err;
    }
    ~Fixture() {
        cm.stop();
        std::remove(sock.c_str());
    }
    bool        started = false;
    std::string startErr;
};

}  // namespace

// ----------------------------------------------------------- ServiceRegistry
TEST(ServiceRegistry, RegistersLooksUpAndRemoves) {
    ServiceRegistry r;
    std::string err;
    ASSERT_TRUE(r.registerService(makeInfo("SpeedSensorService"), err)) << err;
    EXPECT_EQ(1u, r.size());
    EXPECT_TRUE(r.contains("SpeedSensorService"));

    ServiceInfo out;
    ASSERT_TRUE(r.get("SpeedSensorService", out));
    EXPECT_EQ("SpeedSensorService", out.name);
    EXPECT_NE(0u, out.registeredAt);
    EXPECT_FALSE(out.toString().empty());

    EXPECT_TRUE(r.unregisterService("SpeedSensorService"));
    EXPECT_FALSE(r.unregisterService("SpeedSensorService"));   // already gone
    EXPECT_EQ(0u, r.size());
}

TEST(ServiceRegistry, RefusesDuplicatesAndNamelessEntries) {
    ServiceRegistry r;
    std::string err;
    ASSERT_TRUE(r.registerService(makeInfo("A"), err));
    EXPECT_FALSE(r.registerService(makeInfo("A"), err));
    EXPECT_FALSE(err.empty());

    ServiceInfo nameless;
    EXPECT_FALSE(r.registerService(nameless, err));

    ServiceInfo tooLong = makeInfo(std::string(limits::kMaxEndpointName + 1, 'n'));
    EXPECT_FALSE(r.registerService(tooLong, err));
}

TEST(ServiceRegistry, TracksStateHealthAndHeartbeats) {
    ServiceRegistry r;
    std::string err;
    ASSERT_TRUE(r.registerService(makeInfo("A"), err));
    EXPECT_TRUE(r.setState("A", ServiceState::PAUSED));
    EXPECT_TRUE(r.setHealth("A", HealthState::DEGRADED));
    EXPECT_TRUE(r.touchHeartbeat("A", util::steadyNs()));
    EXPECT_TRUE(r.setMissedHeartbeats("A", 2));

    ServiceInfo out;
    ASSERT_TRUE(r.get("A", out));
    EXPECT_EQ(ServiceState::PAUSED, out.state);
    EXPECT_EQ(HealthState::DEGRADED, out.health);
    EXPECT_NE(0u, out.lastHeartbeat);
    EXPECT_EQ(2u, out.missedHeartbeats);

    EXPECT_FALSE(r.setState("Nope", ServiceState::RUNNING));
    EXPECT_FALSE(r.get("Nope", out));
}

TEST(ServiceRegistry, QueriesByKindAndTopic) {
    ServiceRegistry r;
    std::string err;
    ServiceInfo p = makeInfo("SpeedSensorService", ServiceKind::Producer);
    p.publishes.push_back(topics::kSpeed);
    ServiceInfo c = makeInfo("DashboardService", ServiceKind::Consumer);
    c.subscribes.push_back(topics::kSpeed);
    ASSERT_TRUE(r.registerService(p, err));
    ASSERT_TRUE(r.registerService(c, err));

    EXPECT_EQ(1u, r.byKind(ServiceKind::Producer).size());
    EXPECT_EQ(1u, r.byKind(ServiceKind::Consumer).size());
    EXPECT_EQ(0u, r.byKind(ServiceKind::Core).size());
    ASSERT_EQ(1u, r.publishersOf(topics::kSpeed).size());
    EXPECT_EQ("SpeedSensorService", r.publishersOf(topics::kSpeed)[0].name);
    ASSERT_EQ(1u, r.subscribersOf(topics::kSpeed).size());
    EXPECT_TRUE(r.publishersOf("nobody.publishes.this").empty());
    EXPECT_EQ(2u, r.names().size());

    r.clear();
    EXPECT_EQ(0u, r.size());
}

TEST(ServiceRegistry, ListReturnsAnIndependentSnapshot) {
    ServiceRegistry r;
    std::string err;
    r.registerService(makeInfo("A"), err);
    std::vector<ServiceInfo> snap = r.list();
    ASSERT_EQ(1u, snap.size());
    snap[0].name = "mutated";
    ServiceInfo out;
    ASSERT_TRUE(r.get("A", out));
    EXPECT_EQ("A", out.name);
}

TEST(ServiceRegistry, SurvivesConcurrentRegistrationAndQuery) {
    ServiceRegistry r;
    std::atomic<int> ok(0);
    std::vector<std::thread> th;
    for (int t = 0; t < 6; ++t) {
        th.push_back(std::thread([&r, &ok, t] {
            for (int i = 0; i < 200; ++i) {
                std::string err;
                std::string n = "S" + std::to_string(t) + "_" + std::to_string(i);
                if (r.registerService(makeInfo(n), err)) ok.fetch_add(1);
                r.list();
                r.setHealth(n, HealthState::HEALTHY);
            }
        }));
    }
    for (std::size_t i = 0; i < th.size(); ++i) th[i].join();
    EXPECT_EQ(1200, ok.load());
    EXPECT_EQ(1200u, r.size());
}

// ---------------------------------------------------------- DiscoveryManager
TEST(DiscoveryManager, FindsOnlyRunningServicesButLookupSeesAll) {
    ServiceRegistry r;
    DiscoveryManager d(r);
    std::string err;
    ServiceInfo si = makeInfo("BatteryService");
    si.state = ServiceState::PAUSED;
    ASSERT_TRUE(r.registerService(si, err));

    ServiceInfo out;
    EXPECT_FALSE(d.discover("BatteryService", out, err));   // not RUNNING
    EXPECT_FALSE(err.empty());
    EXPECT_TRUE(d.lookup("BatteryService", out));           // but it exists
    EXPECT_EQ(ServiceState::PAUSED, out.state);

    r.setState("BatteryService", ServiceState::RUNNING);
    EXPECT_TRUE(d.discover("BatteryService", out, err)) << err;
    EXPECT_EQ("BatteryService", out.name);
}

TEST(DiscoveryManager, UnknownServiceIsReportedNotInvented) {
    ServiceRegistry r;
    DiscoveryManager d(r);
    ServiceInfo out;
    std::string err;
    EXPECT_FALSE(d.discover("NoSuchService", out, err));
    EXPECT_NE(std::string::npos, err.find("NoSuchService"));
    EXPECT_FALSE(d.lookup("NoSuchService", out));
    EXPECT_FALSE(d.discover("", out, err));
}

TEST(DiscoveryManager, ListsByTopicKindAndAvailability) {
    ServiceRegistry r;
    DiscoveryManager d(r);
    std::string err;
    ServiceInfo p = makeInfo("BatteryService", ServiceKind::Producer);
    p.publishes.push_back(topics::kBattery);
    ServiceInfo c = makeInfo("DiagnosticService", ServiceKind::Consumer);
    c.state = ServiceState::PAUSED;
    r.registerService(p, err);
    r.registerService(c, err);

    EXPECT_EQ(1u, d.discoverByTopic(topics::kBattery).size());
    EXPECT_EQ(1u, d.discoverByKind(ServiceKind::Producer).size());
    std::vector<std::string> avail = d.available();
    ASSERT_EQ(1u, avail.size());                      // the paused one is hidden
    EXPECT_EQ("BatteryService", avail[0]);
}

TEST(DiscoveryManager, WaitForReturnsAsSoonAsAServiceAppears) {
    ServiceRegistry r;
    DiscoveryManager d(r);
    EXPECT_FALSE(d.waitFor("LateService", 50));       // times out cleanly

    std::thread later([&r] {
        sleepMs(120);
        std::string err;
        r.registerService(makeInfo("LateService"), err);
    });
    std::uint64_t t0 = util::steadyNs();
    EXPECT_TRUE(d.waitFor("LateService", 3000));
    double waitedMs = static_cast<double>(util::steadyNs() - t0) / 1e6;
    EXPECT_LT(waitedMs, 2000.0);                      // returned early, not at timeout
    later.join();
}

// ------------------------------------------------------------- PubSubManager
TEST(PubSubManager, SubscribeIsIdempotentAndUnsubscribeWorks) {
    PubSubManager ps;
    std::string err;
    ASSERT_TRUE(ps.subscribe(topics::kSpeed, "DashboardService", err)) << err;
    ASSERT_TRUE(ps.subscribe(topics::kSpeed, "DashboardService", err));   // again
    EXPECT_EQ(1u, ps.subscribers(topics::kSpeed).size());
    EXPECT_TRUE(ps.isSubscribed(topics::kSpeed, "DashboardService"));

    EXPECT_TRUE(ps.unsubscribe(topics::kSpeed, "DashboardService"));
    EXPECT_FALSE(ps.unsubscribe(topics::kSpeed, "DashboardService"));
    EXPECT_TRUE(ps.subscribers(topics::kSpeed).empty());
}

TEST(PubSubManager, RejectsEmptyAndOverlongNames) {
    PubSubManager ps;
    std::string err;
    EXPECT_FALSE(ps.subscribe("", "Dash", err));
    EXPECT_FALSE(ps.subscribe(topics::kSpeed, "", err));
    EXPECT_FALSE(ps.subscribe(std::string(limits::kMaxTopicName + 1, 't'), "Dash", err));
    EXPECT_FALSE(ps.subscribe(topics::kSpeed, std::string(limits::kMaxEndpointName + 1, 'e'), err));
    EXPECT_EQ(0u, ps.subscriptionCount());
}

TEST(PubSubManager, WildcardPatternsMatchByPrefix) {
    EXPECT_TRUE(PubSubManager::topicMatches("vehicle.*", "vehicle.speed"));
    EXPECT_TRUE(PubSubManager::topicMatches("vehicle.*", "vehicle.battery"));
    EXPECT_TRUE(PubSubManager::topicMatches("*", "anything.at.all"));
    EXPECT_FALSE(PubSubManager::topicMatches("vehicle.*", "system.health"));
    EXPECT_TRUE(PubSubManager::topicMatches("vehicle.speed", "vehicle.speed"));
    EXPECT_FALSE(PubSubManager::topicMatches("vehicle.speed", "vehicle.speeding"));

    PubSubManager ps;
    std::string err;
    ASSERT_TRUE(ps.subscribe("vehicle.*", "LoggerService", err));
    ASSERT_TRUE(ps.subscribe(topics::kSpeed, "DashboardService", err));
    std::vector<std::string> s = ps.subscribers(topics::kSpeed);
    EXPECT_EQ(2u, s.size());
    // system.health is outside the vehicle.* family, so nobody hears it.
    EXPECT_EQ(0u, ps.subscribers(topics::kHealth).size());
}

TEST(PubSubManager, UnsubscribeAllCleansUpAServiceEverywhere) {
    PubSubManager ps;
    std::string err;
    ps.subscribe(topics::kSpeed, "Dash", err);
    ps.subscribe(topics::kEngine, "Dash", err);
    ps.subscribe("vehicle.*", "Dash", err);
    ps.subscribe(topics::kSpeed, "Diag", err);

    EXPECT_EQ(3u, ps.unsubscribeAll("Dash"));
    EXPECT_EQ(0u, ps.unsubscribeAll("Dash"));
    ASSERT_EQ(1u, ps.subscribers(topics::kSpeed).size());
    EXPECT_EQ("Diag", ps.subscribers(topics::kSpeed)[0]);
}

TEST(PubSubManager, TopicAndSubscriptionCountsAreConsistent) {
    PubSubManager ps;
    std::string err;
    ps.subscribe(topics::kSpeed, "A", err);
    ps.subscribe(topics::kSpeed, "B", err);
    ps.subscribe(topics::kGps, "A", err);
    EXPECT_EQ(2u, ps.topicCount());
    EXPECT_EQ(3u, ps.subscriptionCount());
    EXPECT_EQ(2u, ps.topics().size());
    ps.clear();
    EXPECT_EQ(0u, ps.topicCount());
    EXPECT_EQ(0u, ps.subscriptionCount());
}

TEST(PubSubManager, ConcurrentSubscribeAndPublishLookupsAreSafe) {
    PubSubManager ps;
    std::atomic<bool> go(true);
    std::thread reader([&ps, &go] {
        while (go.load()) ps.subscribers(topics::kSpeed);
    });
    for (int i = 0; i < 2000; ++i) {
        std::string err;
        ps.subscribe(topics::kSpeed, "S" + std::to_string(i % 50), err);
        if (i % 3 == 0) ps.unsubscribe(topics::kSpeed, "S" + std::to_string(i % 50));
    }
    go.store(false);
    reader.join();
    SUCCEED();
}

// ---------------------------------------------------- RequestResponseManager
TEST(RequestResponseManager, CompletesWhenTheResponseArrives) {
    RequestResponseManager rr;
    rr.setSourceName("Caller");
    Message captured;
    rr.setSender([&captured](const Message& m, std::string&) {
        captured = m;
        return true;
    });

    std::thread responder([&rr, &captured] {
        ASSERT_TRUE(waitUntil([&captured] { return captured.messageId != 0; }, 2000));
        Message resp(MsgType::RESPONSE, "BatteryService", captured.topic, "97.5");
        resp.destination = "Caller";
        resp.correlationId = captured.correlationId;
        EXPECT_TRUE(rr.onResponse(resp));
    });

    Message out;
    std::string err;
    EXPECT_TRUE(rr.request("BatteryService", topics::kBattery, "level?", 3000, out, err)) << err;
    EXPECT_EQ("97.5", out.payload);
    EXPECT_EQ(1u, rr.succeeded());
    EXPECT_EQ(0u, rr.pending());
    responder.join();
}

TEST(RequestResponseManager, TimesOutInsteadOfHangingForever) {
    RequestResponseManager rr;
    rr.setSourceName("Caller");
    rr.setSender([](const Message&, std::string&) { return true; });   // black hole

    Message out;
    std::string err;
    std::uint64_t t0 = util::steadyNs();
    EXPECT_FALSE(rr.request("Ghost", "t", "p", 120, out, err));
    double ms = static_cast<double>(util::steadyNs() - t0) / 1e6;
    EXPECT_GE(ms, 100.0);
    EXPECT_LT(ms, 2000.0);
    EXPECT_EQ(1u, rr.timedOut());
    EXPECT_EQ(0u, rr.pending());          // the slot is reclaimed
    EXPECT_FALSE(err.empty());
}

TEST(RequestResponseManager, SendFailureIsReportedImmediately) {
    RequestResponseManager rr;
    rr.setSourceName("Caller");
    rr.setSender([](const Message&, std::string& e) { e = "socket closed"; return false; });
    Message out;
    std::string err;
    EXPECT_FALSE(rr.request("Any", "t", "p", 5000, out, err));
    EXPECT_NE(std::string::npos, err.find("socket"));
    EXPECT_EQ(1u, rr.failed());
    EXPECT_EQ(0u, rr.pending());
}

TEST(RequestResponseManager, LateAndDuplicateResponsesAreDiscarded) {
    RequestResponseManager rr;
    rr.setSourceName("Caller");
    Message captured;
    rr.setSender([&captured](const Message& m, std::string&) { captured = m; return true; });

    Message out;
    std::string err;
    EXPECT_FALSE(rr.request("Ghost", "t", "p", 60, out, err));    // times out

    Message late(MsgType::RESPONSE, "Ghost", "t", "too late");
    late.destination = "Caller";
    late.correlationId = captured.correlationId;
    EXPECT_FALSE(rr.onResponse(late));
    EXPECT_FALSE(rr.onResponse(late));
    EXPECT_EQ(2u, rr.late());
}

TEST(RequestResponseManager, UnknownCorrelationIdIsIgnored) {
    RequestResponseManager rr;
    rr.setSourceName("Caller");
    Message stray(MsgType::RESPONSE, "Someone", "t", "hello");
    stray.destination = "Caller";
    stray.correlationId = 987654321;
    EXPECT_FALSE(rr.onResponse(stray));
}

TEST(RequestResponseManager, ErrorResponsesSurfaceTheReason) {
    RequestResponseManager rr;
    rr.setSourceName("Caller");
    Message captured;
    rr.setSender([&captured](const Message& m, std::string&) { captured = m; return true; });

    std::thread responder([&rr, &captured] {
        ASSERT_TRUE(waitUntil([&captured] { return captured.messageId != 0; }, 2000));
        Message e(MsgType::ERROR, "BatteryService", captured.topic, "service is paused");
        e.destination = "Caller";
        e.correlationId = captured.correlationId;
        rr.onResponse(e);
    });
    Message out;
    std::string err;
    EXPECT_FALSE(rr.request("BatteryService", "t", "p", 3000, out, err));
    EXPECT_NE(std::string::npos, err.find("paused"));
    responder.join();
}

TEST(RequestResponseManager, CancelAllWakesEveryWaiter) {
    RequestResponseManager rr;
    rr.setSourceName("Caller");
    rr.setSender([](const Message&, std::string&) { return true; });

    std::atomic<int> finished(0);
    std::vector<std::thread> th;
    for (int i = 0; i < 4; ++i) {
        th.push_back(std::thread([&rr, &finished] {
            Message out;
            std::string err;
            rr.request("Ghost", "t", "p", 30000, out, err);   // would block for ages
            finished.fetch_add(1);
        }));
    }
    ASSERT_TRUE(waitUntil([&rr] { return rr.pending() == 4; }, 3000));
    rr.cancelAll("shutting down");
    EXPECT_TRUE(waitUntil([&finished] { return finished.load() == 4; }, 3000));
    for (std::size_t i = 0; i < th.size(); ++i) th[i].join();
    EXPECT_EQ(0u, rr.pending());
}

TEST(RequestResponseManager, PendingTableIsBounded) {
    RequestResponseManager rr;
    rr.setSourceName("Caller");
    rr.setSender([](const Message&, std::string&) { return true; });

    std::atomic<int> refused(0);
    std::vector<std::thread> th;
    const int kThreads = 40;
    for (int i = 0; i < kThreads; ++i) {
        th.push_back(std::thread([&rr, &refused] {
            for (int k = 0; k < 40; ++k) {
                Message out;
                std::string err;
                if (!rr.request("Ghost", "t", "p", 200, out, err) &&
                    err.find("pending") != std::string::npos) {
                    refused.fetch_add(1);
                }
            }
        }));
    }
    for (std::size_t i = 0; i < th.size(); ++i) th[i].join();
    EXPECT_LE(rr.pending(), RequestResponseManager::kMaxPending);
    SUCCEED();
}

// ---------------------------------------------------- IPCManager / IPCClient
TEST(IPCManager, StartsBindsAndCleansUpItsSocket) {
    std::string path = uniquePath("ipc", ".sock");
    IPCManager ipc;
    std::string err;
    ASSERT_TRUE(ipc.start(path, err)) << err;
    EXPECT_TRUE(ipc.isRunning());
    EXPECT_TRUE(util::fileExists(path));
    ipc.stop();
    EXPECT_FALSE(ipc.isRunning());
    EXPECT_FALSE(util::fileExists(path));      // unlinked, no stale socket left
    ipc.stop();                                 // idempotent
}

TEST(IPCManager, RefusesASecondInstanceOnTheSameSocket) {
    std::string path = uniquePath("ipcdup", ".sock");
    IPCManager a, b;
    std::string err;
    ASSERT_TRUE(a.start(path, err)) << err;
    EXPECT_FALSE(b.start(path, err));
    EXPECT_FALSE(err.empty());
    a.stop();
}

TEST(IPCManager, TakesOverAStaleSocketFile) {
    std::string path = uniquePath("ipcstale", ".sock");
    ASSERT_TRUE(writeFile(path, ""));           // a leftover file, nobody listening
    IPCManager ipc;
    std::string err;
    EXPECT_TRUE(ipc.start(path, err)) << err;
    ipc.stop();
}

TEST(IPCManager, RejectsAnImpossiblyLongSocketPath) {
    IPCManager ipc;
    std::string err;
    std::string path = "/tmp/" + std::string(200, 'p') + ".sock";
    EXPECT_FALSE(ipc.start(path, err));         // sun_path is 108 bytes
    EXPECT_FALSE(err.empty());
}

TEST(IPCManager, DeliversToNamedEndpointsAndReportsUnknownOnes) {
    std::string path = uniquePath("ipcdeliver", ".sock");
    IPCManager ipc;
    std::string err;
    ASSERT_TRUE(ipc.start(path, err)) << err;

    IPCClient client;
    std::mutex mu;
    std::vector<Message> got;
    client.setHandler([&mu, &got](const Message& m) {
        std::lock_guard<std::mutex> lk(mu);
        got.push_back(m);
    });
    ASSERT_TRUE(client.connect(path, "DashboardService", 1000, err)) << err;
    ASSERT_TRUE(waitUntil([&ipc] { return ipc.hasEndpoint("DashboardService"); }, 2000));
    EXPECT_EQ(1u, ipc.connectionCount());
    EXPECT_EQ(1u, ipc.endpointNames().size());

    Message m(MsgType::PUBLISH, "SpeedSensorService", topics::kSpeed, "{\"speed\":42}");
    ASSERT_TRUE(ipc.deliver("DashboardService", m, err)) << err;
    EXPECT_TRUE(waitUntil([&mu, &got] {
        std::lock_guard<std::mutex> lk(mu);
        return !got.empty();
    }, 2000));
    {
        std::lock_guard<std::mutex> lk(mu);
        EXPECT_EQ("{\"speed\":42}", got[0].payload);
    }

    EXPECT_FALSE(ipc.deliver("NoSuchEndpoint", m, err));
    EXPECT_FALSE(err.empty());

    client.disconnect();
    EXPECT_TRUE(waitUntil([&ipc] { return ipc.connectionCount() == 0; }, 2000));
    ipc.stop();
}

TEST(IPCManager, RefusesDuplicateEndpointNames) {
    std::string path = uniquePath("ipcname", ".sock");
    IPCManager ipc;
    std::string err;
    ASSERT_TRUE(ipc.start(path, err)) << err;

    IPCClient a, b;
    ASSERT_TRUE(a.connect(path, "SameName", 1000, err)) << err;
    ASSERT_TRUE(waitUntil([&ipc] { return ipc.hasEndpoint("SameName"); }, 2000));
    b.connect(path, "SameName", 1000, err);
    // The broker drops the impostor: exactly one connection survives.
    EXPECT_TRUE(waitUntil([&ipc] { return ipc.connectionCount() <= 1; }, 2000));
    a.disconnect();
    b.disconnect();
    ipc.stop();
}

TEST(IPCClient, ConnectFailsCleanlyWhenNobodyIsListening) {
    IPCClient c;
    std::string err;
    EXPECT_FALSE(c.connect("/tmp/vsmf_no_broker_here_8123.sock", "X", 300, err));
    EXPECT_FALSE(err.empty());
    EXPECT_FALSE(c.connected());
    EXPECT_FALSE(c.send(Message(MsgType::PUBLISH, "X", "t", "p"), err));
    c.disconnect();                              // safe on a dead client
}

TEST(IPCClient, SurvivesTheBrokerDisappearing) {
    std::string path = uniquePath("ipcdead", ".sock");
    IPCManager ipc;
    std::string err;
    ASSERT_TRUE(ipc.start(path, err)) << err;
    IPCClient c;
    // A handler makes this an asynchronous client, so a background reader
    // notices the peer vanishing. Handler-less clients (the console) find
    // out on their next send() or receive() instead.
    c.setHandler([](const Message&) {});
    ASSERT_TRUE(c.connect(path, "Client", 1000, err)) << err;
    ipc.stop();
    EXPECT_TRUE(waitUntil([&c] { return !c.connected(); }, 3000));
    Message m(MsgType::PUBLISH, "Client", "t", "p");
    c.send(m, err);                               // must not raise SIGPIPE
    c.disconnect();
    SUCCEED();
}

TEST(IPCManager, HostileFrameLengthIsRefusedAndTheBrokerSurvives) {
    std::string path = uniquePath("ipchostile", ".sock");
    IPCManager ipc;
    std::string err;
    ASSERT_TRUE(ipc.start(path, err)) << err;

    // Raw socket, no HELLO, claiming a gigantic payload.
    int fd = ::socket(AF_UNIX, SOCK_STREAM, 0);
    ASSERT_GE(fd, 0);
    struct sockaddr_un addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    std::strncpy(addr.sun_path, path.c_str(), sizeof(addr.sun_path) - 1);
    ASSERT_EQ(0, ::connect(fd, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)));
    unsigned char hostile[4] = {0x7F, 0xFF, 0xFF, 0xFF};      // ~2 GiB
    EXPECT_GT(util::writeAll(fd, hostile, 4), 0);
    util::closeQuiet(fd);

    // The broker must still be usable afterwards.
    IPCClient good;
    EXPECT_TRUE(waitUntil([&] {
        std::string e;
        return good.connect(path, "Good", 500, e);
    }, 3000));
    EXPECT_TRUE(ipc.isRunning());
    good.disconnect();
    ipc.stop();
}

TEST(IPCManager, GarbageAfterHelloIsCountedNotFatal) {
    std::string path = uniquePath("ipcjunk", ".sock");
    IPCManager ipc;
    std::string err;
    ASSERT_TRUE(ipc.start(path, err)) << err;

    int fd = ::socket(AF_UNIX, SOCK_STREAM, 0);
    ASSERT_GE(fd, 0);
    struct sockaddr_un addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    std::strncpy(addr.sun_path, path.c_str(), sizeof(addr.sun_path) - 1);
    ASSERT_EQ(0, ::connect(fd, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)));

    unsigned char junk[16] = {0, 0, 0, 8, 9, 9, 9, 9, 9, 9, 9, 9, 0, 0, 0, 0};
    util::writeAll(fd, junk, sizeof(junk));
    sleepMs(100);
    util::closeQuiet(fd);
    EXPECT_TRUE(ipc.isRunning());
    ipc.stop();
}

// ------------------------------------------- CommunicationManager + Router
TEST(CommunicationManager, StartsAndCreatesUniqueEndpoints) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;
    EndpointPtr a = f.cm.createEndpoint("A", err);
    ASSERT_TRUE(a) << err;
    EXPECT_TRUE(a->isOpen());
    EXPECT_FALSE(f.cm.createEndpoint("A", err));      // duplicate refused
    f.cm.destroyEndpoint("A");
    f.cm.destroyEndpoint("A");                        // idempotent
    EndpointPtr again = f.cm.createEndpoint("A", err);
    EXPECT_TRUE(again) << err;                        // name is reusable
}

TEST(MessageRouter, PublishReachesEverySubscriberButNotThePublisher) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;

    EndpointPtr pub = f.cm.createEndpoint("SpeedSensorService", err);
    EndpointPtr s1  = f.cm.createEndpoint("DashboardService", err);
    EndpointPtr s2  = f.cm.createEndpoint("DiagnosticService", err);
    ASSERT_TRUE(pub && s1 && s2) << err;

    std::atomic<int> n1(0), n2(0), nPub(0);
    s1->setHandler([&n1](const Message&) { n1.fetch_add(1); });
    s2->setHandler([&n2](const Message&) { n2.fetch_add(1); });
    pub->setHandler([&nPub](const Message&) { nPub.fetch_add(1); });

    ASSERT_TRUE(s1->subscribe(topics::kSpeed, err)) << err;
    ASSERT_TRUE(s2->subscribe(topics::kSpeed, err)) << err;
    ASSERT_TRUE(pub->subscribe(topics::kSpeed, err)) << err;   // even self-subscribed

    ASSERT_TRUE(pub->publish(topics::kSpeed, "{\"speed\":50}", Priority::NORMAL, err)) << err;
    EXPECT_TRUE(waitUntil([&] { return n1.load() == 1 && n2.load() == 1; }, 3000));
    sleepMs(100);
    EXPECT_EQ(0, nPub.load());        // a publisher never hears its own echo
    EXPECT_GT(f.cm.router().delivered(), 0u);
}

TEST(MessageRouter, PublishWithNoSubscribersIsCountedNotAnError) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;
    EndpointPtr pub = f.cm.createEndpoint("Lonely", err);
    ASSERT_TRUE(pub) << err;
    EXPECT_TRUE(pub->publish("nobody.listens", "{}", Priority::LOW, err)) << err;
    sleepMs(150);
    EXPECT_EQ(0u, f.cm.router().failed());
}

TEST(MessageRouter, WildcardSubscribersReceiveTheWholeFamily) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;
    EndpointPtr pub = f.cm.createEndpoint("Pub", err);
    EndpointPtr log = f.cm.createEndpoint("LoggerEndpoint", err);
    ASSERT_TRUE(pub && log) << err;

    std::atomic<int> n(0);
    log->setHandler([&n](const Message&) { n.fetch_add(1); });
    ASSERT_TRUE(log->subscribe("vehicle.*", err)) << err;

    pub->publish(topics::kSpeed, "{}", Priority::NORMAL, err);
    pub->publish(topics::kBattery, "{}", Priority::NORMAL, err);
    pub->publish(topics::kHealth, "{}", Priority::NORMAL, err);   // not vehicle.*
    EXPECT_TRUE(waitUntil([&n] { return n.load() == 2; }, 3000));
    sleepMs(100);
    EXPECT_EQ(2, n.load());
}

TEST(MessageRouter, RequestAndResponseTravelOverTheSocket) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;
    EndpointPtr caller = f.cm.createEndpoint("VehicleControlService", err);
    EndpointPtr server = f.cm.createEndpoint("BatteryService", err);
    ASSERT_TRUE(caller && server) << err;

    server->setHandler([&server](const Message& m) {
        if (m.type != MsgType::REQUEST) return;
        std::string e;
        server->respond(m, "{\"battery\":88.5}", e);
    });

    Message out;
    ASSERT_TRUE(caller->request("BatteryService", topics::kBattery, "level?", 3000, out, err)) << err;
    EXPECT_EQ("{\"battery\":88.5}", out.payload);
    EXPECT_EQ("BatteryService", out.sourceService);
}

TEST(MessageRouter, RequestToAnUnknownEndpointFailsFast) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;
    EndpointPtr caller = f.cm.createEndpoint("Caller", err);
    ASSERT_TRUE(caller) << err;

    Message out;
    std::uint64_t t0 = util::steadyNs();
    EXPECT_FALSE(caller->request("GhostService", "t", "p", 5000, out, err));
    double ms = static_cast<double>(util::steadyNs() - t0) / 1e6;
    EXPECT_LT(ms, 2000.0);            // an error came back, we did not wait out the timeout
    EXPECT_FALSE(err.empty());
}

TEST(MessageRouter, AHandlerMayIssueItsOwnRequestWithoutDeadlocking) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;
    EndpointPtr front = f.cm.createEndpoint("FrontService", err);
    EndpointPtr back  = f.cm.createEndpoint("BackService", err);
    EndpointPtr client = f.cm.createEndpoint("Client", err);
    ASSERT_TRUE(front && back && client) << err;

    back->setHandler([&back](const Message& m) {
        if (m.type != MsgType::REQUEST) return;
        std::string e;
        back->respond(m, "inner-answer", e);
    });
    // The front service answers only after calling the back service: this
    // is the nested-request case that must not stall the reader thread.
    front->setHandler([&front](const Message& m) {
        if (m.type != MsgType::REQUEST) return;
        Message inner;
        std::string e;
        bool ok = front->request("BackService", "t", "ask", 2000, inner, e);
        front->respond(m, ok ? ("outer:" + inner.payload) : ("failed:" + e), e);
    });

    Message out;
    ASSERT_TRUE(client->request("FrontService", "t", "go", 5000, out, err)) << err;
    EXPECT_EQ("outer:inner-answer", out.payload);
}

TEST(MessageRouter, RespondErrorReachesTheCallerAsAFailure) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;
    EndpointPtr caller = f.cm.createEndpoint("Caller", err);
    EndpointPtr server = f.cm.createEndpoint("Server", err);
    ASSERT_TRUE(caller && server) << err;

    server->setHandler([&server](const Message& m) {
        if (m.type != MsgType::REQUEST) return;
        std::string e;
        server->respondError(m, "sensor offline", e);
    });

    Message out;
    EXPECT_FALSE(caller->request("Server", "t", "p", 3000, out, err));
    EXPECT_NE(std::string::npos, err.find("sensor offline"));
}

TEST(MessageRouter, PingIsAnsweredEvenWhileTheHandlerIsBusy) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;
    EndpointPtr prober = f.cm.createEndpoint("Prober", err);
    EndpointPtr busy   = f.cm.createEndpoint("BusyService", err);
    ASSERT_TRUE(prober && busy) << err;

    std::atomic<bool> release(false);
    busy->setHandler([&release](const Message& m) {
        if (m.type == MsgType::REQUEST) waitUntil([&] { return release.load(); }, 5000);
    });

    // Occupy the request thread, then prove liveness anyway.
    std::thread blocker([&prober] {
        Message out;
        std::string e;
        prober->request("BusyService", "t", "block", 4000, out, e);
    });
    sleepMs(150);
    EXPECT_TRUE(prober->ping("BusyService", 2000, err)) << err;
    release.store(true);
    blocker.join();
}

TEST(MessageRouter, EndpointCloseUnsubscribesAndWakesWaiters) {
    Fixture f;
    ASSERT_TRUE(f.started) << f.startErr;
    std::string err;
    EndpointPtr ep = f.cm.createEndpoint("Temp", err);
    ASSERT_TRUE(ep) << err;
    ASSERT_TRUE(ep->subscribe(topics::kSpeed, err));
    EXPECT_TRUE(f.cm.pubsub().isSubscribed(topics::kSpeed, "Temp"));
    f.cm.destroyEndpoint("Temp");
    EXPECT_FALSE(f.cm.pubsub().isSubscribed(topics::kSpeed, "Temp"));
}

TEST(CommunicationManager, StopIsSafeWithLiveEndpointsAndCalledTwice) {
    std::string sock = uniquePath("cmstop", ".sock");
    ServiceRegistry reg;
    CommunicationManager cm(reg);
    Config cfg;
    cfg.socketPath = sock;
    std::string err;
    ASSERT_TRUE(cm.start(cfg, err)) << err;
    EndpointPtr a = cm.createEndpoint("A", err);
    EndpointPtr b = cm.createEndpoint("B", err);
    ASSERT_TRUE(a && b) << err;
    cm.stop();
    cm.stop();
    EXPECT_FALSE(cm.isRunning());
    std::remove(sock.c_str());
}
