# VSMF — Edge cases and failure handling

Every item below is implemented in the source and, unless noted, exercised by a
named test in `tests/`.

## 1. Transport (IPCManager, IPCClient)

| Situation | Handling |
|---|---|
| `read`/`write`/`poll` interrupted by a signal | EINTR retried everywhere; no partial-operation loss |
| Peer disappears mid-write | SIGPIPE ignored process-wide; EPIPE handled as a normal disconnect |
| Short read / short write | full-transfer loops, never assume one syscall moved everything |
| Stale socket file from a crashed run | probed with `connect()`; if nothing is listening it is unlinked and rebound |
| A second instance on the same socket | refused with a clear message instead of silently stealing traffic |
| Socket path longer than `sun_path` (108 bytes) | validated up front and rejected |
| Hostile length prefix (e.g. 2 GiB) | capped at 1 MiB; the connection is dropped and the broker survives |
| Garbage after HELLO | counted as malformed, connection dropped, broker unaffected |
| Traffic before HELLO | anonymous peers cannot inject anything |
| Forged `sourceService` | the broker stamps provenance from the connection, not the frame |
| Duplicate endpoint name | the impostor is refused; the original keeps its connection |
| `EMFILE` / `ENFILE` on accept | back-off instead of a CPU-burning spin |
| Blocking write to a wedged peer | bounded by poll timeouts |
| Shutdown with live peers | `shutdown()` wakes every reader, all threads joined, socket unlinked |
| Socket permissions | created mode 0600 |

## 2. Message and wire format

- Truncation at *every* byte offset is rejected rather than misparsed (tested
  exhaustively, not by sampling).
- Unknown wire version, unknown message type and unknown priority are all
  rejected before any field is trusted.
- Over-long fields are refused at serialization, so a bad frame is never put on
  the wire in the first place.
- Binary payloads survive intact: nothing assumes text.
- An empty `sourceService` is invalid — a nameless frame cannot be routed or
  answered.
- `toLogString()` is single-line and length-bounded, so a huge payload cannot
  flood or corrupt the log.

## 3. Configuration and JSON

- Missing file, unreadable file, corrupt file → documented defaults, boot
  continues, warning logged.
- Out-of-range values clamped (negative speed limit, 100 000 threads, zero
  heartbeat interval, 900 % battery limit) with a warning naming the key.
- Wrong-typed values ignored in favour of the default.
- UTF-8 BOM tolerated.
- Hot reload acts only on an mtime change; a half-written file (an editor
  mid-save) leaves the last good configuration in place.
- JSON parser: 64-level recursion guard against stack exhaustion, surrogate
  pairs handled, lone surrogates rejected, trailing commas rejected, leading
  zeros rejected, NaN/ERANGE numbers rejected.
- `get()` returns an independent snapshot, so a reload cannot change values
  under a caller mid-decision.

## 4. Thread pool

- Never blocks a publisher: the queue is bounded, overflow is dropped and
  counted.
- CRITICAL work evicts the oldest LOW item rather than being dropped itself.
- A task that throws is contained; the worker survives and the failure is
  counted.
- `stop()` is idempotent, drains or discards on request, and detaches rather
  than attempting to join itself if called from a worker.
- Thread creation failure yields a partial pool rather than a dead process.
- `submit()` before `start()` or after `stop()` is refused, not silently lost.

## 5. Logger

- Asynchronous and bounded: under flood the oldest entries are dropped and
  counted; publishers are never blocked.
- Rotates to `.log.1` at the configured size; a failed rotation keeps appending
  rather than losing the stream.
- WARN and above are flushed immediately.
- Unusable log directory → stderr fallback, boot continues.
- Writes before `start()` and after `stop()` are written straight through and
  flushed, reopening the stream if it was closed, because there is no worker
  thread then to drain the buffer.
- `flush()` waits for the queue to empty **and** for the entry already in the
  worker's hand, so a caller that logs and immediately tails the file sees its
  own line.
- Control characters are replaced, so one entry is always exactly one line.
- Bounded 2-second drain: a wedged filesystem cannot hang shutdown.

## 6. Request / response

- Hard timeouts; the pending slot is always reclaimed.
- Late responses counted and discarded; duplicates ignored.
- Unknown correlation ids ignored.
- Pending table capped at 1024 entries.
- `cancelAll()` wakes every waiter at shutdown instead of leaving threads to
  time out one by one.
- An undeliverable REQUEST gets an immediate ERROR, so the caller fails fast
  instead of waiting out its full timeout.
- A paused service answers with an error rather than leaving the caller hanging.
- **A handler may issue its own request without deadlocking** — see
  `ARCHITECTURE.md` §3.

## 7. Publish / subscribe

- The subscriber list is copied before delivery: no iterator invalidation, and
  no lock held while a callback runs.
- `subscribe()` is idempotent.
- Prefix wildcards (`vehicle.*`) alongside exact topics.
- A publisher never receives its own message, even if subscribed to the topic.
- Publishing with no subscribers is counted, not an error.
- Endpoint teardown unsubscribes it everywhere.

## 8. Services

- `start()` and `stop()` are idempotent; a stopped service can be restarted and
  its endpoint name is reusable.
- Starting with the transport down fails cleanly into FAILED with a recorded
  reason, rather than throwing.
- A service registry entry survives `stop()` with state STOPPED, so the console
  can still list and restart it; discovery filters on RUNNING regardless.
- `stop()` called from inside `onTick()` detaches instead of self-joining.
- All service hooks are wrapped: a handler that throws cannot tear down the
  transport.
- Malformed payloads (empty, non-JSON, wrong types, `1e400`) are ignored without
  raising a false alert and without stopping the consumer.
- Diagnostic alerts are edge-triggered with 2 % hysteresis and a 64-entry
  bounded history, so a value flapping across a threshold produces one alert per
  crossing rather than an unbounded storm.

## 9. Health and lifecycle

- Heartbeats are real PING/PONG traffic, answered at transport level so a busy
  service still proves liveness.
- A registered service with no live endpoint is marked UNHEALTHY after the
  configured number of missed beats, not on the first miss.
- Illegal state transitions are rejected with a specific reason (pausing a
  service that was never started, resuming a stopped one).
- One failed service does not abort the start of the rest; the failure is
  reported and the remaining services still come up.
- `stopAll()` is safe to call twice.

## 10. Performance measurement

- Nonsense latencies (over 60 s, clock jumps) discarded.
- Division-by-zero and counter-reset guards throughout.
- `/proc/self/stat` parsed from the **last** `)`, so a process name containing
  spaces or brackets cannot shift the field offsets.
- A throwing report sink is contained.
- `snapshot()` falls back to since-start averages and a live RSS read before the
  first sampling window completes.

## 11. Process level

- SIGINT, SIGTERM and SIGHUP handled with an async-signal-safe handler that only
  sets a flag; all real work happens on the main thread.
- `SA_RESTART` deliberately not set, so `poll()` returns EINTR and loops notice
  the shutdown request promptly.
- The dashboard detects a non-TTY stdout and drops ANSI escapes.
- `--duration` gives a deterministic, non-interactive run for CI.
- Unknown options and bad argument values exit with `EX_USAGE` (64) and a
  message, never with a stack trace.
- The console reports clearly when no broker is running, and reconnects if the
  connection drops between commands.
