# VSMF Architecture

## 1. Shape of the system

VSMF is a broker-based service-oriented middleware. One process hosts the broker
and the vehicle services; a second process (`./vsmf --console`) attaches to the
same Unix domain socket as an ordinary peer. Nothing in the design privileges
the in-process services: they reach each other through exactly the same
transport a remote console uses, which is what makes the two-terminal demo an
honest demonstration rather than a simulation.

```
                        +---------------------------+
                        |        IPCManager         |   /tmp/vsmf/vsmf.sock
                        |   (broker, accept loop,   |
                        |    one reader per peer)   |
                        +-------------+-------------+
                                      |
                        +-------------+-------------+
                        |      MessageRouter        |
                        |  PubSubManager | Registry |
                        +-------------+-------------+
                                      |
     +-------------+-------------+----+----+-------------+-------------+
     |             |             |         |             |             |
  Speed        Engine        Battery      GPS       Dashboard      Diagnostic
  Sensor       Sensor        Service    Service      Service        Service
                                                          VehicleControlService
                                                          ControlService (console)
```

Each service owns an `Endpoint`: a client connection to the broker plus its own
`RequestResponseManager`. `CommunicationManager` is the facade that creates and
destroys endpoints and owns the broker, the router and the subscription table.

## 2. Components

**Interface** — `IService`: `start / stop / pause / resume / state`. Everything
that participates in the lifecycle implements it, including the logger.

**Data** — `Message` (id, correlation id, wall and monotonic timestamps, type,
priority, source, destination, topic, payload) and `DataGenerator`, a correlated
vehicle model: speed follows a target through a first-order lag, gear follows
speed, RPM follows gear ratio, coolant follows engine load, the pack drains with
demand, and position integrates from the speed. One model step feeds all four
producer topics so every sample describes the same instant.

**Core** — `ServiceRegistry` (who exists, in what state, how healthy),
`DiscoveryManager` (`discover()` returns only RUNNING services, `lookup()` sees
every state, `waitFor()` blocks until a dependency appears),
`CommunicationManager`, `MessageRouter`, `PubSubManager` (exact topics plus
`prefix.*` wildcards), `RequestResponseManager` (correlation, timeouts,
cancellation) and `IPCManager` (`IPCManager` broker + `IPCClient` peer).

**Execution** — `ThreadPool`: fixed workers, bounded priority queue, FIFO within
a priority class.

**Producers** — SpeedSensor, EngineSensor, Battery, GPS. SpeedSensor owns the
model step; the others read the current sample.

**Consumers** — Dashboard (aggregates every vehicle topic), Diagnostic
(thresholds from configuration), VehicleControl (discovers BatteryService and
calls it, enters limp mode on a flat pack).

**Support** — LoggerService (four channels, asynchronous, rotating),
ConfigManager (load, validate, clamp, hot reload), HealthMonitor (PING/PONG
heartbeats), LifecycleManager (ordered start, reverse stop, legal transitions),
PerformanceMonitor (throughput, latency distribution, CPU, RSS, queue depth).

## 3. Threading model

| Thread | Count | Work |
|---|---|---|
| main | 1 | boot, dashboard rendering, signal handling, shutdown |
| broker accept | 1 | `accept()` and connection reaping |
| broker reader | one per peer | frame decoding and routing |
| endpoint reader | one per endpoint | inbound frames for that service |
| endpoint request | one per endpoint | inbound REQUEST handling, serial |
| service worker | one per periodic service | `onTick()` |
| thread pool | `thread_pool_size` | PUBLISH delivery |
| logger | 1 | draining the log queue |
| performance sampler | 1 | periodic snapshot |
| health monitor | 1 | heartbeat rounds |

### Why REQUEST does not run on the pool

Two designs were tried and rejected before the current one.

*Everything on the pool* deadlocks a small pool: a request handler that itself
issues a request occupies a worker while waiting for a reply whose delivery
needs a worker.

*REQUEST inline on the endpoint's reader thread* fixes that but creates a worse
bug, and the console found it immediately: the ControlService `battery` command
issues a request from inside its own request handler, so the reader thread that
must deliver the response is the very thread blocked waiting for it. Guaranteed
timeout.

The design that holds: **each endpoint gets one dedicated serial request
thread** with a bounded queue. The reader thread only decodes and dispatches, so
it is always free to complete a pending request. Nested calls across services
work; only a genuine request *cycle* (A calls B which calls A) can stall, and
that is an application-level error rather than a middleware limitation.
Responses, errors and PONGs complete inline on the reader thread — they never
queue anywhere.

### Heartbeats

`HealthMonitor` sends real PING frames through `RequestResponseManager` and
waits for PONG. `Endpoint::onFrame` answers PING at transport level, before the
service handler is consulted, so a service busy inside a long callback still
proves it is alive. Liveness and responsiveness are therefore measured
separately, which is the distinction that matters when deciding whether to
restart something.

## 4. Wire format

```
frame   := u32 payloadLen (big endian) || payload
payload := u16 version | u8 type | u8 priority
         | u64 messageId | u64 correlationId
         | u64 timestampNs | u64 steadyStampNs
         | u32 len || bytes    (sourceService)
         | u32 len || bytes    (destination)
         | u32 len || bytes    (topic)
         | u32 len || bytes    (payload)
```

Every field is length-prefixed and bounds-checked on the way in: 1 MiB per
frame, 64 KiB per string, 64 bytes per endpoint name, 128 bytes per topic. The
version field is checked before anything else is trusted, so a future format
change is a clean rejection rather than a misparse.

Two timestamps are carried deliberately. The wall clock is for logs and is
allowed to jump; the monotonic stamp is what latency is computed from, so an NTP
step cannot corrupt the performance figures.

`serialize()` produces a complete frame including the length prefix;
`deserialize()` takes the body, because the transport consumes the prefix to
decide how many bytes to read. `deserializeFrame()` exists for callers holding
a whole frame and validates the prefix against the buffer length.

## 5. Boot and shutdown

Boot: configuration → logger → thread pool → performance counters → transport
and registry → data generator → **consumers** → **producers** → health monitor.
Consumers start first so that no early sample is published to an empty
subscriber list.

Shutdown is exactly the reverse: health monitor (stop probing before endpoints
disappear) → performance sampler → services in reverse registration order →
transport (socket closed and unlinked) → thread pool drained → logger flushed
and stopped.

`createEndpoint()` waits for the broker to acknowledge the HELLO before
returning. Without that wait a service that starts and immediately calls another
gets "no such endpoint" purely because of start-up ordering — a race that showed
up in testing and is now closed at the source rather than papered over with a
retry in every caller.

## 6. Configuration and JSON

The JSON parser is hand-written and dependency-free. A middleware that fails to
boot because a header was missing on the target image is not acceptable, and the
configuration surface is small enough that a full library is not warranted. The
parser is strict where strictness protects the operator (no trailing commas, no
leading zeros, no lone surrogates, 64-level recursion cap) and tolerant where
tolerance costs nothing (a UTF-8 BOM is skipped).

Configuration failures never stop the vehicle software. A missing file, a
corrupt file, a wrong-typed value or an out-of-range value produces a documented
default plus a warning in `middleware.log`. Hot reload only acts on an mtime
change, and a half-written file leaves the last good configuration in place.

## 7. Performance measurement

`PerformanceMonitor` keeps atomic counters plus a 512-entry latency reservoir
for the p95. Latencies above 60 seconds are discarded as clock artefacts rather
than allowed to poison the average. CPU comes from `/proc/self/stat`, parsed
from the **last** `)` so that a process name containing spaces or brackets
cannot shift the field offsets. When the sampler has not produced a window yet,
`snapshot()` falls back to since-start averages and a live RSS read, so an early
`metrics` command returns real numbers instead of zeroes.
