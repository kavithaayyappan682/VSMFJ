#include "data/Message.hpp"

#include <atomic>
#include <cstring>
#include <sstream>

#include "common/Utils.hpp"

namespace vsmf {

namespace {

std::atomic<std::uint64_t> g_counter(1);

void putU16(std::vector<std::uint8_t>& b, std::uint16_t v) {
    b.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
    b.push_back(static_cast<std::uint8_t>(v & 0xFF));
}
void putU32(std::vector<std::uint8_t>& b, std::uint32_t v) {
    for (int i = 3; i >= 0; --i) b.push_back(static_cast<std::uint8_t>((v >> (i * 8)) & 0xFF));
}
void putU64(std::vector<std::uint8_t>& b, std::uint64_t v) {
    for (int i = 7; i >= 0; --i) b.push_back(static_cast<std::uint8_t>((v >> (i * 8)) & 0xFF));
}

struct Reader {
    const std::uint8_t* p;
    std::size_t n;
    std::size_t i;
    bool ok;
    std::string err;

    Reader(const std::uint8_t* buf, std::size_t len) : p(buf), n(len), i(0), ok(true) {}

    bool need(std::size_t k) {
        if (!ok) return false;
        if (i + k > n) { ok = false; err = "frame truncated"; return false; }
        return true;
    }
    std::uint16_t u16() {
        if (!need(2)) return 0;
        std::uint16_t v = static_cast<std::uint16_t>((p[i] << 8) | p[i + 1]);
        i += 2;
        return v;
    }
    std::uint8_t u8() {
        if (!need(1)) return 0;
        return p[i++];
    }
    std::uint32_t u32() {
        if (!need(4)) return 0;
        std::uint32_t v = 0;
        for (int k = 0; k < 4; ++k) v = (v << 8) | p[i + static_cast<std::size_t>(k)];
        i += 4;
        return v;
    }
    std::uint64_t u64() {
        if (!need(8)) return 0;
        std::uint64_t v = 0;
        for (int k = 0; k < 8; ++k) v = (v << 8) | p[i + static_cast<std::size_t>(k)];
        i += 8;
        return v;
    }
    std::string str() {
        std::uint32_t len = u32();
        if (!ok) return std::string();
        if (len > limits::kMaxStringBytes) { ok = false; err = "string field too large"; return std::string(); }
        if (!need(len)) return std::string();
        std::string s(reinterpret_cast<const char*>(p + i), len);
        i += len;
        return s;
    }
};

}  // namespace

Message::Message(MsgType t, const std::string& src, const std::string& topic_,
                 const std::string& payload_, Priority p)
    : messageId(nextId()),
      timestamp(util::wallNs()),
      steadyStamp(util::steadyNs()),
      type(t),
      priority(p),
      sourceService(src),
      topic(topic_),
      payload(payload_) {}

std::uint64_t Message::nextId() noexcept {
    return g_counter.fetch_add(1, std::memory_order_relaxed);
}

bool Message::isValid(std::string& why) const {
    // Every frame must say who sent it: the broker uses this to stamp
    // provenance and a nameless frame cannot be routed or answered.
    if (sourceService.empty()) { why = "empty sourceService"; return false; }
    if (sourceService.size() > limits::kMaxEndpointName) { why = "sourceService too long"; return false; }
    if (destination.size()   > limits::kMaxEndpointName) { why = "destination too long"; return false; }
    if (topic.size()         > limits::kMaxTopicName)    { why = "topic too long"; return false; }
    if (payload.size()       > limits::kMaxStringBytes)  { why = "payload too large"; return false; }
    if (type == MsgType::PUBLISH && topic.empty())       { why = "PUBLISH without topic"; return false; }
    if ((type == MsgType::REQUEST || type == MsgType::RESPONSE) && destination.empty()) {
        why = "REQUEST/RESPONSE without destination";
        return false;
    }
    return true;
}

bool Message::serialize(std::vector<std::uint8_t>& out, std::string& err) const {
    if (!isValid(err)) return false;

    std::vector<std::uint8_t> body;
    body.reserve(64 + sourceService.size() + destination.size() + topic.size() + payload.size());
    putU16(body, limits::kWireVersion);
    body.push_back(static_cast<std::uint8_t>(type));
    body.push_back(static_cast<std::uint8_t>(priority));
    putU64(body, messageId);
    putU64(body, correlationId);
    putU64(body, timestamp);
    putU64(body, steadyStamp);

    const std::string* fields[4] = {&sourceService, &destination, &topic, &payload};
    for (int k = 0; k < 4; ++k) {
        putU32(body, static_cast<std::uint32_t>(fields[k]->size()));
        body.insert(body.end(), fields[k]->begin(), fields[k]->end());
    }

    if (body.size() > limits::kMaxFrameBytes) { err = "frame exceeds maximum size"; return false; }
    putU32(out, static_cast<std::uint32_t>(body.size()));
    out.insert(out.end(), body.begin(), body.end());
    return true;
}

bool Message::deserializeFrame(const std::uint8_t* frame, std::size_t len,
                               Message& out, std::string& err) {
    err.clear();
    if (frame == nullptr) { err = "null buffer"; return false; }
    if (len < 4) { err = "frame too short for a length prefix"; return false; }
    std::uint32_t declared = (static_cast<std::uint32_t>(frame[0]) << 24) |
                             (static_cast<std::uint32_t>(frame[1]) << 16) |
                             (static_cast<std::uint32_t>(frame[2]) << 8)  |
                              static_cast<std::uint32_t>(frame[3]);
    if (declared != len - 4) { err = "length prefix disagrees with buffer size"; return false; }
    return deserialize(frame + 4, len - 4, out, err);
}

bool Message::deserialize(const std::uint8_t* data, std::size_t len, Message& out, std::string& err) {
    err.clear();
    if (data == nullptr) { err = "null buffer"; return false; }
    if (len < 2 + 1 + 1 + 8 * 4 + 4 * 4) { err = "frame too short"; return false; }

    Reader r(data, len);
    std::uint16_t ver = r.u16();
    if (!r.ok) { err = r.err; return false; }
    if (ver != limits::kWireVersion) {
        std::ostringstream os;
        os << "unsupported wire version " << ver;
        err = os.str();
        return false;
    }
    std::uint8_t rawType = r.u8();
    std::uint8_t rawPrio = r.u8();
    if (!isValidMsgType(rawType)) { err = "unknown message type"; return false; }
    if (!isValidPriority(rawPrio)) { err = "unknown priority"; return false; }

    Message m;
    m.type          = static_cast<MsgType>(rawType);
    m.priority      = static_cast<Priority>(rawPrio);
    m.messageId     = r.u64();
    m.correlationId = r.u64();
    m.timestamp     = r.u64();
    m.steadyStamp   = r.u64();
    m.sourceService = r.str();
    m.destination   = r.str();
    m.topic         = r.str();
    m.payload       = r.str();
    if (!r.ok) { err = r.err; return false; }
    if (r.i != len) { err = "trailing bytes in frame"; return false; }

    std::string why;
    if (!m.isValid(why)) { err = why; return false; }
    out = m;
    return true;
}

std::string Message::toLogString() const {
    std::ostringstream os;
    os << "id=" << messageId
       << " type=" << vsmf::toString(type)
       << " prio=" << vsmf::toString(priority)
       << " src=" << (sourceService.empty() ? "-" : sourceService)
       << " dst=" << (destination.empty() ? "-" : destination)
       << " topic=" << (topic.empty() ? "-" : topic);
    if (correlationId != 0) os << " corr=" << correlationId;
    if (!payload.empty()) os << " payload=" << util::sanitize(payload, 200);
    return os.str();
}

}  // namespace vsmf
