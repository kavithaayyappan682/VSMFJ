#include "data/DataGenerator.hpp"

#include <cmath>
#include <cstdio>

#include "common/Utils.hpp"
#include "support/Json.hpp"

namespace vsmf {

const double DataGenerator::kMaxSpeedKph = 260.0;
const double DataGenerator::kMaxRpm      = 8000.0;

namespace {
const double kIdleRpm = 800.0;
const double kAmbientC = 30.0;
}

DataGenerator::DataGenerator(std::uint64_t seed) : rng_(seed ? seed : 0x5EED1234ULL) {
    s_.timestamp = util::wallNs();
}

double DataGenerator::nextUniform() {
    // xorshift64*: no <random> state to synchronise, fully deterministic.
    rng_ ^= rng_ >> 12;
    rng_ ^= rng_ << 25;
    rng_ ^= rng_ >> 27;
    std::uint64_t v = rng_ * 2685821657736338717ULL;
    return static_cast<double>(v >> 11) / 9007199254740992.0;   // 2^53
}

double DataGenerator::nextNoise(double amplitude) {
    return (nextUniform() - 0.5) * 2.0 * amplitude;
}

VehicleSample DataGenerator::step(double dtSec) {
    if (!(dtSec > 0.0)) dtSec = 0.001;              // also catches NaN
    dtSec = util::clampValue(dtSec, 0.001, 5.0);

    std::lock_guard<std::mutex> lk(mu_);

    // Drive cycle: a slow sinusoid around the operator's target speed.
    phase_ += dtSec * 0.12;
    if (phase_ > 6.28318530718) phase_ -= 6.28318530718;
    double desired = targetSpeed_ + 18.0 * std::sin(phase_) + nextNoise(1.2);
    desired = util::clampValue(desired, 0.0, kMaxSpeedKph);

    // First-order approach: real vehicles do not step-change speed.
    double tau = 2.5;
    double alpha = dtSec / (tau + dtSec);
    s_.speedKph += (desired - s_.speedKph) * alpha;
    s_.speedKph = util::clampValue(s_.speedKph, 0.0, kMaxSpeedKph);

    // Gear from speed, RPM from speed and gear ratio.
    static const double ratio[6] = {13.5, 8.2, 5.6, 4.2, 3.4, 2.9};
    int g = 0;
    if      (s_.speedKph < 20.0)  g = 0;
    else if (s_.speedKph < 40.0)  g = 1;
    else if (s_.speedKph < 65.0)  g = 2;
    else if (s_.speedKph < 95.0)  g = 3;
    else if (s_.speedKph < 130.0) g = 4;
    else                          g = 5;
    s_.gear = g + 1;
    s_.rpm = kIdleRpm + s_.speedKph * ratio[g] + nextNoise(40.0);
    s_.rpm = util::clampValue(s_.rpm, kIdleRpm * 0.9, kMaxRpm);

    // Coolant: heats with load, sheds to ambient.
    double load = s_.rpm / kMaxRpm;
    double targetC = kAmbientC + 55.0 * load + (faultOverheat_ ? 45.0 : 0.0);
    s_.coolantC += (targetC - s_.coolantC) * (dtSec / (12.0 + dtSec));
    s_.coolantC = util::clampValue(s_.coolantC + nextNoise(0.15), -40.0, 200.0);

    // Pack drain proportional to demand, faster under fault.
    double drain = (0.02 + 0.18 * load) * dtSec * (faultBattery_ ? 12.0 : 1.0);
    s_.batteryPct = util::clampValue(s_.batteryPct - drain, 0.0, 100.0);

    // Position: integrate heading-less straight-line motion, good enough
    // to make the GPS topic carry changing, sane values.
    double metres = (s_.speedKph / 3.6) * dtSec;
    s_.latitude  = util::clampValue(s_.latitude + metres / 111320.0, -90.0, 90.0);
    s_.longitude = util::clampValue(s_.longitude + metres / 102000.0, -180.0, 180.0);
    s_.satellites = static_cast<std::uint32_t>(6 + static_cast<int>(nextUniform() * 6));
    s_.gpsFix = s_.satellites >= 4;
    s_.timestamp = util::wallNs();
    return s_;
}

VehicleSample DataGenerator::current() const {
    std::lock_guard<std::mutex> lk(mu_);
    return s_;
}

bool DataGenerator::setSpeed(double kph, std::string& err) {
    if (kph != kph) { err = "speed is not a number"; return false; }
    if (kph < 0.0 || kph > kMaxSpeedKph) {
        char buf[96];
        std::snprintf(buf, sizeof(buf), "speed must be within 0..%.0f km/h", kMaxSpeedKph);
        err = buf;
        return false;
    }
    std::lock_guard<std::mutex> lk(mu_);
    s_.speedKph = kph;
    targetSpeed_ = kph;
    return true;
}

void DataGenerator::setTargetSpeed(double kph) {
    std::lock_guard<std::mutex> lk(mu_);
    targetSpeed_ = util::clampValue(kph, 0.0, kMaxSpeedKph);
}

void DataGenerator::injectFault(bool overheat, bool batteryFault) {
    std::lock_guard<std::mutex> lk(mu_);
    faultOverheat_ = overheat;
    faultBattery_ = batteryFault;
}

void DataGenerator::reset() {
    std::lock_guard<std::mutex> lk(mu_);
    s_ = VehicleSample();
    targetSpeed_ = 60.0;
    phase_ = 0.0;
    faultOverheat_ = false;
    faultBattery_ = false;
}

// ---------------------------------------------------------------------
namespace {
std::string num(double v, int dp) {
    char buf[48];
    std::snprintf(buf, sizeof(buf), "%.*f", dp, v);
    return std::string(buf);
}
}  // namespace

std::string encodeSpeed(const VehicleSample& s) {
    return "{\"speed\":" + num(s.speedKph, 2) + ",\"gear\":" + std::to_string(s.gear) + "}";
}

std::string encodeEngine(const VehicleSample& s) {
    return "{\"rpm\":" + num(s.rpm, 0) + ",\"temperature\":" + num(s.coolantC, 2) + "}";
}

std::string encodeBattery(const VehicleSample& s) {
    return "{\"battery\":" + num(s.batteryPct, 2) + ",\"voltage\":" +
           num(11.6 + 0.024 * s.batteryPct, 2) + "}";
}

std::string encodeGps(const VehicleSample& s) {
    return "{\"lat\":" + num(s.latitude, 6) + ",\"lon\":" + num(s.longitude, 6) +
           ",\"fix\":" + (s.gpsFix ? "true" : "false") +
           ",\"satellites\":" + std::to_string(s.satellites) + "}";
}

bool decodeNumber(const std::string& json, const char* key, double& out) {
    JsonValue doc;
    std::string err;
    if (!JsonValue::parse(json, doc, err)) return false;
    const JsonValue* v = doc.find(key);
    if (v == nullptr || !v->isNumber()) return false;
    out = v->asNumber();
    return true;
}

bool decodeString(const std::string& json, const char* key, std::string& out) {
    JsonValue doc;
    std::string err;
    if (!JsonValue::parse(json, doc, err)) return false;
    const JsonValue* v = doc.find(key);
    if (v == nullptr || !v->isString()) return false;
    out = v->asString();
    return true;
}

}  // namespace vsmf
