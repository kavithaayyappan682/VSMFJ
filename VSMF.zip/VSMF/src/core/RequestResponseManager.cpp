#include "core/RequestResponseManager.hpp"

#include <chrono>

#include "common/Utils.hpp"

namespace vsmf {

RequestResponseManager::RequestResponseManager() {}

RequestResponseManager::~RequestResponseManager() { cancelAll("manager destroyed"); }

void RequestResponseManager::setSender(SendFn fn) {
    std::lock_guard<std::mutex> lk(mu_);
    send_ = fn;
}

bool RequestResponseManager::request(const std::string& destination, const std::string& topic,
                                     const std::string& payload, int timeoutMs,
                                     Message& out, std::string& err, Priority p, MsgType type) {
    if (destination.empty()) { err = "empty destination"; return false; }
    if (timeoutMs <= 0) timeoutMs = 1000;

    SendFn sender;
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (!send_) { err = "transport not attached"; return false; }
        if (pending_.size() >= kMaxPending) {
            ++failed_;
            err = "too many in-flight requests";
            return false;
        }
        sender = send_;
    }

    if (type != MsgType::REQUEST && type != MsgType::PING) { err = "unsupported request type"; return false; }
    Message req(type, source_, topic, payload, p);
    req.destination = destination;
    req.correlationId = req.messageId;

    PendingPtr slot(new Pending());
    {
        std::lock_guard<std::mutex> lk(mu_);
        pending_[req.correlationId] = slot;
        ++sent_;
    }

    // Send outside the table lock: the transport can block briefly.
    if (!sender(req, err)) {
        std::lock_guard<std::mutex> lk(mu_);
        pending_.erase(req.correlationId);
        ++failed_;
        return false;
    }

    bool got = false;
    {
        std::unique_lock<std::mutex> lk(slot->mu);
        got = slot->cv.wait_for(lk, std::chrono::milliseconds(timeoutMs),
                                [&slot] { return slot->done; });
    }

    // Remove the slot regardless of outcome. A response arriving after
    // this point finds no entry, is counted as late and dropped.
    {
        std::lock_guard<std::mutex> lk(mu_);
        pending_.erase(req.correlationId);
    }

    if (!got) {
        std::lock_guard<std::mutex> lk(mu_);
        ++timeouts_;
        err = "request to '" + destination + "' timed out after " + std::to_string(timeoutMs) + " ms";
        return false;
    }

    std::lock_guard<std::mutex> lk2(slot->mu);
    if (slot->error) {
        {
            std::lock_guard<std::mutex> lk(mu_);
            ++failed_;
        }
        err = slot->err.empty() ? "remote error" : slot->err;
        return false;
    }
    out = slot->response;
    {
        std::lock_guard<std::mutex> lk(mu_);
        ++ok_;
    }
    return true;
}

bool RequestResponseManager::onResponse(const Message& m) {
    PendingPtr slot;
    {
        std::lock_guard<std::mutex> lk(mu_);
        std::map<std::uint64_t, PendingPtr>::iterator it = pending_.find(m.correlationId);
        if (it == pending_.end()) {
            ++late_;              // timed out already, or a duplicate/bogus id
            return false;
        }
        slot = it->second;
    }
    {
        std::lock_guard<std::mutex> lk(slot->mu);
        if (slot->done) return false;                 // duplicate response
        slot->done = true;
        if (m.type == MsgType::ERROR) {
            slot->error = true;
            slot->err = m.payload;
        } else {
            slot->response = m;
        }
    }
    slot->cv.notify_all();
    return true;
}

void RequestResponseManager::cancelAll(const std::string& reason) {
    std::map<std::uint64_t, PendingPtr> copy;
    {
        std::lock_guard<std::mutex> lk(mu_);
        copy.swap(pending_);
    }
    for (std::map<std::uint64_t, PendingPtr>::iterator it = copy.begin(); it != copy.end(); ++it) {
        PendingPtr& s = it->second;
        {
            std::lock_guard<std::mutex> lk(s->mu);
            if (s->done) continue;
            s->done = true;
            s->error = true;
            s->err = reason;
        }
        s->cv.notify_all();
    }
}

std::size_t RequestResponseManager::pending() const {
    std::lock_guard<std::mutex> lk(mu_);
    return pending_.size();
}

}  // namespace vsmf
