#include "core/PubSubManager.hpp"

#include <algorithm>

namespace vsmf {

bool PubSubManager::topicMatches(const std::string& pattern, const std::string& topic) {
    if (pattern.empty()) return false;
    if (pattern == "*" || pattern == "#") return true;
    if (pattern[pattern.size() - 1] == '*') {
        std::string prefix = pattern.substr(0, pattern.size() - 1);
        return topic.size() >= prefix.size() && topic.compare(0, prefix.size(), prefix) == 0;
    }
    return pattern == topic;
}

bool PubSubManager::subscribe(const std::string& topic, const std::string& endpoint, std::string& err) {
    if (topic.empty())    { err = "empty topic"; return false; }
    if (endpoint.empty()) { err = "empty endpoint"; return false; }
    if (topic.size() > limits::kMaxTopicName)       { err = "topic too long"; return false; }
    if (endpoint.size() > limits::kMaxEndpointName) { err = "endpoint name too long"; return false; }

    bool wildcard = (topic == "*" || topic == "#" || topic[topic.size() - 1] == '*');
    std::lock_guard<std::mutex> lk(mu_);
    if (wildcard) wild_[topic].insert(endpoint);
    else          exact_[topic].insert(endpoint);
    return true;
}

bool PubSubManager::unsubscribe(const std::string& topic, const std::string& endpoint) {
    std::lock_guard<std::mutex> lk(mu_);
    bool removed = false;
    std::map<std::string, std::set<std::string> >::iterator it = exact_.find(topic);
    if (it != exact_.end()) {
        removed = it->second.erase(endpoint) > 0;
        if (it->second.empty()) exact_.erase(it);
    }
    it = wild_.find(topic);
    if (it != wild_.end()) {
        removed = (it->second.erase(endpoint) > 0) || removed;
        if (it->second.empty()) wild_.erase(it);
    }
    return removed;
}

std::size_t PubSubManager::unsubscribeAll(const std::string& endpoint) {
    std::lock_guard<std::mutex> lk(mu_);
    std::size_t n = 0;
    std::map<std::string, std::set<std::string> >* maps[2] = {&exact_, &wild_};
    for (int k = 0; k < 2; ++k) {
        std::map<std::string, std::set<std::string> >::iterator it = maps[k]->begin();
        while (it != maps[k]->end()) {
            n += it->second.erase(endpoint);
            if (it->second.empty()) maps[k]->erase(it++);   // safe erase-advance
            else ++it;
        }
    }
    return n;
}

std::vector<std::string> PubSubManager::subscribers(const std::string& topic) const {
    std::set<std::string> uniq;
    {
        std::lock_guard<std::mutex> lk(mu_);
        std::map<std::string, std::set<std::string> >::const_iterator it = exact_.find(topic);
        if (it != exact_.end()) uniq.insert(it->second.begin(), it->second.end());
        for (it = wild_.begin(); it != wild_.end(); ++it)
            if (topicMatches(it->first, topic)) uniq.insert(it->second.begin(), it->second.end());
    }
    return std::vector<std::string>(uniq.begin(), uniq.end());
}

bool PubSubManager::isSubscribed(const std::string& topic, const std::string& endpoint) const {
    std::vector<std::string> subs = subscribers(topic);
    return std::find(subs.begin(), subs.end(), endpoint) != subs.end();
}

std::vector<std::string> PubSubManager::topics() const {
    std::lock_guard<std::mutex> lk(mu_);
    std::vector<std::string> out;
    std::map<std::string, std::set<std::string> >::const_iterator it;
    for (it = exact_.begin(); it != exact_.end(); ++it) out.push_back(it->first);
    for (it = wild_.begin(); it != wild_.end(); ++it) out.push_back(it->first);
    return out;
}

std::size_t PubSubManager::topicCount() const {
    std::lock_guard<std::mutex> lk(mu_);
    return exact_.size() + wild_.size();
}

std::size_t PubSubManager::subscriptionCount() const {
    std::lock_guard<std::mutex> lk(mu_);
    std::size_t n = 0;
    std::map<std::string, std::set<std::string> >::const_iterator it;
    for (it = exact_.begin(); it != exact_.end(); ++it) n += it->second.size();
    for (it = wild_.begin(); it != wild_.end(); ++it) n += it->second.size();
    return n;
}

void PubSubManager::clear() {
    std::lock_guard<std::mutex> lk(mu_);
    exact_.clear();
    wild_.clear();
}

}  // namespace vsmf
