#include "core/IPCManager.hpp"

#include <cerrno>
#include <cstring>
#include <ctime>

#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#include "common/Utils.hpp"
#include "support/LoggerService.hpp"

namespace vsmf {

namespace {

// A UDS path must fit in sun_path with room for the NUL terminator.
bool checkPath(const std::string& p, std::string& err) {
    struct sockaddr_un sa;
    if (p.empty()) { err = "socket path is empty"; return false; }
    if (p.size() + 1 > sizeof(sa.sun_path)) {
        err = "socket path too long (max " + std::to_string(sizeof(sa.sun_path) - 1) + " bytes): " + p;
        return false;
    }
    if (p[0] != '/') { err = "socket path must be absolute: " + p; return false; }
    return true;
}

void fillAddr(struct sockaddr_un& sa, const std::string& p) {
    std::memset(&sa, 0, sizeof(sa));
    sa.sun_family = AF_UNIX;
    std::memcpy(sa.sun_path, p.c_str(), p.size());   // length already validated
}

// Is somebody actually listening on this path, or is it a corpse?
bool socketIsLive(const std::string& p) {
    int fd = ::socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return false;
    struct sockaddr_un sa;
    fillAddr(sa, p);
    bool live = (::connect(fd, reinterpret_cast<struct sockaddr*>(&sa), sizeof(sa)) == 0);
    util::closeQuiet(fd);
    return live;
}

const int kPollSliceMs = 200;   // bounds shutdown latency

}  // namespace

// ---------------------------------------------------------------------
// Framing
// ---------------------------------------------------------------------
FrameStatus readFrame(int fd, std::vector<std::uint8_t>& buf, int timeoutMs, std::string& err) {
    err.clear();
    if (fd < 0) { err = "bad descriptor"; return FrameStatus::Error; }

    int rc = util::waitReadable(fd, timeoutMs);
    if (rc == 0) return FrameStatus::Timeout;
    if (rc < 0) { err = std::strerror(errno); return FrameStatus::Error; }

    std::uint8_t hdr[4];
    std::ptrdiff_t r = util::readAll(fd, hdr, sizeof(hdr));
    if (r == 0) return FrameStatus::Closed;              // clean EOF
    if (r < 0) {
        // A peer that vanished mid-header is a close, not a fault.
        if (errno == ECONNRESET || errno == EPIPE) return FrameStatus::Closed;
        err = std::strerror(errno);
        return FrameStatus::Error;
    }

    std::uint32_t len = (static_cast<std::uint32_t>(hdr[0]) << 24) |
                        (static_cast<std::uint32_t>(hdr[1]) << 16) |
                        (static_cast<std::uint32_t>(hdr[2]) << 8)  |
                        (static_cast<std::uint32_t>(hdr[3]));
    if (len == 0) { err = "zero-length frame"; return FrameStatus::Error; }
    if (len > limits::kMaxFrameBytes) {
        // Refuse to allocate on a peer's say-so.
        err = "frame length " + std::to_string(len) + " exceeds limit";
        return FrameStatus::Error;
    }

    buf.resize(len);
    r = util::readAll(fd, buf.data(), len);
    if (r == 0) return FrameStatus::Closed;              // truncated frame
    if (r < 0) {
        if (errno == ECONNRESET || errno == EPIPE) return FrameStatus::Closed;
        err = std::strerror(errno);
        return FrameStatus::Error;
    }
    return FrameStatus::Ok;
}

bool writeFrame(int fd, const Message& m, std::mutex& wmu, std::string& err) {
    std::vector<std::uint8_t> out;
    if (!m.serialize(out, err)) return false;
    std::lock_guard<std::mutex> lk(wmu);             // one writer at a time
    if (fd < 0) { err = "connection closed"; return false; }
    if (util::writeAll(fd, out.data(), out.size()) < 0) {
        err = std::strerror(errno);                  // EPIPE when peer is gone
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------
// IPCManager
// ---------------------------------------------------------------------
IPCManager::IPCManager()
    : running_(false), framesIn_(0), framesOut_(0), framesDropped_(0), framesBad_(0) {}

IPCManager::~IPCManager() { stop(); }

void IPCManager::setInboundHandler(InboundHandler h) {
    std::lock_guard<std::mutex> lk(handlerMu_);
    inbound_ = h;
}

void IPCManager::log(LogLevel lvl, const std::string& msg) {
    if (logger_ != nullptr) logger_->log(lvl, "IPCManager", msg);
}

bool IPCManager::start(const std::string& socketPath, std::string& err) {
    if (running_.load(std::memory_order_acquire)) { err = "already running"; return false; }
    if (!checkPath(socketPath, err)) return false;

    util::ignoreSigPipe();

    std::string mkErr;
    if (!util::makeDirs(util::dirName(socketPath), mkErr)) { err = mkErr; return false; }

    if (util::fileExists(socketPath)) {
        if (socketIsLive(socketPath)) {
            err = "another VSMF instance is already listening on " + socketPath;
            return false;
        }
        if (::unlink(socketPath.c_str()) != 0 && errno != ENOENT) {
            err = "cannot remove stale socket " + socketPath + ": " + std::strerror(errno);
            return false;
        }
        log(LogLevel::WARN, "removed stale socket " + socketPath);
    }

    listenFd_ = ::socket(AF_UNIX, SOCK_STREAM, 0);
    if (listenFd_ < 0) { err = std::string("socket(): ") + std::strerror(errno); return false; }
    util::setCloExec(listenFd_);

    struct sockaddr_un sa;
    fillAddr(sa, socketPath);
    if (::bind(listenFd_, reinterpret_cast<struct sockaddr*>(&sa), sizeof(sa)) != 0) {
        err = std::string("bind(") + socketPath + "): " + std::strerror(errno);
        util::closeQuiet(listenFd_);
        return false;
    }
    // Owner-only: vehicle telemetry is not world-writable.
    if (::chmod(socketPath.c_str(), 0600) != 0) {
        log(LogLevel::WARN, std::string("chmod on socket failed: ") + std::strerror(errno));
    }
    if (::listen(listenFd_, 64) != 0) {
        err = std::string("listen(): ") + std::strerror(errno);
        ::unlink(socketPath.c_str());
        util::closeQuiet(listenFd_);
        return false;
    }

    socketPath_ = socketPath;
    running_.store(true, std::memory_order_release);
    acceptTh_ = std::thread(&IPCManager::acceptLoop, this);
    log(LogLevel::INFO, "listening on " + socketPath);
    return true;
}

void IPCManager::stop() {
    if (!running_.exchange(false, std::memory_order_acq_rel)) return;

    // Wake the accept loop out of poll() and refuse new peers.
    if (listenFd_ >= 0) ::shutdown(listenFd_, SHUT_RDWR);
    if (acceptTh_.joinable()) acceptTh_.join();
    util::closeQuiet(listenFd_);

    // Wake every reader thread: shutdown() makes their blocked read return 0.
    {
        std::lock_guard<std::mutex> lk(connMu_);
        for (std::size_t i = 0; i < conns_.size(); ++i) {
            conns_[i]->alive.store(false, std::memory_order_release);
            if (conns_[i]->fd >= 0) ::shutdown(conns_[i]->fd, SHUT_RDWR);
        }
    }
    reap(true);

    if (!socketPath_.empty()) {
        ::unlink(socketPath_.c_str());
        log(LogLevel::INFO, "socket closed and unlinked");
    }
}

void IPCManager::acceptLoop() {
    while (running_.load(std::memory_order_acquire)) {
        int rc = util::waitReadable(listenFd_, kPollSliceMs);
        if (rc == 0) { reap(false); continue; }          // idle: reap corpses
        if (rc < 0) {
            if (errno == EINTR) continue;
            if (running_.load(std::memory_order_acquire))
                log(LogLevel::ERROR, std::string("poll on listen fd: ") + std::strerror(errno));
            break;
        }
        int cfd = ::accept(listenFd_, nullptr, nullptr);
        if (cfd < 0) {
            // EMFILE/ENFILE: out of descriptors. Do not spin the CPU -
            // back off and keep serving the peers we already have.
            if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK) continue;
            if (errno == EMFILE || errno == ENFILE) {
                log(LogLevel::ERROR, "descriptor limit reached, backing off");
                struct timespec ts; ts.tv_sec = 0; ts.tv_nsec = 100 * 1000000L;
                ::nanosleep(&ts, nullptr);
                continue;
            }
            if (errno == EINVAL || errno == EBADF) break;   // listen fd shut down
            log(LogLevel::WARN, std::string("accept(): ") + std::strerror(errno));
            continue;
        }
        util::setCloExec(cfd);

        ConnPtr c(new Conn());
        c->fd = cfd;
        {
            std::lock_guard<std::mutex> lk(connMu_);
            conns_.push_back(c);
        }
        c->th = std::thread(&IPCManager::readerLoop, this, c);
        reap(false);
    }
}

void IPCManager::readerLoop(ConnPtr c) {
    std::vector<std::uint8_t> buf;
    std::string err;

    while (running_.load(std::memory_order_acquire) && c->alive.load(std::memory_order_acquire)) {
        FrameStatus st = readFrame(c->fd, buf, kPollSliceMs, err);
        if (st == FrameStatus::Timeout) continue;
        if (st == FrameStatus::Closed) break;
        if (st == FrameStatus::Error) {
            framesBad_.fetch_add(1, std::memory_order_relaxed);
            log(LogLevel::WARN, "dropping connection '" + c->name + "': " + err);
            break;
        }

        Message m;
        if (!Message::deserialize(buf.data(), buf.size(), m, err)) {
            // One bad frame does not justify killing the endpoint, but we
            // count it: a rising counter is the symptom of a broken peer.
            framesBad_.fetch_add(1, std::memory_order_relaxed);
            log(LogLevel::WARN, "malformed frame from '" + c->name + "': " + err);
            continue;
        }
        framesIn_.fetch_add(1, std::memory_order_relaxed);

        if (m.type == MsgType::HELLO) {
            std::string want = util::sanitize(m.sourceService, limits::kMaxEndpointName);
            if (want.empty()) {
                log(LogLevel::WARN, "HELLO with empty endpoint name, ignoring");
                continue;
            }
            bool clash = false;
            {
                std::lock_guard<std::mutex> lk(connMu_);
                for (std::size_t i = 0; i < conns_.size(); ++i) {
                    if (conns_[i] != c && conns_[i]->alive.load(std::memory_order_acquire) &&
                        conns_[i]->name == want) { clash = true; break; }
                }
                if (!clash) c->name = want;
            }
            if (clash) {
                log(LogLevel::ERROR, "duplicate endpoint name '" + want + "', refusing connection");
                break;
            }
            log(LogLevel::DEBUG, "endpoint attached: " + want);
            continue;
        }

        if (m.type == MsgType::BYE) { log(LogLevel::DEBUG, "endpoint said BYE: " + c->name); break; }

        // Anonymous peers may not inject traffic.
        if (c->name.empty()) {
            framesBad_.fetch_add(1, std::memory_order_relaxed);
            log(LogLevel::WARN, "frame before HELLO, ignored");
            continue;
        }
        // Do not let a peer forge someone else's identity.
        if (m.sourceService != c->name) m.sourceService = c->name;

        InboundHandler h;
        {
            std::lock_guard<std::mutex> lk(handlerMu_);
            h = inbound_;
        }
        if (!h) { framesDropped_.fetch_add(1, std::memory_order_relaxed); continue; }
        try {
            h(m);   // routing happens outside every lock we hold
        } catch (const std::exception& e) {
            log(LogLevel::ERROR, std::string("inbound handler threw: ") + e.what());
        } catch (...) {
            log(LogLevel::ERROR, "inbound handler threw unknown exception");
        }
    }

    c->alive.store(false, std::memory_order_release);
    if (c->fd >= 0) ::shutdown(c->fd, SHUT_RDWR);
}

void IPCManager::dropConn(const ConnPtr& c) {
    c->alive.store(false, std::memory_order_release);
    if (c->fd >= 0) ::shutdown(c->fd, SHUT_RDWR);
}

void IPCManager::reap(bool joinAll) {
    std::vector<ConnPtr> dead;
    {
        std::lock_guard<std::mutex> lk(connMu_);
        std::vector<ConnPtr> keep;
        keep.reserve(conns_.size());
        for (std::size_t i = 0; i < conns_.size(); ++i) {
            if (joinAll || !conns_[i]->alive.load(std::memory_order_acquire)) dead.push_back(conns_[i]);
            else keep.push_back(conns_[i]);
        }
        conns_.swap(keep);
    }
    // Join outside connMu_: a reader thread may be calling back into us.
    for (std::size_t i = 0; i < dead.size(); ++i) {
        if (dead[i]->th.joinable()) dead[i]->th.join();
        util::closeQuiet(dead[i]->fd);
    }
}

bool IPCManager::deliver(const std::string& endpoint, const Message& m, std::string& err) {
    if (!running_.load(std::memory_order_acquire)) { err = "broker not running"; return false; }
    ConnPtr target;
    {
        std::lock_guard<std::mutex> lk(connMu_);
        for (std::size_t i = 0; i < conns_.size(); ++i) {
            if (conns_[i]->alive.load(std::memory_order_acquire) && conns_[i]->name == endpoint) {
                target = conns_[i];
                break;
            }
        }
    }
    if (!target) {
        framesDropped_.fetch_add(1, std::memory_order_relaxed);
        err = "no such endpoint: " + endpoint;
        return false;
    }
    // Write outside connMu_ so a slow peer cannot stall the whole broker.
    if (!writeFrame(target->fd, m, target->writeMu, err)) {
        framesDropped_.fetch_add(1, std::memory_order_relaxed);
        dropConn(target);
        log(LogLevel::WARN, "delivery to '" + endpoint + "' failed (" + err + "), connection dropped");
        return false;
    }
    framesOut_.fetch_add(1, std::memory_order_relaxed);
    return true;
}

bool IPCManager::hasEndpoint(const std::string& name) const {
    std::lock_guard<std::mutex> lk(connMu_);
    for (std::size_t i = 0; i < conns_.size(); ++i)
        if (conns_[i]->alive.load(std::memory_order_acquire) && conns_[i]->name == name) return true;
    return false;
}

std::vector<std::string> IPCManager::endpointNames() const {
    std::vector<std::string> out;
    std::lock_guard<std::mutex> lk(connMu_);
    for (std::size_t i = 0; i < conns_.size(); ++i)
        if (conns_[i]->alive.load(std::memory_order_acquire) && !conns_[i]->name.empty())
            out.push_back(conns_[i]->name);
    return out;
}

std::size_t IPCManager::connectionCount() const {
    std::lock_guard<std::mutex> lk(connMu_);
    std::size_t n = 0;
    for (std::size_t i = 0; i < conns_.size(); ++i)
        if (conns_[i]->alive.load(std::memory_order_acquire)) ++n;
    return n;
}

// ---------------------------------------------------------------------
// IPCClient
// ---------------------------------------------------------------------
IPCClient::IPCClient() : connected_(false), running_(false) {}
IPCClient::~IPCClient() { disconnect(); }

void IPCClient::setHandler(Handler h) {
    std::lock_guard<std::mutex> lk(handlerMu_);
    handler_ = h;
}

bool IPCClient::connect(const std::string& socketPath, const std::string& endpointName,
                        int timeoutMs, std::string& err) {
    if (connected_.load(std::memory_order_acquire)) { err = "already connected"; return false; }
    if (!checkPath(socketPath, err)) return false;
    if (endpointName.empty() || endpointName.size() > limits::kMaxEndpointName) {
        err = "invalid endpoint name";
        return false;
    }
    util::ignoreSigPipe();

    // The broker may still be coming up; retry until the deadline.
    const std::uint64_t deadline = util::steadyNs() + static_cast<std::uint64_t>(timeoutMs < 0 ? 0 : timeoutMs) * 1000000ULL;
    for (;;) {
        fd_ = ::socket(AF_UNIX, SOCK_STREAM, 0);
        if (fd_ < 0) { err = std::string("socket(): ") + std::strerror(errno); return false; }
        util::setCloExec(fd_);
        struct sockaddr_un sa;
        fillAddr(sa, socketPath);
        if (::connect(fd_, reinterpret_cast<struct sockaddr*>(&sa), sizeof(sa)) == 0) break;
        int e = errno;
        util::closeQuiet(fd_);
        if (util::steadyNs() >= deadline) {
            err = "connect(" + socketPath + "): " + std::strerror(e);
            return false;
        }
        struct timespec ts; ts.tv_sec = 0; ts.tv_nsec = 20 * 1000000L;
        ::nanosleep(&ts, nullptr);
    }

    name_ = endpointName;
    connected_.store(true, std::memory_order_release);

    Message hello(MsgType::HELLO, endpointName, "", "", Priority::HIGH);
    if (!send(hello, err)) {
        disconnect();
        return false;
    }

    // Only spin a reader thread when somebody is listening for messages;
    // the console client polls with receive() instead.
    bool wantReader = false;
    {
        std::lock_guard<std::mutex> lk(handlerMu_);
        wantReader = static_cast<bool>(handler_);
    }
    if (wantReader) {
        running_.store(true, std::memory_order_release);
        th_ = std::thread(&IPCClient::readerLoop, this);
    }
    return true;
}

void IPCClient::disconnect() {
    if (!connected_.exchange(false, std::memory_order_acq_rel)) {
        if (th_.joinable()) th_.join();
        return;
    }
    // Best-effort courtesy BYE; failure is irrelevant, we are leaving.
    if (fd_ >= 0) {
        std::string ignored;
        Message bye(MsgType::BYE, name_, "", "", Priority::HIGH);
        writeFrame(fd_, bye, writeMu_, ignored);
    }
    running_.store(false, std::memory_order_release);
    if (fd_ >= 0) ::shutdown(fd_, SHUT_RDWR);
    if (th_.joinable()) th_.join();
    util::closeQuiet(fd_);
}

bool IPCClient::send(const Message& m, std::string& err) {
    if (!connected_.load(std::memory_order_acquire)) { err = "not connected"; return false; }
    if (!writeFrame(fd_, m, writeMu_, err)) {
        connected_.store(false, std::memory_order_release);
        return false;
    }
    return true;
}

bool IPCClient::receive(Message& out, int timeoutMs, std::string& err) {
    if (!connected_.load(std::memory_order_acquire)) { err = "not connected"; return false; }
    std::vector<std::uint8_t> buf;
    FrameStatus st = readFrame(fd_, buf, timeoutMs, err);
    if (st == FrameStatus::Timeout) { err = "timeout"; return false; }
    if (st == FrameStatus::Closed) {
        connected_.store(false, std::memory_order_release);
        err = "connection closed by middleware";
        return false;
    }
    if (st == FrameStatus::Error) return false;
    return Message::deserialize(buf.data(), buf.size(), out, err);
}

void IPCClient::readerLoop() {
    std::vector<std::uint8_t> buf;
    std::string err;
    while (running_.load(std::memory_order_acquire)) {
        FrameStatus st = readFrame(fd_, buf, kPollSliceMs, err);
        if (st == FrameStatus::Timeout) continue;
        if (st == FrameStatus::Closed || st == FrameStatus::Error) {
            connected_.store(false, std::memory_order_release);
            break;
        }
        Message m;
        if (!Message::deserialize(buf.data(), buf.size(), m, err)) continue;

        Handler h;
        {
            std::lock_guard<std::mutex> lk(handlerMu_);
            h = handler_;
        }
        if (!h) continue;
        try {
            h(m);
        } catch (...) {
            // A misbehaving service handler must not tear down its transport.
        }
    }
}

}  // namespace vsmf
