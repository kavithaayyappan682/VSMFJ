#include <ctime>

#include "core/CommunicationManager.hpp"

#include "common/Utils.hpp"
#include "support/LoggerService.hpp"
#include "support/PerformanceMonitor.hpp"
#include "support/ThreadPool.hpp"

namespace vsmf {

// ---------------------------------------------------------------------
// Endpoint
// ---------------------------------------------------------------------
const std::size_t Endpoint::kMaxRequestQueue;

Endpoint::Endpoint(const std::string& name, CommunicationManager& cm)
    : name_(name), cm_(cm), reqRunning_(false) {
    rr_.setSourceName(name);
}

Endpoint::~Endpoint() { close(); }

void Endpoint::setHandler(Handler h) {
    std::lock_guard<std::mutex> lk(handlerMu_);
    handler_ = h;
}

bool Endpoint::open(std::string& err) {
    if (client_.connected()) return true;                  // idempotent
    client_.setHandler([this](const Message& m) { this->onFrame(m); });
    if (!client_.connect(cm_.config().socketPath, name_, 2000, err)) return false;

    rr_.setSender([this](const Message& m, std::string& e) {
        if (cm_.perf() != nullptr) cm_.perf()->onRequest();
        return client_.send(m, e);
    });

    reqRunning_.store(true, std::memory_order_release);
    try {
        reqTh_ = std::thread(&Endpoint::requestWorker, this);
    } catch (const std::system_error& se) {
        // No request thread: fall back to inline handling. Nested
        // requests then are not possible, so say so loudly.
        reqRunning_.store(false, std::memory_order_release);
        if (cm_.logger() != nullptr)
            cm_.logger()->log(LogLevel::WARN, name_,
                              std::string("no request thread (") + se.what() + "), handling inline");
    }
    return true;
}

void Endpoint::close() {
    // Wake anyone blocked in request() before the socket disappears,
    // otherwise those threads wait out their full timeout at shutdown.
    rr_.cancelAll("endpoint " + name_ + " closing");

    if (reqRunning_.exchange(false, std::memory_order_acq_rel)) {
        reqCv_.notify_all();
        if (reqTh_.joinable()) {
            if (reqTh_.get_id() == std::this_thread::get_id()) reqTh_.detach();  // close() from a handler
            else reqTh_.join();
        }
    }
    {
        std::lock_guard<std::mutex> lk(reqMu_);
        reqQ_.clear();
    }
    client_.disconnect();
    cm_.pubsub().unsubscribeAll(name_);
}

std::size_t Endpoint::requestQueueDepth() const {
    std::lock_guard<std::mutex> lk(reqMu_);
    return reqQ_.size();
}

void Endpoint::requestWorker() {
    for (;;) {
        Message m;
        {
            std::unique_lock<std::mutex> lk(reqMu_);
            reqCv_.wait(lk, [this] {
                return !reqQ_.empty() || !reqRunning_.load(std::memory_order_acquire);
            });
            if (reqQ_.empty()) {
                if (!reqRunning_.load(std::memory_order_acquire)) return;
                continue;
            }
            m = reqQ_.front();
            reqQ_.pop_front();
        }
        dispatch(m);
    }
}

void Endpoint::dispatch(const Message& m) {
    Handler h;
    {
        std::lock_guard<std::mutex> lk(handlerMu_);
        h = handler_;
    }
    if (!h) return;
    try {
        h(m);
    } catch (const std::exception& e) {
        if (cm_.logger() != nullptr)
            cm_.logger()->log(LogLevel::ERROR, name_, std::string("handler threw: ") + e.what());
    } catch (...) {
        if (cm_.logger() != nullptr) cm_.logger()->log(LogLevel::ERROR, name_, "handler threw");
    }
}

bool Endpoint::subscribe(const std::string& topic, std::string& err) {
    return cm_.pubsub().subscribe(topic, name_, err);
}

bool Endpoint::unsubscribe(const std::string& topic) {
    return cm_.pubsub().unsubscribe(topic, name_);
}

bool Endpoint::publish(const std::string& topic, const std::string& payload,
                       Priority p, std::string& err) {
    if (!client_.connected()) { err = "endpoint " + name_ + " is not connected"; return false; }
    Message m(MsgType::PUBLISH, name_, topic, payload, p);
    if (!client_.send(m, err)) {
        if (cm_.perf() != nullptr) cm_.perf()->onDropped();
        return false;
    }
    if (cm_.perf() != nullptr) cm_.perf()->onPublished();
    return true;
}

bool Endpoint::request(const std::string& destination, const std::string& topic,
                       const std::string& payload, int timeoutMs, Message& out, std::string& err) {
    if (!client_.connected()) { err = "endpoint " + name_ + " is not connected"; return false; }
    if (destination == name_) { err = "a service cannot request from itself"; return false; }
    bool ok = rr_.request(destination, topic, payload, timeoutMs, out, err);
    if (!ok && cm_.perf() != nullptr && err.find("timed out") != std::string::npos) cm_.perf()->onTimeout();
    return ok;
}

bool Endpoint::respond(const Message& req, const std::string& payload, std::string& err) {
    if (req.type != MsgType::REQUEST) { err = "not a request"; return false; }
    Message r(MsgType::RESPONSE, name_, req.topic, payload, req.priority);
    r.destination = req.sourceService;
    r.correlationId = req.correlationId;
    if (!client_.send(r, err)) return false;
    if (cm_.perf() != nullptr) cm_.perf()->onResponse();
    return true;
}

bool Endpoint::ping(const std::string& destination, int timeoutMs, std::string& err) {
    if (!client_.connected()) { err = "endpoint " + name_ + " is not connected"; return false; }
    Message pong;
    return rr_.request(destination, topics::kHealth, "PING", timeoutMs, pong, err,
                       Priority::HIGH, MsgType::PING);
}

bool Endpoint::respondError(const Message& req, const std::string& reason, std::string& err) {
    Message r(MsgType::ERROR, name_, req.topic, reason, Priority::HIGH);
    r.destination = req.sourceService;
    r.correlationId = req.correlationId;
    return client_.send(r, err);
}

void Endpoint::onFrame(const Message& m) {
    // Latency is measured from publish to arrival at the consumer.
    if (cm_.perf() != nullptr && m.steadyStamp != 0) {
        std::uint64_t now = util::steadyNs();
        cm_.perf()->onDelivered(now > m.steadyStamp ? now - m.steadyStamp : 0);
    }

    // Responses complete a waiting caller: handle inline, never on the
    // pool, so a saturated pool cannot deadlock request/response.
    if (m.type == MsgType::RESPONSE || m.type == MsgType::ERROR || m.type == MsgType::PONG) {
        rr_.onResponse(m);
        return;
    }

    // Heartbeats are answered by the transport layer itself: a service
    // busy in its own callback still proves it is alive.
    if (m.type == MsgType::PING) {
        Message pong(MsgType::PONG, name_, m.topic, "PONG", Priority::HIGH);
        pong.destination = m.sourceService;
        pong.correlationId = m.correlationId;
        std::string err;
        if (client_.send(pong, err) && cm_.perf() != nullptr) cm_.perf()->onResponse();
        return;
    }

    // REQUESTs go to this endpoint's serial request thread so a handler
    // may itself issue a request without blocking the reader thread that
    // has to deliver the answer.
    if (m.type == MsgType::REQUEST) {
        if (reqRunning_.load(std::memory_order_acquire)) {
            bool full = false;
            {
                std::lock_guard<std::mutex> lk(reqMu_);
                if (reqQ_.size() >= kMaxRequestQueue) full = true;
                else reqQ_.push_back(m);
            }
            if (full) {
                // Bounded: tell the caller now instead of letting it time out.
                std::string err;
                Message busy(MsgType::ERROR, name_, m.topic, name_ + " request queue full", Priority::HIGH);
                busy.destination = m.sourceService;
                busy.correlationId = m.correlationId;
                client_.send(busy, err);
                if (cm_.perf() != nullptr) cm_.perf()->onDropped();
                return;
            }
            reqCv_.notify_one();
        } else {
            dispatch(m);       // degraded mode: no request thread available
        }
        return;
    }

    // PUBLISH traffic goes to the shared pool: that is where the
    // multithreaded fan-out happens.
    Handler h;
    {
        std::lock_guard<std::mutex> lk(handlerMu_);
        h = handler_;
    }
    if (!h) return;
    ThreadPool* tp = cm_.pool();
    if (tp != nullptr && tp->isRunning()) {
        Message copy = m;
        // Dropped work is counted by the pool and by the perf monitor;
        // falling back to inline execution here would defeat backpressure.
        if (!tp->submit([h, copy]() { h(copy); }, m.priority)) {
            if (cm_.perf() != nullptr) cm_.perf()->onDropped();
            if (cm_.logger() != nullptr)
                cm_.logger()->log(LogLevel::WARN, name_, "thread pool full, message dropped: " + copy.toLogString());
        }
        return;
    }
    dispatch(m);
}

// ---------------------------------------------------------------------
// CommunicationManager
// ---------------------------------------------------------------------
CommunicationManager::CommunicationManager(ServiceRegistry& reg)
    : reg_(reg), router_(ipc_, pubsub_, reg) {}

CommunicationManager::~CommunicationManager() { stop(); }

void CommunicationManager::setLogger(LoggerService* lg) {
    logger_ = lg;
    ipc_.setLogger(lg);
    router_.setLogger(lg);
}

void CommunicationManager::setPerf(PerformanceMonitor* pm) {
    perf_ = pm;
    router_.setPerf(pm);
}

bool CommunicationManager::start(const Config& cfg, std::string& err) {
    cfg_ = cfg;
    ipc_.setInboundHandler([this](const Message& m) { router_.route(m); });
    if (!ipc_.start(cfg_.socketPath, err)) return false;
    if (logger_ != nullptr)
        logger_->log(LogLevel::INFO, "CommunicationManager", "transport up on " + cfg_.socketPath);
    return true;
}

void CommunicationManager::stop() {
    std::map<std::string, EndpointPtr> eps;
    {
        std::lock_guard<std::mutex> lk(epMu_);
        eps.swap(endpoints_);
    }
    // Close endpoints before the broker so each gets a clean BYE.
    for (std::map<std::string, EndpointPtr>::iterator it = eps.begin(); it != eps.end(); ++it)
        it->second->close();
    eps.clear();
    ipc_.stop();
}

EndpointPtr CommunicationManager::createEndpoint(const std::string& name, std::string& err) {
    if (name.empty() || name.size() > limits::kMaxEndpointName) {
        err = "invalid endpoint name";
        return EndpointPtr();
    }
    if (!ipc_.isRunning()) { err = "transport is not running"; return EndpointPtr(); }
    {
        std::lock_guard<std::mutex> lk(epMu_);
        if (endpoints_.find(name) != endpoints_.end()) {
            err = "endpoint already exists: " + name;
            return EndpointPtr();
        }
    }
    EndpointPtr ep(new Endpoint(name, *this));
    if (!ep->open(err)) return EndpointPtr();

    // connect() only guarantees the HELLO frame was written; the broker
    // registers the name a moment later on its own reader thread. Without
    // this wait, a service that starts and immediately calls another one
    // gets "no such endpoint" purely because of start-up ordering.
    const std::uint64_t deadline = util::steadyNs() + 2000ULL * 1000000ULL;
    while (!ipc_.hasEndpoint(name)) {
        if (util::steadyNs() >= deadline) {
            ep->close();
            err = "broker did not acknowledge endpoint " + name;
            return EndpointPtr();
        }
        struct timespec ts;
        ts.tv_sec = 0;
        ts.tv_nsec = 200 * 1000L;      // 0.2 ms
        ::nanosleep(&ts, nullptr);
    }
    {
        std::lock_guard<std::mutex> lk(epMu_);
        endpoints_[name] = ep;
    }
    return ep;
}

void CommunicationManager::destroyEndpoint(const std::string& name) {
    EndpointPtr ep;
    {
        std::lock_guard<std::mutex> lk(epMu_);
        std::map<std::string, EndpointPtr>::iterator it = endpoints_.find(name);
        if (it == endpoints_.end()) return;
        ep = it->second;
        endpoints_.erase(it);
    }
    ep->close();   // outside the lock: close() joins a reader thread
}

}  // namespace vsmf
