#include "core/DiscoveryManager.hpp"

#include <ctime>

#include "common/Utils.hpp"

namespace vsmf {

bool DiscoveryManager::lookup(const std::string& name, ServiceInfo& out) const {
    return reg_.get(name, out);
}

bool DiscoveryManager::discover(const std::string& name, ServiceInfo& out, std::string& err) const {
    if (name.empty()) { err = "empty service name"; return false; }
    ServiceInfo info;
    if (!reg_.get(name, info)) { err = "service not found: " + name; return false; }
    if (info.state != ServiceState::RUNNING) {
        err = "service '" + name + "' is " + vsmf::toString(info.state) + ", not available";
        return false;
    }
    if (info.health == HealthState::UNHEALTHY) {
        // Discoverable but flagged: the caller decides whether to proceed.
        err = "service '" + name + "' is UNHEALTHY";
        out = info;
        return true;
    }
    out = info;
    return true;
}

std::vector<ServiceInfo> DiscoveryManager::discoverByTopic(const std::string& topic) const {
    return reg_.publishersOf(topic);
}

std::vector<ServiceInfo> DiscoveryManager::discoverByKind(ServiceKind k) const {
    return reg_.byKind(k);
}

std::vector<std::string> DiscoveryManager::available() const {
    std::vector<ServiceInfo> all = reg_.list();
    std::vector<std::string> out;
    for (std::size_t i = 0; i < all.size(); ++i)
        if (all[i].state == ServiceState::RUNNING) out.push_back(all[i].name);
    return out;
}

bool DiscoveryManager::waitFor(const std::string& name, int timeoutMs) const {
    const std::uint64_t deadline =
        util::steadyNs() + static_cast<std::uint64_t>(timeoutMs < 0 ? 0 : timeoutMs) * 1000000ULL;
    for (;;) {
        ServiceInfo info;
        if (reg_.get(name, info) && info.state == ServiceState::RUNNING) return true;
        if (util::steadyNs() >= deadline) return false;
        struct timespec ts; ts.tv_sec = 0; ts.tv_nsec = 5 * 1000000L;
        ::nanosleep(&ts, nullptr);
    }
}

}  // namespace vsmf
