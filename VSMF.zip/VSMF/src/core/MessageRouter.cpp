#include "core/MessageRouter.hpp"

#include "support/LoggerService.hpp"
#include "support/PerformanceMonitor.hpp"

namespace vsmf {

MessageRouter::MessageRouter(IPCManager& ipc, PubSubManager& ps, ServiceRegistry& reg)
    : ipc_(ipc), ps_(ps), reg_(reg), routed_(0), delivered_(0), unrouted_(0), failed_(0) {}

void MessageRouter::route(const Message& m) {
    routed_.fetch_add(1, std::memory_order_relaxed);
    if (perf_ != nullptr) perf_->onRouted();

    switch (m.type) {
        case MsgType::PUBLISH:
            routePublish(m);
            break;
        case MsgType::REQUEST:
        case MsgType::RESPONSE:
        case MsgType::ERROR:
        case MsgType::PING:
        case MsgType::PONG:
            routeDirect(m);
            break;
        case MsgType::HELLO:
        case MsgType::BYE:
            break;   // consumed by the transport, never reaches routing
    }
}

void MessageRouter::routePublish(const Message& m) {
    std::vector<std::string> subs = ps_.subscribers(m.topic);
    if (subs.empty()) {
        unrouted_.fetch_add(1, std::memory_order_relaxed);
        if (logger_ != nullptr)
            logger_->log(LogLevel::DEBUG, "MessageRouter", "no subscribers for topic " + m.topic);
        return;
    }
    std::size_t ok = 0;
    for (std::size_t i = 0; i < subs.size(); ++i) {
        // A publisher does not receive its own message back.
        if (subs[i] == m.sourceService) continue;
        std::string err;
        Message copy = m;
        copy.destination = subs[i];
        if (ipc_.deliver(subs[i], copy, err)) {
            ++ok;
        } else {
            // One dead subscriber must not stop delivery to the others.
            failed_.fetch_add(1, std::memory_order_relaxed);
            if (perf_ != nullptr) perf_->onDropped();
            if (logger_ != nullptr)
                logger_->log(LogLevel::WARN, "MessageRouter",
                             "delivery of " + m.topic + " to " + subs[i] + " failed: " + err);
        }
    }
    delivered_.fetch_add(ok, std::memory_order_relaxed);
    if (ok == 0) unrouted_.fetch_add(1, std::memory_order_relaxed);
}

void MessageRouter::routeDirect(const Message& m) {
    if (m.destination.empty()) {
        unrouted_.fetch_add(1, std::memory_order_relaxed);
        return;
    }
    std::string err;
    if (ipc_.deliver(m.destination, m, err)) {
        delivered_.fetch_add(1, std::memory_order_relaxed);
        return;
    }
    failed_.fetch_add(1, std::memory_order_relaxed);
    if (perf_ != nullptr) perf_->onDropped();

    // A REQUEST that cannot be delivered must fail fast rather than make
    // the caller sit out its full timeout.
    if (m.type == MsgType::REQUEST) {
        sendError(m, "destination unavailable: " + m.destination + " (" + err + ")");
    } else if (logger_ != nullptr) {
        logger_->log(LogLevel::WARN, "MessageRouter",
                     std::string(vsmf::toString(m.type)) + " to " + m.destination + " failed: " + err);
    }
}

void MessageRouter::sendError(const Message& req, const std::string& reason) {
    Message e(MsgType::ERROR, endpoints::kBroker, req.topic, reason, Priority::HIGH);
    e.destination = req.sourceService;
    e.correlationId = req.correlationId;
    std::string err;
    if (!ipc_.deliver(e.destination, e, err) && logger_ != nullptr) {
        logger_->log(LogLevel::WARN, "MessageRouter",
                     "could not report error to " + e.destination + ": " + err);
    }
    if (logger_ != nullptr) logger_->log(LogLevel::WARN, "MessageRouter", reason);
}

}  // namespace vsmf
