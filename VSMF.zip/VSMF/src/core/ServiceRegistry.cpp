#include "core/ServiceRegistry.hpp"

#include <algorithm>
#include <sstream>

#include "common/Utils.hpp"

namespace vsmf {

const char* toString(ServiceKind k) noexcept {
    switch (k) {
        case ServiceKind::Producer: return "PRODUCER";
        case ServiceKind::Consumer: return "CONSUMER";
        case ServiceKind::Support:  return "SUPPORT";
        case ServiceKind::Core:     return "CORE";
    }
    return "UNKNOWN";
}

std::string ServiceInfo::toString() const {
    std::ostringstream os;
    os << name << " [" << vsmf::toString(kind) << "] state=" << vsmf::toString(state)
       << " health=" << vsmf::toString(health) << " endpoint=" << endpoint;
    if (!publishes.empty()) {
        os << " publishes=";
        for (std::size_t i = 0; i < publishes.size(); ++i) os << (i ? "," : "") << publishes[i];
    }
    if (!subscribes.empty()) {
        os << " subscribes=";
        for (std::size_t i = 0; i < subscribes.size(); ++i) os << (i ? "," : "") << subscribes[i];
    }
    return os.str();
}

bool ServiceRegistry::registerService(const ServiceInfo& info, std::string& err) {
    if (info.name.empty()) { err = "service name is empty"; return false; }
    if (info.name.size() > limits::kMaxEndpointName) { err = "service name too long"; return false; }
    for (std::size_t i = 0; i < info.publishes.size(); ++i)
        if (info.publishes[i].size() > limits::kMaxTopicName) { err = "published topic name too long"; return false; }

    std::lock_guard<std::mutex> lk(mu_);
    if (map_.find(info.name) != map_.end()) { err = "service already registered: " + info.name; return false; }

    ServiceInfo copy = info;
    if (copy.endpoint.empty()) copy.endpoint = copy.name;
    copy.registeredAt = util::wallNs();
    copy.lastHeartbeat = util::steadyNs();
    map_[copy.name] = copy;
    return true;
}

bool ServiceRegistry::unregisterService(const std::string& name) {
    std::lock_guard<std::mutex> lk(mu_);
    return map_.erase(name) > 0;
}

bool ServiceRegistry::contains(const std::string& name) const {
    std::lock_guard<std::mutex> lk(mu_);
    return map_.find(name) != map_.end();
}

bool ServiceRegistry::get(const std::string& name, ServiceInfo& out) const {
    std::lock_guard<std::mutex> lk(mu_);
    std::map<std::string, ServiceInfo>::const_iterator it = map_.find(name);
    if (it == map_.end()) return false;
    out = it->second;
    return true;
}

bool ServiceRegistry::setState(const std::string& name, ServiceState s) {
    std::lock_guard<std::mutex> lk(mu_);
    std::map<std::string, ServiceInfo>::iterator it = map_.find(name);
    if (it == map_.end()) return false;
    it->second.state = s;
    return true;
}

bool ServiceRegistry::setHealth(const std::string& name, HealthState h) {
    std::lock_guard<std::mutex> lk(mu_);
    std::map<std::string, ServiceInfo>::iterator it = map_.find(name);
    if (it == map_.end()) return false;
    it->second.health = h;
    return true;
}

bool ServiceRegistry::touchHeartbeat(const std::string& name, std::uint64_t steadyNs) {
    std::lock_guard<std::mutex> lk(mu_);
    std::map<std::string, ServiceInfo>::iterator it = map_.find(name);
    if (it == map_.end()) return false;
    it->second.lastHeartbeat = steadyNs;
    it->second.missedHeartbeats = 0;
    return true;
}

bool ServiceRegistry::setMissedHeartbeats(const std::string& name, std::uint32_t n) {
    std::lock_guard<std::mutex> lk(mu_);
    std::map<std::string, ServiceInfo>::iterator it = map_.find(name);
    if (it == map_.end()) return false;
    it->second.missedHeartbeats = n;
    return true;
}

std::vector<ServiceInfo> ServiceRegistry::list() const {
    std::lock_guard<std::mutex> lk(mu_);
    std::vector<ServiceInfo> out;
    out.reserve(map_.size());
    for (std::map<std::string, ServiceInfo>::const_iterator it = map_.begin(); it != map_.end(); ++it)
        out.push_back(it->second);
    return out;
}

std::vector<std::string> ServiceRegistry::names() const {
    std::lock_guard<std::mutex> lk(mu_);
    std::vector<std::string> out;
    out.reserve(map_.size());
    for (std::map<std::string, ServiceInfo>::const_iterator it = map_.begin(); it != map_.end(); ++it)
        out.push_back(it->first);
    return out;
}

std::vector<ServiceInfo> ServiceRegistry::byKind(ServiceKind k) const {
    std::lock_guard<std::mutex> lk(mu_);
    std::vector<ServiceInfo> out;
    for (std::map<std::string, ServiceInfo>::const_iterator it = map_.begin(); it != map_.end(); ++it)
        if (it->second.kind == k) out.push_back(it->second);
    return out;
}

std::vector<ServiceInfo> ServiceRegistry::publishersOf(const std::string& topic) const {
    std::lock_guard<std::mutex> lk(mu_);
    std::vector<ServiceInfo> out;
    for (std::map<std::string, ServiceInfo>::const_iterator it = map_.begin(); it != map_.end(); ++it) {
        const std::vector<std::string>& v = it->second.publishes;
        if (std::find(v.begin(), v.end(), topic) != v.end()) out.push_back(it->second);
    }
    return out;
}

std::vector<ServiceInfo> ServiceRegistry::subscribersOf(const std::string& topic) const {
    std::lock_guard<std::mutex> lk(mu_);
    std::vector<ServiceInfo> out;
    for (std::map<std::string, ServiceInfo>::const_iterator it = map_.begin(); it != map_.end(); ++it) {
        const std::vector<std::string>& v = it->second.subscribes;
        if (std::find(v.begin(), v.end(), topic) != v.end()) out.push_back(it->second);
    }
    return out;
}

std::size_t ServiceRegistry::size() const {
    std::lock_guard<std::mutex> lk(mu_);
    return map_.size();
}

void ServiceRegistry::clear() {
    std::lock_guard<std::mutex> lk(mu_);
    map_.clear();
}

}  // namespace vsmf
