// =====================================================================
//  src/services/Consumers.cpp
//  DashboardService, DiagnosticService, VehicleControlService.
// =====================================================================
#include <cstdio>
#include <sstream>

#include "common/Utils.hpp"
#include "data/DataGenerator.hpp"
#include "services/DashboardService.hpp"
#include "services/DiagnosticService.hpp"
#include "services/VehicleControlService.hpp"

namespace vsmf {

// ----------------------------- Dashboard -----------------------------
DashboardService::DashboardService(CommunicationManager& cm)
    : ServiceBase("DashboardService", ServiceKind::Consumer, cm), dirty_(true) {
    addSubscription(topics::kSpeed);
    addSubscription(topics::kEngine);
    addSubscription(topics::kBattery);
    addSubscription(topics::kGps);
    addSubscription(topics::kAlert);
    addSubscription(topics::kHealth);
    addSubscription(topics::kPerformance);
}

void DashboardService::onMessage(const Message& m) {
    if (m.type != MsgType::PUBLISH) return;
    double v = 0.0;
    std::lock_guard<std::mutex> lk(mu_);

    if (m.topic == topics::kSpeed) {
        if (decodeNumber(m.payload, "speed", v)) d_.speed = v;
    } else if (m.topic == topics::kEngine) {
        if (decodeNumber(m.payload, "rpm", v)) d_.rpm = v;
        if (decodeNumber(m.payload, "temperature", v)) d_.temperature = v;
    } else if (m.topic == topics::kBattery) {
        if (decodeNumber(m.payload, "battery", v)) d_.battery = v;
    } else if (m.topic == topics::kGps) {
        if (decodeNumber(m.payload, "lat", v)) d_.latitude = v;
        if (decodeNumber(m.payload, "lon", v)) d_.longitude = v;
        if (decodeNumber(m.payload, "satellites", v)) d_.satellites = static_cast<std::uint32_t>(v);
        d_.gpsFix = d_.satellites >= 4;
    } else if (m.topic == topics::kAlert) {
        std::string text;
        if (!decodeString(m.payload, "text", text)) text = util::sanitize(m.payload, 80);
        d_.lastAlert = text;
        d_.lastAlertAt = m.timestamp;
    } else if (m.topic == topics::kHealth) {
        std::string h;
        if (decodeString(m.payload, "state", h)) d_.health = h;
    } else if (m.topic == topics::kPerformance) {
        if (decodeNumber(m.payload, "latency_us", v)) d_.latencyUs = v;
        if (decodeNumber(m.payload, "throughput", v)) d_.throughput = v;
    } else {
        return;                       // unknown topic: nothing to update
    }

    ++d_.updates;
    d_.lastUpdateNs = util::wallNs();
    dirty_.store(true, std::memory_order_release);
}

DashboardData DashboardService::data() const {
    std::lock_guard<std::mutex> lk(mu_);
    return d_;
}

bool DashboardService::consumeDirty() {
    return dirty_.exchange(false, std::memory_order_acq_rel);
}

void DashboardService::setPerfLine(double latencyUs, double throughput) {
    std::lock_guard<std::mutex> lk(mu_);
    d_.latencyUs = latencyUs;
    d_.throughput = throughput;
    dirty_.store(true, std::memory_order_release);
}

// ----------------------------- Diagnostics ---------------------------
const std::size_t DiagnosticService::kKeep;

DiagnosticService::DiagnosticService(CommunicationManager& cm, ConfigManager& cfg)
    : ServiceBase("DiagnosticService", ServiceKind::Consumer, cm), cfg_(cfg), alerts_(0) {
    addSubscription(topics::kSpeed);
    addSubscription(topics::kEngine);
    addSubscription(topics::kBattery);
    addSubscription(topics::kGps);
    addPublishedTopic(topics::kAlert);
}

void DiagnosticService::onMessage(const Message& m) {
    if (m.type != MsgType::PUBLISH) return;
    check(m.topic, m.payload);
}

void DiagnosticService::check(const std::string& topic, const std::string& payload) {
    // Thresholds come from ConfigManager on every evaluation, so a
    // config reload takes effect without restarting the service.
    Config c = cfg_.get();
    double v = 0.0;
    char buf[192];

    // 2% hysteresis band keeps a value sitting on the limit from
    // flip-flopping the alert on every sample.
    const double h = 0.02;

    if (topic == topics::kSpeed && decodeNumber(payload, "speed", v)) {
        if (!overSpeed_ && v > c.speedLimit) {
            overSpeed_ = true;
            std::snprintf(buf, sizeof(buf), "over-speed: %.1f km/h exceeds limit %.1f km/h", v, c.speedLimit);
            raise("CRITICAL", topic, buf);
        } else if (overSpeed_ && v < c.speedLimit * (1.0 - h)) {
            overSpeed_ = false;
            raise("INFO", topic, "speed back within limit");
        }
    } else if (topic == topics::kEngine) {
        if (decodeNumber(payload, "temperature", v)) {
            if (!overTemp_ && v > c.temperatureLimit) {
                overTemp_ = true;
                std::snprintf(buf, sizeof(buf), "over-temperature: %.1f C exceeds limit %.1f C", v, c.temperatureLimit);
                raise("CRITICAL", topic, buf);
            } else if (overTemp_ && v < c.temperatureLimit * (1.0 - h)) {
                overTemp_ = false;
                raise("INFO", topic, "coolant temperature normal");
            }
        }
        if (decodeNumber(payload, "rpm", v)) {
            if (!overRpm_ && v > c.rpmLimit) {
                overRpm_ = true;
                std::snprintf(buf, sizeof(buf), "over-rev: %.0f rpm exceeds limit %.0f rpm", v, c.rpmLimit);
                raise("WARNING", topic, buf);
            } else if (overRpm_ && v < c.rpmLimit * (1.0 - h)) {
                overRpm_ = false;
            }
        }
    } else if (topic == topics::kBattery && decodeNumber(payload, "battery", v)) {
        if (!lowBattery_ && v < c.batteryLimit) {
            lowBattery_ = true;
            std::snprintf(buf, sizeof(buf), "low battery: %.1f%% below limit %.1f%%", v, c.batteryLimit);
            raise("CRITICAL", topic, buf);
        } else if (lowBattery_ && v > c.batteryLimit * (1.0 + h)) {
            lowBattery_ = false;
            raise("INFO", topic, "battery recovered");
        }
    } else if (topic == topics::kGps && decodeNumber(payload, "satellites", v)) {
        bool fix = v >= 4;
        if (!noFix_ && !fix) { noFix_ = true; raise("WARNING", topic, "GPS fix lost"); }
        else if (noFix_ && fix) { noFix_ = false; raise("INFO", topic, "GPS fix restored"); }
    }
}

void DiagnosticService::raise(const std::string& severity, const std::string& topic, const std::string& text) {
    Alert a;
    a.ts = util::wallNs();
    a.severity = severity;
    a.topic = topic;
    a.text = text;
    {
        std::lock_guard<std::mutex> lk(mu_);
        recent_.push_back(a);
        while (recent_.size() > kKeep) recent_.pop_front();   // bounded history
    }
    alerts_.fetch_add(1, std::memory_order_relaxed);

    LogLevel lvl = (severity == "CRITICAL") ? LogLevel::ERROR
                 : (severity == "WARNING")  ? LogLevel::WARN
                                            : LogLevel::INFO;
    logTo(LogChannel::Diagnostics, lvl, "[" + topic + "] " + text);
    log(lvl, text);

    std::string json = "{\"severity\":\"" + severity + "\",\"topic\":\"" + topic +
                       "\",\"text\":\"" + util::sanitize(text, 200) + "\"}";
    publish(topics::kAlert, json, severity == "CRITICAL" ? Priority::CRITICAL : Priority::HIGH);
}

std::vector<Alert> DiagnosticService::recentAlerts(std::size_t n) const {
    std::lock_guard<std::mutex> lk(mu_);
    std::vector<Alert> out;
    if (n == 0 || recent_.empty()) return out;
    std::size_t start = recent_.size() > n ? recent_.size() - n : 0;
    for (std::size_t i = start; i < recent_.size(); ++i) out.push_back(recent_[i]);
    return out;
}

std::string DiagnosticService::summary() const {
    Config c = cfg_.get();
    std::ostringstream os;
    os << "alerts=" << alertCount()
       << " active[speed=" << (overSpeed_ ? "Y" : "N")
       << " temp=" << (overTemp_ ? "Y" : "N")
       << " battery=" << (lowBattery_ ? "Y" : "N")
       << " rpm=" << (overRpm_ ? "Y" : "N")
       << " gps=" << (noFix_ ? "NO-FIX" : "OK") << "]"
       << " limits[speed=" << c.speedLimit << " temp=" << c.temperatureLimit
       << " battery=" << c.batteryLimit << " rpm=" << c.rpmLimit << "]";
    return os.str();
}

// --------------------------- Vehicle control -------------------------
VehicleControlService::VehicleControlService(CommunicationManager& cm, DiscoveryManager& disc,
                                             ConfigManager& cfg, int intervalMs)
    : ServiceBase("VehicleControlService", ServiceKind::Consumer, cm),
      disc_(disc), cfg_(cfg), limp_(false), requests_(0), failures_(0) {
    addSubscription(topics::kSpeed);
    addSubscription(topics::kAlert);
    addPublishedTopic(topics::kAlert);
    setTickInterval(intervalMs > 0 ? intervalMs * 5 : 1000);
}

void VehicleControlService::onMessage(const Message& m) {
    if (m.type == MsgType::REQUEST) {
        std::string err;
        endpoint()->respond(m, "{\"limp_mode\":" + std::string(limp_.load() ? "true" : "false") + "}", err);
        return;
    }
    if (m.type != MsgType::PUBLISH) return;
    if (m.topic == topics::kSpeed) {
        double v = 0.0;
        if (decodeNumber(m.payload, "speed", v)) {
            std::lock_guard<std::mutex> lk(mu_);
            lastSpeed_ = v;
        }
    }
}

void VehicleControlService::onTick() {
    // Discovery first: never assume a peer is there just because it was
    // there last time.
    ServiceInfo info;
    std::string err;
    if (!disc_.discover("BatteryService", info, err)) {
        failures_.fetch_add(1, std::memory_order_relaxed);
        std::lock_guard<std::mutex> lk(mu_);
        lastDecision_ = "battery state unavailable (" + err + ")";
        return;
    }

    Config c = cfg_.get();
    Message resp;
    requests_.fetch_add(1, std::memory_order_relaxed);
    if (!endpoint()->request(info.endpoint, topics::kBattery, "{\"query\":\"state\"}",
                             c.requestTimeoutMs, resp, err)) {
        failures_.fetch_add(1, std::memory_order_relaxed);
        log(LogLevel::WARN, "battery request failed: " + err);
        std::lock_guard<std::mutex> lk(mu_);
        lastDecision_ = "battery request failed: " + err;
        return;
    }

    double pct = 0.0;
    if (!decodeNumber(resp.payload, "battery", pct)) {
        failures_.fetch_add(1, std::memory_order_relaxed);
        log(LogLevel::WARN, "malformed battery response: " + util::sanitize(resp.payload, 120));
        return;
    }

    bool wantLimp = pct < c.batteryLimit;
    bool was = limp_.exchange(wantLimp, std::memory_order_relaxed);
    std::ostringstream os;
    os << "battery " << pct << "% -> " << (wantLimp ? "LIMP MODE" : "normal operation");
    {
        std::lock_guard<std::mutex> lk(mu_);
        lastBattery_ = pct;
        lastDecision_ = os.str();
    }
    if (was != wantLimp) {
        log(wantLimp ? LogLevel::ERROR : LogLevel::INFO, os.str());
        std::string json = std::string("{\"severity\":\"") + (wantLimp ? "CRITICAL" : "INFO") +
                           "\",\"topic\":\"control\",\"text\":\"" +
                           (wantLimp ? "limp mode engaged - low battery" : "limp mode cleared") + "\"}";
        publish(topics::kAlert, json, Priority::CRITICAL);
    }
}

std::string VehicleControlService::status() const {
    std::lock_guard<std::mutex> lk(mu_);
    std::ostringstream os;
    os << "speed=" << lastSpeed_ << " km/h battery=" << lastBattery_ << "% "
       << (limp_.load(std::memory_order_relaxed) ? "LIMP" : "NORMAL")
       << " | " << lastDecision_
       << " | requests=" << requests_.load(std::memory_order_relaxed)
       << " failures=" << failures_.load(std::memory_order_relaxed);
    return os.str();
}

}  // namespace vsmf
