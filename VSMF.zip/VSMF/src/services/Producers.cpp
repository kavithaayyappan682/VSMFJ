// =====================================================================
//  src/services/Producers.cpp
//  SpeedSensorService, EngineSensorService, BatteryService, GPSService.
// =====================================================================
#include "services/BatteryService.hpp"
#include "services/EngineSensorService.hpp"
#include "services/GPSService.hpp"
#include "services/SpeedSensorService.hpp"

namespace vsmf {

// ------------------------------ Speed --------------------------------
SpeedSensorService::SpeedSensorService(CommunicationManager& cm, DataGenerator& gen, int intervalMs)
    : ServiceBase("SpeedSensorService", ServiceKind::Producer, cm), gen_(gen), count_(0) {
    addPublishedTopic(topics::kSpeed);
    setTickInterval(intervalMs > 0 ? intervalMs : 200);
}

bool SpeedSensorService::onStart(std::string& err) {
    (void)err;
    return true;
}

void SpeedSensorService::onTick() {
    // The speed sensor owns the model step; the other producers read the
    // resulting sample, so all four topics describe the same instant.
    VehicleSample s = gen_.step(secondsSinceLastTick());
    if (publish(topics::kSpeed, encodeSpeed(s), Priority::HIGH))
        count_.fetch_add(1, std::memory_order_relaxed);
}

void SpeedSensorService::onMessage(const Message& m) {
    if (m.type != MsgType::REQUEST) return;
    std::string err;
    endpoint()->respond(m, encodeSpeed(gen_.current()), err);
}

// ------------------------------ Engine -------------------------------
EngineSensorService::EngineSensorService(CommunicationManager& cm, DataGenerator& gen, int intervalMs)
    : ServiceBase("EngineSensorService", ServiceKind::Producer, cm), gen_(gen), count_(0) {
    addPublishedTopic(topics::kEngine);
    setTickInterval(intervalMs > 0 ? intervalMs : 200);
}

void EngineSensorService::onTick() {
    VehicleSample s = gen_.current();
    if (publish(topics::kEngine, encodeEngine(s), Priority::NORMAL))
        count_.fetch_add(1, std::memory_order_relaxed);
}

void EngineSensorService::onMessage(const Message& m) {
    if (m.type != MsgType::REQUEST) return;
    std::string err;
    endpoint()->respond(m, encodeEngine(gen_.current()), err);
}

// ------------------------------ Battery ------------------------------
BatteryService::BatteryService(CommunicationManager& cm, DataGenerator& gen, int intervalMs)
    : ServiceBase("BatteryService", ServiceKind::Producer, cm), gen_(gen), served_(0) {
    addPublishedTopic(topics::kBattery);
    setTickInterval(intervalMs > 0 ? intervalMs * 2 : 400);   // pack changes slowly
}

void BatteryService::onTick() {
    publish(topics::kBattery, encodeBattery(gen_.current()), Priority::NORMAL);
}

void BatteryService::onMessage(const Message& m) {
    if (m.type != MsgType::REQUEST) return;
    std::string err;
    if (!endpoint()->respond(m, encodeBattery(gen_.current()), err)) {
        log(LogLevel::WARN, "could not answer request from " + m.sourceService + ": " + err);
        return;
    }
    served_.fetch_add(1, std::memory_order_relaxed);
    log(LogLevel::DEBUG, "served battery request from " + m.sourceService);
}

// ------------------------------ GPS ----------------------------------
GPSService::GPSService(CommunicationManager& cm, DataGenerator& gen, int intervalMs)
    : ServiceBase("GPSService", ServiceKind::Producer, cm), gen_(gen), fix_(true) {
    addPublishedTopic(topics::kGps);
    setTickInterval(intervalMs > 0 ? intervalMs * 5 : 1000);
}

void GPSService::onTick() {
    VehicleSample s = gen_.current();
    bool was = fix_.exchange(s.gpsFix, std::memory_order_relaxed);
    if (was && !s.gpsFix) log(LogLevel::WARN, "GPS fix lost");
    if (!was && s.gpsFix) log(LogLevel::INFO, "GPS fix reacquired");
    publish(topics::kGps, encodeGps(s), s.gpsFix ? Priority::LOW : Priority::HIGH);
}

void GPSService::onMessage(const Message& m) {
    if (m.type != MsgType::REQUEST) return;
    std::string err;
    endpoint()->respond(m, encodeGps(gen_.current()), err);
}

}  // namespace vsmf
