#include "services/ServiceBase.hpp"

#include <chrono>

#include "common/Utils.hpp"
#include "support/PerformanceMonitor.hpp"

namespace vsmf {

ServiceBase::ServiceBase(const std::string& name, ServiceKind kind, CommunicationManager& cm)
    : name_(name), kind_(kind), cm_(cm),
      state_(static_cast<std::uint8_t>(ServiceState::CREATED)),
      running_(false), paused_(false) {}

ServiceBase::~ServiceBase() {
    // A subclass must not still be receiving callbacks while its own
    // members are being destroyed.
    stop();
}

void ServiceBase::setState(ServiceState s) {
    state_.store(static_cast<std::uint8_t>(s), std::memory_order_release);
    cm_.registry().setState(name_, s);
}

bool ServiceBase::start() {
    std::lock_guard<std::mutex> lk(lifecycleMu_);
    ServiceState st = state();
    if (st == ServiceState::RUNNING || st == ServiceState::STARTING) return true;   // idempotent
    setState(ServiceState::STARTING);
    lastError_.clear();

    std::string err;

    // 1. Registration (skipped when restarting an already-known service).
    if (!cm_.registry().contains(name_)) {
        ServiceInfo info;
        info.name = name_;
        info.endpoint = name_;
        info.kind = kind_;
        info.publishes = publishes_;
        info.subscribes = subscribes_;
        info.state = ServiceState::STARTING;
        if (!cm_.registry().registerService(info, err)) {
            lastError_ = err;
            setState(ServiceState::FAILED);
            log(LogLevel::ERROR, "registration failed: " + err);
            return false;
        }
        log(LogLevel::INFO, "registered with ServiceRegistry");
    }

    // 2. Transport endpoint.
    if (!ep_) {
        ep_ = cm_.createEndpoint(name_, err);
        if (!ep_) {
            lastError_ = err;
            setState(ServiceState::FAILED);
            log(LogLevel::ERROR, "endpoint failed: " + err);
            return false;
        }
        ep_->setHandler([this](const Message& m) {
            if (paused_.load(std::memory_order_acquire)) {
                // Paused: refuse work but stay answerable so the caller is
                // not left waiting for a timeout.
                if (m.type == MsgType::REQUEST) {
                    std::string e;
                    ep_->respondError(m, name_ + " is paused", e);
                }
                return;
            }
            try {
                onMessage(m);
            } catch (const std::exception& ex) {
                log(LogLevel::ERROR, std::string("onMessage threw: ") + ex.what());
            } catch (...) {
                log(LogLevel::ERROR, "onMessage threw an unknown exception");
            }
        });
    }

    // 3. Subscriptions.
    for (std::size_t i = 0; i < subscribes_.size(); ++i) {
        std::string serr;
        if (!ep_->subscribe(subscribes_[i], serr))
            log(LogLevel::WARN, "subscribe(" + subscribes_[i] + ") failed: " + serr);
    }

    // 4. Subclass start.
    if (!onStart(err)) {
        lastError_ = err.empty() ? "onStart() failed" : err;
        setState(ServiceState::FAILED);
        log(LogLevel::ERROR, "start failed: " + lastError_);
        return false;
    }

    // 5. Periodic worker.
    running_.store(true, std::memory_order_release);
    paused_.store(false, std::memory_order_release);
    if (tickMs_ > 0) {
        try {
            th_ = std::thread(&ServiceBase::workerLoop, this);
        } catch (const std::system_error& e) {
            running_.store(false, std::memory_order_release);
            lastError_ = std::string("cannot start worker thread: ") + e.what();
            setState(ServiceState::FAILED);
            return false;
        }
    }
    setState(ServiceState::RUNNING);
    log(LogLevel::INFO, "started");
    return true;
}

void ServiceBase::stop() {
    std::lock_guard<std::mutex> lk(lifecycleMu_);
    ServiceState st = state();
    if (st == ServiceState::STOPPED || st == ServiceState::CREATED) {
        if (th_.joinable()) th_.join();      // tidy up a failed start
        return;
    }
    setState(ServiceState::STOPPING);

    running_.store(false, std::memory_order_release);
    cv_.notify_all();
    if (th_.joinable()) {
        if (th_.get_id() == std::this_thread::get_id()) th_.detach();   // stop() from onTick()
        else th_.join();
    }

    try {
        onStop();
    } catch (...) {
        log(LogLevel::ERROR, "onStop threw");
    }

    if (ep_) {
        cm_.destroyEndpoint(name_);   // closes socket, drops subscriptions
        ep_.reset();
    }
    // The registry entry survives with state STOPPED rather than being
    // removed: the console must still be able to list the service and
    // restart it, and discovery already filters on RUNNING.
    setState(ServiceState::STOPPED);
    log(LogLevel::INFO, "stopped");
}

void ServiceBase::pause() {
    std::lock_guard<std::mutex> lk(lifecycleMu_);
    if (state() != ServiceState::RUNNING) return;
    paused_.store(true, std::memory_order_release);
    setState(ServiceState::PAUSED);
    cv_.notify_all();
    log(LogLevel::INFO, "paused");
}

void ServiceBase::resume() {
    std::lock_guard<std::mutex> lk(lifecycleMu_);
    if (state() != ServiceState::PAUSED) return;
    paused_.store(false, std::memory_order_release);
    setState(ServiceState::RUNNING);
    cv_.notify_all();
    log(LogLevel::INFO, "resumed");
}

void ServiceBase::workerLoop() {
    std::uint64_t last = util::steadyNs();
    while (running_.load(std::memory_order_acquire)) {
        {
            std::unique_lock<std::mutex> lk(cvMu_);
            cv_.wait_for(lk, std::chrono::milliseconds(tickMs_),
                         [this] { return !running_.load(std::memory_order_acquire); });
        }
        if (!running_.load(std::memory_order_acquire)) break;
        if (paused_.load(std::memory_order_acquire)) { last = util::steadyNs(); continue; }

        std::uint64_t now = util::steadyNs();
        lastDt_ = static_cast<double>(now - last) / 1e9;
        last = now;
        try {
            onTick();
        } catch (const std::exception& e) {
            log(LogLevel::ERROR, std::string("onTick threw: ") + e.what());
        } catch (...) {
            log(LogLevel::ERROR, "onTick threw an unknown exception");
        }
    }
}

bool ServiceBase::publish(const std::string& topic, const std::string& payload, Priority p) {
    if (!ep_) return false;
    if (paused_.load(std::memory_order_acquire)) return false;
    std::string err;
    if (!ep_->publish(topic, payload, p, err)) {
        log(LogLevel::WARN, "publish(" + topic + ") failed: " + err);
        return false;
    }
    return true;
}

void ServiceBase::log(LogLevel lvl, const std::string& msg) {
    if (cm_.logger() != nullptr) cm_.logger()->log(lvl, name_, msg);
}

void ServiceBase::logTo(LogChannel ch, LogLevel lvl, const std::string& msg) {
    if (cm_.logger() != nullptr) cm_.logger()->logTo(ch, lvl, name_, msg);
}

}  // namespace vsmf
