#include "services/ControlService.hpp"

#include <cstdio>
#include <sstream>

#include "common/Utils.hpp"

namespace vsmf {

ControlService::ControlService(CommunicationManager& cm, const SystemContext& ctx)
    : ServiceBase(endpoints::kControl, ServiceKind::Support, cm), ctx_(ctx) {
    addPublishedTopic(topics::kSpeed);
    addPublishedTopic(topics::kControl);
}

void ControlService::onMessage(const Message& m) {
    if (m.type != MsgType::REQUEST) return;
    std::string reply;
    try {
        reply = execute(m.payload);
    } catch (const std::exception& e) {
        reply = std::string("command failed: ") + e.what();
    } catch (...) {
        reply = "command failed: unknown error";
    }
    std::string err;
    if (!endpoint()->respond(m, reply, err))
        log(LogLevel::WARN, "could not answer console: " + err);
}

std::string ControlService::help() {
    return
        "commands:\n"
        "  services                 list registered services and their state\n"
        "  discover <Service>       resolve a service through DiscoveryManager\n"
        "  publish_speed <kph>      inject a speed value and publish it\n"
        "  battery                  request/response call to BatteryService\n"
        "  diagnostics              diagnostic state and recent alerts\n"
        "  metrics                  performance counters\n"
        "  logs [channel] [n]       tail middleware|performance|diagnostics|health\n"
        "  status                   vehicle control status\n"
        "  health                   heartbeat report\n"
        "  config                   effective configuration\n"
        "  reload                   re-read the JSON configuration\n"
        "  restart <Service>        stop and start a service\n"
        "  pause|resume <Service>   lifecycle control\n"
        "  shutdown                 stop the whole framework\n"
        "  exit                     leave the console (framework keeps running)\n"
        "  help                     this text";
}

std::string ControlService::execute(const std::string& line) {
    std::vector<std::string> tok = util::splitWhitespace(util::trim(line), 3);
    if (tok.empty()) return "";                       // bare Enter: no noise
    std::string cmd = util::toLower(tok[0]);
    const std::string a1 = tok.size() > 1 ? tok[1] : std::string();

    if (cmd == "help" || cmd == "?")   return help();
    if (cmd == "services")             return cmdServices();
    if (cmd == "discover") {
        if (a1.empty()) return "usage: discover <ServiceName>";
        return cmdDiscover(a1);
    }
    if (cmd == "publish_speed") {
        if (a1.empty()) return "usage: publish_speed <kph>";
        return cmdPublishSpeed(a1);
    }
    if (cmd == "battery")     return cmdBattery();
    if (cmd == "diagnostics") return cmdDiagnostics();
    if (cmd == "metrics")     return cmdMetrics();
    if (cmd == "logs")        return cmdLogs(tok);
    if (cmd == "status")      return cmdStatus();
    if (cmd == "health")      return cmdHealth();
    if (cmd == "config")      return cmdConfig();
    if (cmd == "reload")      return cmdReload();
    if (cmd == "restart" || cmd == "pause" || cmd == "resume" || cmd == "start" || cmd == "stop") {
        if (a1.empty()) return "usage: " + cmd + " <ServiceName>";
        return cmdLifecycle(cmd, a1);
    }
    if (cmd == "shutdown") {
        if (ctx_.shutdownFlag == nullptr) return "shutdown is not available";
        ctx_.shutdownFlag->store(true, std::memory_order_release);
        log(LogLevel::WARN, "shutdown requested from console");
        return "shutdown requested; the framework is stopping";
    }
    if (cmd == "exit" || cmd == "quit") return "bye";
    return "unknown command '" + util::sanitize(tok[0], 32) + "'. Type 'help'.";
}

std::string ControlService::cmdServices() const {
    if (ctx_.registry == nullptr) return "registry unavailable";
    std::vector<ServiceInfo> all = ctx_.registry->list();
    if (all.empty()) return "no services registered";
    std::ostringstream os;
    os << "registered services (" << all.size() << "):";
    char buf[256];
    for (std::size_t i = 0; i < all.size(); ++i) {
        std::snprintf(buf, sizeof(buf), "\n  %-24s %-9s %-9s %-9s",
                      all[i].name.c_str(), vsmf::toString(all[i].kind),
                      vsmf::toString(all[i].state), vsmf::toString(all[i].health));
        os << buf;
    }
    return os.str();
}

std::string ControlService::cmdDiscover(const std::string& name) const {
    if (ctx_.discovery == nullptr) return "discovery unavailable";
    ServiceInfo info;
    std::string err;
    if (ctx_.discovery->discover(name, info, err)) {
        std::ostringstream os;
        os << "found: " << info.toString();
        if (!err.empty()) os << "\n  note: " << err;
        return os.str();
    }
    // Not usable - but say whether it exists at all, which is the thing
    // an operator actually wants to know.
    ServiceInfo raw;
    if (ctx_.discovery->lookup(name, raw))
        return "not available: " + err + "\n  registered as: " + raw.toString();
    return "not found: " + name;
}

std::string ControlService::cmdPublishSpeed(const std::string& arg) {
    double v = 0.0;
    if (!util::parseDouble(arg, v)) return "not a number: " + util::sanitize(arg, 32);
    if (ctx_.generator == nullptr) return "data generator unavailable";
    std::string err;
    if (!ctx_.generator->setSpeed(v, err)) return "rejected: " + err;

    // Publish immediately so the dashboard reacts without waiting for the
    // sensor's next tick.
    VehicleSample s = ctx_.generator->current();
    if (!publish(topics::kSpeed, encodeSpeed(s), Priority::HIGH))
        return "speed model updated, but publish failed";
    char buf[96];
    std::snprintf(buf, sizeof(buf), "speed set to %.1f km/h and published on %s", v, topics::kSpeed);
    return buf;
}

std::string ControlService::cmdBattery() {
    if (ctx_.discovery == nullptr) return "discovery unavailable";
    ServiceInfo info;
    std::string err;
    if (!ctx_.discovery->discover("BatteryService", info, err)) return "BatteryService: " + err;

    Config c = ctx_.cfg != nullptr ? ctx_.cfg->get() : Config();
    Message resp;
    if (!endpoint()->request(info.endpoint, topics::kBattery, "{\"query\":\"state\"}",
                             c.requestTimeoutMs, resp, err))
        return "request failed: " + err;

    double pct = 0.0, volts = 0.0;
    decodeNumber(resp.payload, "battery", pct);
    decodeNumber(resp.payload, "voltage", volts);
    char buf[192];
    std::snprintf(buf, sizeof(buf),
                  "BatteryService responded: %.1f %% (%.2f V) [request/response over UDS, corr=%llu]",
                  pct, volts, static_cast<unsigned long long>(resp.correlationId));
    return buf;
}

std::string ControlService::cmdDiagnostics() const {
    if (ctx_.diagnostics == nullptr) return "diagnostics unavailable";
    std::ostringstream os;
    os << ctx_.diagnostics->summary();
    std::vector<Alert> recent = ctx_.diagnostics->recentAlerts(10);
    if (recent.empty()) {
        os << "\n  no alerts raised";
    } else {
        os << "\n  last " << recent.size() << " alerts:";
        for (std::size_t i = 0; i < recent.size(); ++i)
            os << "\n    " << util::formatWallTime(recent[i].ts) << "  [" << recent[i].severity
               << "] " << recent[i].topic << ": " << recent[i].text;
    }
    return os.str();
}

std::string ControlService::cmdMetrics() const {
    if (ctx_.perf == nullptr) return "performance monitor unavailable";
    PerfSnapshot s = ctx_.perf->snapshot();
    std::ostringstream os;
    os << s.toString();
    if (ctx_.pool != nullptr) {
        os << "\n  thread pool: threads=" << ctx_.pool->threadCount()
           << " queued=" << ctx_.pool->queueDepth()
           << " submitted=" << ctx_.pool->submitted()
           << " completed=" << ctx_.pool->completed()
           << " dropped=" << ctx_.pool->dropped()
           << " failed=" << ctx_.pool->failed();
    }
    if (ctx_.comm != nullptr) {
        os << "\n  transport: connections=" << ctx_.comm->ipc().connectionCount()
           << " in=" << ctx_.comm->ipc().framesIn()
           << " out=" << ctx_.comm->ipc().framesOut()
           << " dropped=" << ctx_.comm->ipc().framesDropped()
           << " malformed=" << ctx_.comm->ipc().framesBad();
        os << "\n  router: routed=" << ctx_.comm->router().routed()
           << " delivered=" << ctx_.comm->router().delivered()
           << " unrouted=" << ctx_.comm->router().unrouted()
           << " failed=" << ctx_.comm->router().failed();
        os << "\n  pubsub: topics=" << ctx_.comm->pubsub().topicCount()
           << " subscriptions=" << ctx_.comm->pubsub().subscriptionCount();
    }
    if (ctx_.logger != nullptr)
        os << "\n  logger: written=" << ctx_.logger->written() << " dropped=" << ctx_.logger->dropped();
    return os.str();
}

std::string ControlService::cmdLogs(const std::vector<std::string>& args) const {
    if (ctx_.logger == nullptr) return "logger unavailable";
    LogChannel ch = LogChannel::Middleware;
    std::size_t n = 15;

    // Accept "logs", "logs 30", "logs health", "logs health 30".
    for (std::size_t i = 1; i < args.size(); ++i) {
        std::vector<std::string> parts = util::splitWhitespace(args[i]);
        for (std::size_t k = 0; k < parts.size(); ++k) {
            std::string t = util::toLower(parts[k]);
            long long num = 0;
            if (util::parseInt(t, num)) {
                if (num < 1) num = 1;
                if (num > 200) num = 200;               // do not flood the console
                n = static_cast<std::size_t>(num);
            } else if (t == "middleware") ch = LogChannel::Middleware;
            else if (t == "performance")  ch = LogChannel::Performance;
            else if (t == "diagnostics")  ch = LogChannel::Diagnostics;
            else if (t == "health")       ch = LogChannel::Health;
            else return "unknown log channel '" + util::sanitize(t, 24) +
                        "' (middleware|performance|diagnostics|health)";
        }
    }

    // Flush first: the logger is asynchronous, so without this the tail
    // would show whatever happened to be on disk one buffer ago.
    ctx_.logger->flush();
    std::vector<std::string> lines = ctx_.logger->tail(ch, n);
    if (lines.empty()) return "no log entries in " + ctx_.logger->fileFor(ch);
    std::ostringstream os;
    os << "last " << lines.size() << " lines of " << ctx_.logger->fileFor(ch) << ":";
    for (std::size_t i = 0; i < lines.size(); ++i) os << "\n  " << lines[i];
    return os.str();
}

std::string ControlService::cmdStatus() const {
    std::ostringstream os;
    if (ctx_.control != nullptr) os << "vehicle control: " << ctx_.control->status();
    else os << "vehicle control unavailable";
    if (ctx_.dashboard != nullptr) {
        DashboardData d = ctx_.dashboard->data();
        char buf[256];
        std::snprintf(buf, sizeof(buf),
                      "\ndashboard: speed=%.1f km/h rpm=%.0f temp=%.1f C battery=%.1f%% gps=%s updates=%llu",
                      d.speed, d.rpm, d.temperature, d.battery, d.gpsFix ? "FIX" : "NO-FIX",
                      static_cast<unsigned long long>(d.updates));
        os << buf;
    }
    if (ctx_.comm != nullptr)
        os << "\ntransport: " << (ctx_.comm->isRunning() ? "UP" : "DOWN")
           << " on " << ctx_.comm->ipc().socketPath();
    return os.str();
}

std::string ControlService::cmdHealth() const {
    if (ctx_.health == nullptr) return "health monitor unavailable";
    return ctx_.health->report().toString();
}

std::string ControlService::cmdConfig() const {
    if (ctx_.cfg == nullptr) return "config manager unavailable";
    std::ostringstream os;
    os << "config file: " << (ctx_.cfg->path().empty() ? "<defaults>" : ctx_.cfg->path())
       << "\n  " << ctx_.cfg->get().toString();
    std::vector<std::string> w = ctx_.cfg->warnings();
    for (std::size_t i = 0; i < w.size(); ++i) os << "\n  warning: " << w[i];
    return os.str();
}

std::string ControlService::cmdReload() {
    if (ctx_.cfg == nullptr) return "config manager unavailable";
    std::string err;
    if (!ctx_.cfg->reloadIfChanged(err))
        return err.empty() ? "configuration unchanged" : ("not reloaded: " + err);

    // Apply what can be applied live. Thread pool size and socket path
    // deliberately need a restart; say so rather than pretending.
    Config c = ctx_.cfg->get();
    if (ctx_.logger != nullptr) ctx_.logger->setMinLevel(c.logLevel);
    log(LogLevel::INFO, "configuration reloaded from " + ctx_.cfg->path());
    return "reloaded: " + c.toString() +
           "\n  note: thread_pool_size and socket_path take effect on restart";
}

std::string ControlService::cmdLifecycle(const std::string& verb, const std::string& name) {
    if (ctx_.lifecycle == nullptr) return "lifecycle manager unavailable";
    if (name == this->name()) return "refusing to " + verb + " the console service itself";
    std::string err;
    bool ok = false;
    if (verb == "restart")     ok = ctx_.lifecycle->restart(name, err);
    else if (verb == "pause")  ok = ctx_.lifecycle->pause(name, err);
    else if (verb == "resume") ok = ctx_.lifecycle->resume(name, err);
    else if (verb == "start")  ok = ctx_.lifecycle->start(name, err);
    else if (verb == "stop")   ok = ctx_.lifecycle->stop(name, err);
    else return "unsupported lifecycle verb: " + verb;

    if (!ok) return verb + " failed: " + err;
    ServiceInfo info;
    if (ctx_.registry != nullptr && ctx_.registry->get(name, info))
        return name + " " + verb + " ok, now " + vsmf::toString(info.state);
    return name + " " + verb + " ok";
}

}  // namespace vsmf
