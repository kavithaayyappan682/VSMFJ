#include "support/LifecycleManager.hpp"

#include "support/LoggerService.hpp"

namespace vsmf {

bool LifecycleManager::isLegalTransition(ServiceState from, ServiceState to) {
    if (from == to) return true;                       // idempotent calls
    switch (from) {
        case ServiceState::CREATED:  return to == ServiceState::STARTING || to == ServiceState::STOPPED;
        case ServiceState::STARTING: return to == ServiceState::RUNNING || to == ServiceState::FAILED ||
                                            to == ServiceState::STOPPING;
        case ServiceState::RUNNING:  return to == ServiceState::PAUSED || to == ServiceState::STOPPING ||
                                            to == ServiceState::FAILED;
        case ServiceState::PAUSED:   return to == ServiceState::RUNNING || to == ServiceState::STOPPING;
        case ServiceState::STOPPING: return to == ServiceState::STOPPED || to == ServiceState::FAILED;
        case ServiceState::STOPPED:  return to == ServiceState::STARTING;
        case ServiceState::FAILED:   return to == ServiceState::STARTING || to == ServiceState::STOPPING ||
                                            to == ServiceState::STOPPED;
    }
    return false;
}

const char* LifecycleManager::transitionError(ServiceState from, ServiceState to) {
    (void)to;
    switch (from) {
        case ServiceState::PAUSED:   return "service is paused";
        case ServiceState::STOPPED:  return "service is stopped";
        case ServiceState::FAILED:   return "service has failed";
        case ServiceState::STOPPING: return "service is shutting down";
        case ServiceState::STARTING: return "service is still starting";
        default: break;
    }
    return "illegal state transition";
}

void LifecycleManager::log(LogLevel lvl, const std::string& msg) {
    if (logger_ != nullptr) logger_->log(lvl, "LifecycleManager", msg);
}

bool LifecycleManager::add(IService* s, std::string& err) {
    if (s == nullptr) { err = "null service"; return false; }
    std::lock_guard<std::mutex> lk(mu_);
    if (findLocked(s->name()) != nullptr) { err = "duplicate service: " + s->name(); return false; }
    services_.push_back(s);
    return true;
}

IService* LifecycleManager::findLocked(const std::string& name) const {
    for (std::size_t i = 0; i < services_.size(); ++i)
        if (services_[i]->name() == name) return services_[i];
    return nullptr;
}

IService* LifecycleManager::find(const std::string& name) const {
    std::lock_guard<std::mutex> lk(mu_);
    return findLocked(name);
}

bool LifecycleManager::startAll(std::string& err) {
    std::vector<IService*> copy;
    {
        std::lock_guard<std::mutex> lk(mu_);
        copy = services_;
    }
    bool allOk = true;
    for (std::size_t i = 0; i < copy.size(); ++i) {
        if (!copy[i]->start()) {
            allOk = false;
            // Keep going: a vehicle with a failed GPS should still have
            // brakes, dashboards and diagnostics.
            std::string m = "service failed to start: " + copy[i]->name();
            if (err.empty()) err = m; else err += "; " + copy[i]->name();
            log(LogLevel::ERROR, m);
        }
    }
    return allOk;
}

void LifecycleManager::stopAll() {
    std::vector<IService*> copy;
    {
        std::lock_guard<std::mutex> lk(mu_);
        copy = services_;
    }
    for (std::size_t i = copy.size(); i > 0; --i) {
        IService* s = copy[i - 1];
        try {
            s->stop();
        } catch (...) {
            log(LogLevel::ERROR, "exception while stopping " + s->name());
        }
    }
}

bool LifecycleManager::start(const std::string& name, std::string& err) {
    IService* s = find(name);
    if (s == nullptr) { err = "unknown service: " + name; return false; }
    ServiceState st = s->state();
    if (st == ServiceState::RUNNING) return true;
    if (!isLegalTransition(st, ServiceState::STARTING)) {
        err = std::string("cannot start ") + name + ": " + transitionError(st, ServiceState::STARTING);
        return false;
    }
    if (!s->start()) { err = "start failed for " + name; return false; }
    log(LogLevel::INFO, name + " started");
    return true;
}

bool LifecycleManager::stop(const std::string& name, std::string& err) {
    IService* s = find(name);
    if (s == nullptr) { err = "unknown service: " + name; return false; }
    ServiceState st = s->state();
    if (st == ServiceState::STOPPED || st == ServiceState::CREATED) return true;
    s->stop();
    log(LogLevel::INFO, name + " stopped");
    return true;
}

bool LifecycleManager::pause(const std::string& name, std::string& err) {
    IService* s = find(name);
    if (s == nullptr) { err = "unknown service: " + name; return false; }
    ServiceState st = s->state();
    if (st == ServiceState::PAUSED) return true;
    if (!isLegalTransition(st, ServiceState::PAUSED)) {
        err = std::string("cannot pause ") + name + ": " + transitionError(st, ServiceState::PAUSED);
        return false;
    }
    s->pause();
    log(LogLevel::INFO, name + " paused");
    return true;
}

bool LifecycleManager::resume(const std::string& name, std::string& err) {
    IService* s = find(name);
    if (s == nullptr) { err = "unknown service: " + name; return false; }
    ServiceState st = s->state();
    if (st == ServiceState::RUNNING) return true;
    if (st != ServiceState::PAUSED) {
        err = std::string("cannot resume ") + name + ": " + transitionError(st, ServiceState::RUNNING);
        return false;
    }
    s->resume();
    log(LogLevel::INFO, name + " resumed");
    return true;
}

bool LifecycleManager::restart(const std::string& name, std::string& err) {
    IService* s = find(name);
    if (s == nullptr) { err = "unknown service: " + name; return false; }
    log(LogLevel::INFO, "restarting " + name);
    s->stop();                       // stop() is idempotent and safe here
    if (!s->start()) {
        err = "restart failed for " + name + " (service left stopped)";
        log(LogLevel::ERROR, err);
        return false;
    }
    log(LogLevel::INFO, name + " restarted");
    return true;
}

std::vector<std::string> LifecycleManager::names() const {
    std::lock_guard<std::mutex> lk(mu_);
    std::vector<std::string> out;
    out.reserve(services_.size());
    for (std::size_t i = 0; i < services_.size(); ++i) out.push_back(services_[i]->name());
    return out;
}

std::size_t LifecycleManager::size() const {
    std::lock_guard<std::mutex> lk(mu_);
    return services_.size();
}

}  // namespace vsmf
