#include "support/ThreadPool.hpp"

#include <algorithm>

#include "common/Utils.hpp"
#include "support/LoggerService.hpp"

namespace vsmf {

ThreadPool::ThreadPool()
    : running_(false), drain_(true), submitted_(0), completed_(0), dropped_(0), failed_(0) {}

ThreadPool::~ThreadPool() { stop(false); }

bool ThreadPool::start(std::size_t threads, std::size_t capacity) {
    if (running_.load(std::memory_order_acquire)) return false;
    threads  = util::clampValue(threads, limits::kMinThreads, limits::kMaxThreads);
    capacity = util::clampValue(capacity, static_cast<std::size_t>(16), limits::kMaxQueueDepth);
    {
        std::lock_guard<std::mutex> lk(mu_);
        capacity_ = capacity;
        q_.clear();
        peak_ = 0;
    }
    running_.store(true, std::memory_order_release);
    workers_.reserve(threads);
    for (std::size_t i = 0; i < threads; ++i) {
        try {
            workers_.push_back(std::thread(&ThreadPool::worker, this));
        } catch (const std::system_error&) {
            // Cannot spawn the full pool (RLIMIT_NPROC). Run with what we
            // got - a smaller pool is far better than no middleware.
            if (logger_ != nullptr)
                logger_->log(LogLevel::WARN, "ThreadPool",
                             "could only start " + std::to_string(workers_.size()) + " of " +
                             std::to_string(threads) + " worker threads");
            break;
        }
    }
    if (workers_.empty()) {
        running_.store(false, std::memory_order_release);
        return false;
    }
    return true;
}

void ThreadPool::stop(bool drain) {
    if (!running_.exchange(false, std::memory_order_acq_rel)) {
        // Still make sure a half-constructed pool is joined.
        for (std::size_t i = 0; i < workers_.size(); ++i)
            if (workers_[i].joinable()) workers_[i].join();
        workers_.clear();
        return;
    }
    drain_.store(drain, std::memory_order_release);
    cv_.notify_all();

    std::thread::id self = std::this_thread::get_id();
    for (std::size_t i = 0; i < workers_.size(); ++i) {
        if (!workers_[i].joinable()) continue;
        if (workers_[i].get_id() == self) {
            // A task called stop(). Joining ourselves would deadlock.
            workers_[i].detach();
            continue;
        }
        workers_[i].join();
    }
    workers_.clear();
    if (!drain) {
        std::lock_guard<std::mutex> lk(mu_);
        q_.clear();
    }
}

bool ThreadPool::submit(Task t, Priority p) {
    if (!t) return false;
    if (!running_.load(std::memory_order_acquire)) {
        dropped_.fetch_add(1, std::memory_order_relaxed);
        return false;
    }
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (q_.size() >= capacity_) {
            // Full. CRITICAL work evicts the oldest LOW item; everything
            // else is rejected so the caller can account for the loss.
            if (p == Priority::CRITICAL) {
                std::deque<Item>::iterator victim = q_.end();
                for (std::deque<Item>::iterator it = q_.begin(); it != q_.end(); ++it)
                    if (it->prio == Priority::LOW) { victim = it; break; }
                if (victim == q_.end()) {
                    dropped_.fetch_add(1, std::memory_order_relaxed);
                    return false;
                }
                q_.erase(victim);
                dropped_.fetch_add(1, std::memory_order_relaxed);
            } else {
                dropped_.fetch_add(1, std::memory_order_relaxed);
                return false;
            }
        }
        Item it;
        it.fn = t;
        it.prio = p;
        it.seq = seq_++;
        // Insert before the first item of strictly lower priority: O(n) in
        // the worst case but the queue is short in practice and this keeps
        // FIFO fairness within a priority class.
        std::deque<Item>::iterator pos = q_.begin();
        while (pos != q_.end() && static_cast<int>(pos->prio) >= static_cast<int>(p)) ++pos;
        q_.insert(pos, it);
        if (q_.size() > peak_) peak_ = q_.size();
    }
    submitted_.fetch_add(1, std::memory_order_relaxed);
    cv_.notify_one();
    return true;
}

void ThreadPool::worker() {
    for (;;) {
        Item item;
        {
            std::unique_lock<std::mutex> lk(mu_);
            cv_.wait(lk, [this] { return !q_.empty() || !running_.load(std::memory_order_acquire); });
            if (q_.empty()) {
                if (!running_.load(std::memory_order_acquire)) return;
                continue;                                  // spurious wakeup
            }
            if (!running_.load(std::memory_order_acquire) && !drain_.load(std::memory_order_acquire)) return;
            item = q_.front();
            q_.pop_front();
        }
        try {
            item.fn();
            completed_.fetch_add(1, std::memory_order_relaxed);
        } catch (const std::exception& e) {
            failed_.fetch_add(1, std::memory_order_relaxed);
            if (logger_ != nullptr)
                logger_->log(LogLevel::ERROR, "ThreadPool", std::string("task threw: ") + e.what());
        } catch (...) {
            failed_.fetch_add(1, std::memory_order_relaxed);
            if (logger_ != nullptr)
                logger_->log(LogLevel::ERROR, "ThreadPool", "task threw an unknown exception");
        }
    }
}

std::size_t ThreadPool::queueDepth() const {
    std::lock_guard<std::mutex> lk(mu_);
    return q_.size();
}

std::size_t ThreadPool::peakDepth() const {
    std::lock_guard<std::mutex> lk(mu_);
    return peak_;
}

}  // namespace vsmf
