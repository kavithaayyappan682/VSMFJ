#include "support/Json.hpp"

#include <cctype>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>

namespace vsmf {

namespace {
const std::string kEmptyString;
const std::vector<JsonValue> kEmptyArray;

// Recursion guard: a deeply nested document must not blow the C stack.
constexpr int kMaxDepth = 64;

class Parser {
public:
    Parser(const std::string& t) : s_(t), i_(0), line_(1), col_(1) {}

    bool run(JsonValue& out, std::string& err) {
        skipWs();
        if (!parseValue(out, 0)) { err = err_; return false; }
        skipWs();
        if (i_ != s_.size()) { fail("trailing characters after top-level value"); err = err_; return false; }
        return true;
    }

private:
    const std::string& s_;
    std::size_t i_;
    int line_, col_;
    std::string err_;

    void fail(const std::string& msg) {
        if (err_.empty()) {
            std::ostringstream os;
            os << "line " << line_ << " col " << col_ << ": " << msg;
            err_ = os.str();
        }
    }
    bool eof() const { return i_ >= s_.size(); }
    char peek() const { return s_[i_]; }
    char get() {
        char c = s_[i_++];
        if (c == '\n') { ++line_; col_ = 1; } else { ++col_; }
        return c;
    }
    void skipWs() {
        while (!eof()) {
            char c = peek();
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') { get(); continue; }
            break;
        }
    }
    bool expect(char c) {
        skipWs();
        if (eof() || peek() != c) {
            std::string m = "expected '"; m += c; m += "'";
            fail(m);
            return false;
        }
        get();
        return true;
    }

    bool parseValue(JsonValue& out, int depth) {
        if (depth > kMaxDepth) { fail("nesting too deep"); return false; }
        skipWs();
        if (eof()) { fail("unexpected end of input"); return false; }
        char c = peek();
        switch (c) {
            case '{': return parseObject(out, depth);
            case '[': return parseArray(out, depth);
            case '"': {
                std::string sv;
                if (!parseString(sv)) return false;
                out = JsonValue::makeString(sv);
                return true;
            }
            case 't': return parseLiteral("true",  JsonValue::makeBool(true),  out);
            case 'f': return parseLiteral("false", JsonValue::makeBool(false), out);
            case 'n': return parseLiteral("null",  JsonValue::makeNull(),      out);
            default:  return parseNumber(out);
        }
    }

    bool parseLiteral(const char* lit, const JsonValue& v, JsonValue& out) {
        std::size_t n = std::strlen(lit);
        if (s_.compare(i_, n, lit) != 0) { fail(std::string("invalid literal, expected ") + lit); return false; }
        for (std::size_t k = 0; k < n; ++k) get();
        out = v;
        return true;
    }

    bool parseNumber(JsonValue& out) {
        std::size_t start = i_;
        if (!eof() && (peek() == '-' || peek() == '+')) get();
        bool digits = false;
        // RFC 8259 forbids leading zeros ("01"); accepting them would let a
        // typo in a config file silently change its meaning.
        bool leadingZero = (!eof() && peek() == '0');
        while (!eof() && std::isdigit(static_cast<unsigned char>(peek()))) { get(); digits = true; }
        if (leadingZero && i_ - start > (s_[start] == '-' || s_[start] == '+' ? 2u : 1u)) {
            fail("number with a leading zero");
            return false;
        }
        if (!eof() && peek() == '.') { get(); while (!eof() && std::isdigit(static_cast<unsigned char>(peek()))) { get(); digits = true; } }
        if (digits && !eof() && (peek() == 'e' || peek() == 'E')) {
            get();
            if (!eof() && (peek() == '+' || peek() == '-')) get();
            bool ed = false;
            while (!eof() && std::isdigit(static_cast<unsigned char>(peek()))) { get(); ed = true; }
            if (!ed) { fail("malformed exponent"); return false; }
        }
        if (!digits) { fail("invalid value"); return false; }
        std::string tok = s_.substr(start, i_ - start);
        errno = 0;
        char* end = nullptr;
        double v = std::strtod(tok.c_str(), &end);
        if (end == tok.c_str() || errno == ERANGE || v != v) { fail("number out of range"); return false; }
        out = JsonValue::makeNumber(v);
        return true;
    }

    bool appendUtf8(std::string& out, unsigned cp) {
        if (cp <= 0x7F) { out.push_back(static_cast<char>(cp)); }
        else if (cp <= 0x7FF) {
            out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp <= 0xFFFF) {
            out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp <= 0x10FFFF) {
            out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else return false;
        return true;
    }

    bool parseHex4(unsigned& out) {
        if (i_ + 4 > s_.size()) { fail("truncated \\u escape"); return false; }
        unsigned v = 0;
        for (int k = 0; k < 4; ++k) {
            char c = get();
            v <<= 4;
            if (c >= '0' && c <= '9') v |= static_cast<unsigned>(c - '0');
            else if (c >= 'a' && c <= 'f') v |= static_cast<unsigned>(c - 'a' + 10);
            else if (c >= 'A' && c <= 'F') v |= static_cast<unsigned>(c - 'A' + 10);
            else { fail("bad hex digit in \\u escape"); return false; }
        }
        out = v;
        return true;
    }

    bool parseString(std::string& out) {
        if (!expect('"')) return false;
        out.clear();
        for (;;) {
            if (eof()) { fail("unterminated string"); return false; }
            char c = get();
            if (c == '"') return true;
            if (static_cast<unsigned char>(c) < 0x20) { fail("raw control character in string"); return false; }
            if (c != '\\') { out.push_back(c); continue; }
            if (eof()) { fail("unterminated escape"); return false; }
            char e = get();
            switch (e) {
                case '"':  out.push_back('"');  break;
                case '\\': out.push_back('\\'); break;
                case '/':  out.push_back('/');  break;
                case 'b':  out.push_back('\b'); break;
                case 'f':  out.push_back('\f'); break;
                case 'n':  out.push_back('\n'); break;
                case 'r':  out.push_back('\r'); break;
                case 't':  out.push_back('\t'); break;
                case 'u': {
                    unsigned cp = 0;
                    if (!parseHex4(cp)) return false;
                    if (cp >= 0xD800 && cp <= 0xDBFF) {          // high surrogate
                        if (i_ + 1 < s_.size() && s_[i_] == '\\' && s_[i_ + 1] == 'u') {
                            get(); get();
                            unsigned lo = 0;
                            if (!parseHex4(lo)) return false;
                            if (lo < 0xDC00 || lo > 0xDFFF) { fail("invalid low surrogate"); return false; }
                            cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                        } else { fail("lone high surrogate"); return false; }
                    } else if (cp >= 0xDC00 && cp <= 0xDFFF) {
                        fail("lone low surrogate"); return false;
                    }
                    if (!appendUtf8(out, cp)) { fail("code point out of range"); return false; }
                    break;
                }
                default: fail("unknown escape sequence"); return false;
            }
        }
    }

    bool parseArray(JsonValue& out, int depth) {
        if (!expect('[')) return false;
        out = JsonValue::makeArray();
        skipWs();
        if (!eof() && peek() == ']') { get(); return true; }
        for (;;) {
            JsonValue v;
            if (!parseValue(v, depth + 1)) return false;
            out.push(v);
            skipWs();
            if (eof()) { fail("unterminated array"); return false; }
            char c = get();
            if (c == ']') return true;
            if (c != ',') { fail("expected ',' or ']'"); return false; }
            skipWs();
            if (!eof() && peek() == ']') { fail("trailing comma in array"); return false; }
        }
    }

    bool parseObject(JsonValue& out, int depth) {
        if (!expect('{')) return false;
        out = JsonValue::makeObject();
        skipWs();
        if (!eof() && peek() == '}') { get(); return true; }
        for (;;) {
            skipWs();
            std::string key;
            if (!parseString(key)) return false;
            if (!expect(':')) return false;
            JsonValue v;
            if (!parseValue(v, depth + 1)) return false;
            out.set(key, v);                       // duplicate key: last wins
            skipWs();
            if (eof()) { fail("unterminated object"); return false; }
            char c = get();
            if (c == '}') return true;
            if (c != ',') { fail("expected ',' or '}'"); return false; }
            skipWs();
            if (!eof() && peek() == '}') { fail("trailing comma in object"); return false; }
        }
    }
};
}  // namespace

JsonValue JsonValue::makeNull() { return JsonValue(); }
JsonValue JsonValue::makeBool(bool v)   { JsonValue j; j.type_ = Type::Bool;   j.bool_ = v; return j; }
JsonValue JsonValue::makeNumber(double v) { JsonValue j; j.type_ = Type::Number; j.num_ = v; return j; }
JsonValue JsonValue::makeString(const std::string& v) { JsonValue j; j.type_ = Type::String; j.str_ = v; return j; }
JsonValue JsonValue::makeArray()  { JsonValue j; j.type_ = Type::Array;  return j; }
JsonValue JsonValue::makeObject() { JsonValue j; j.type_ = Type::Object; return j; }

bool   JsonValue::asBool(bool def) const { return type_ == Type::Bool ? bool_ : def; }
double JsonValue::asNumber(double def) const { return type_ == Type::Number ? num_ : def; }
const std::string& JsonValue::asString() const { return type_ == Type::String ? str_ : kEmptyString; }
const std::vector<JsonValue>& JsonValue::asArray() const { return type_ == Type::Array ? arr_ : kEmptyArray; }

bool JsonValue::has(const std::string& key) const {
    return type_ == Type::Object && obj_.find(key) != obj_.end();
}

const JsonValue* JsonValue::find(const std::string& key) const {
    if (type_ != Type::Object) return nullptr;
    std::map<std::string, JsonValue>::const_iterator it = obj_.find(key);
    return it == obj_.end() ? nullptr : &it->second;
}

void JsonValue::set(const std::string& key, const JsonValue& v) {
    if (type_ != Type::Object) { *this = makeObject(); }
    if (obj_.find(key) == obj_.end()) order_.push_back(key);
    obj_[key] = v;
}

void JsonValue::push(const JsonValue& v) {
    if (type_ != Type::Array) { *this = makeArray(); }
    arr_.push_back(v);
}

std::vector<std::string> JsonValue::keys() const { return order_; }

std::size_t JsonValue::size() const {
    if (type_ == Type::Array) return arr_.size();
    if (type_ == Type::Object) return obj_.size();
    return 0;
}

void JsonValue::escapeTo(std::string& out, const std::string& s) {
    out.push_back('"');
    for (std::size_t i = 0; i < s.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b";  break;
            case '\f': out += "\\f";  break;
            case '\n': out += "\\n";  break;
            case '\r': out += "\\r";  break;
            case '\t': out += "\\t";  break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out.push_back(s[i]);
                }
        }
    }
    out.push_back('"');
}

void JsonValue::dumpTo(std::string& out, int indent, int depth) const {
    const std::string pad(indent > 0 ? static_cast<std::size_t>(indent * (depth + 1)) : 0, ' ');
    const std::string padEnd(indent > 0 ? static_cast<std::size_t>(indent * depth) : 0, ' ');
    const char* nl = indent > 0 ? "\n" : "";
    switch (type_) {
        case Type::Null:   out += "null"; break;
        case Type::Bool:   out += bool_ ? "true" : "false"; break;
        case Type::Number: {
            char buf[40];
            if (num_ == static_cast<double>(static_cast<long long>(num_)) &&
                num_ < 1e15 && num_ > -1e15) {
                std::snprintf(buf, sizeof(buf), "%lld", static_cast<long long>(num_));
            } else {
                std::snprintf(buf, sizeof(buf), "%.10g", num_);
            }
            out += buf;
            break;
        }
        case Type::String: escapeTo(out, str_); break;
        case Type::Array: {
            if (arr_.empty()) { out += "[]"; break; }
            out += "["; out += nl;
            for (std::size_t i = 0; i < arr_.size(); ++i) {
                out += pad;
                arr_[i].dumpTo(out, indent, depth + 1);
                if (i + 1 < arr_.size()) out += ",";
                out += nl;
            }
            out += padEnd; out += "]";
            break;
        }
        case Type::Object: {
            if (order_.empty()) { out += "{}"; break; }
            out += "{"; out += nl;
            for (std::size_t i = 0; i < order_.size(); ++i) {
                std::map<std::string, JsonValue>::const_iterator it = obj_.find(order_[i]);
                if (it == obj_.end()) continue;
                out += pad;
                escapeTo(out, order_[i]);
                out += indent > 0 ? ": " : ":";
                it->second.dumpTo(out, indent, depth + 1);
                if (i + 1 < order_.size()) out += ",";
                out += nl;
            }
            out += padEnd; out += "}";
            break;
        }
    }
}

std::string JsonValue::dump(int indent) const {
    std::string out;
    dumpTo(out, indent, 0);
    return out;
}

bool JsonValue::parse(const std::string& text, JsonValue& out, std::string& err) {
    err.clear();
    if (text.empty()) { err = "empty document"; return false; }
    // Tolerate a UTF-8 BOM: editors on Windows add one and it is not our
    // user's fault that the config then fails to load.
    std::size_t start = 0;
    if (text.size() >= 3 && static_cast<unsigned char>(text[0]) == 0xEF &&
        static_cast<unsigned char>(text[1]) == 0xBB && static_cast<unsigned char>(text[2]) == 0xBF) {
        start = 3;
    }
    std::string body = start ? text.substr(start) : text;
    Parser p(body);
    return p.run(out, err);
}

bool JsonValue::parseFile(const std::string& path, JsonValue& out, std::string& err) {
    std::ifstream f(path.c_str(), std::ios::binary);
    if (!f.is_open()) { err = "cannot open " + path; return false; }
    std::ostringstream ss;
    ss << f.rdbuf();
    if (f.bad()) { err = "read error on " + path; return false; }
    return parse(ss.str(), out, err);
}

}  // namespace vsmf
