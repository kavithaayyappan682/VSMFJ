#include "support/ConfigManager.hpp"

#include <sstream>

#include "common/Utils.hpp"

namespace vsmf {

namespace {

// Pull a number, validating type and range. Anything wrong is a warning,
// never a hard failure - the vehicle still has to boot.
template <typename T>
void getNum(const JsonValue& doc, const char* key, T& dst, double lo, double hi,
            std::vector<std::string>& warn) {
    const JsonValue* v = doc.find(key);
    if (v == nullptr) return;
    if (!v->isNumber()) {
        warn.push_back(std::string(key) + ": not a number, keeping default");
        return;
    }
    double d = v->asNumber();
    if (d != d) {                                     // NaN
        warn.push_back(std::string(key) + ": NaN, keeping default");
        return;
    }
    if (d < lo || d > hi) {
        double c = util::clampValue(d, lo, hi);
        std::ostringstream os;
        os << key << ": " << d << " out of range [" << lo << ", " << hi << "], clamped to " << c;
        warn.push_back(os.str());
        d = c;
    }
    dst = static_cast<T>(d);
}

void getStr(const JsonValue& doc, const char* key, std::string& dst, std::size_t maxLen,
            std::vector<std::string>& warn) {
    const JsonValue* v = doc.find(key);
    if (v == nullptr) return;
    if (!v->isString()) {
        warn.push_back(std::string(key) + ": not a string, keeping default");
        return;
    }
    const std::string& s = v->asString();
    if (s.empty()) {
        warn.push_back(std::string(key) + ": empty, keeping default");
        return;
    }
    if (s.size() > maxLen) {
        warn.push_back(std::string(key) + ": too long, keeping default");
        return;
    }
    dst = s;
}

}  // namespace

std::string Config::toString() const {
    std::ostringstream os;
    os << "speed_limit=" << speedLimit
       << " temperature_limit=" << temperatureLimit
       << " battery_limit=" << batteryLimit
       << " rpm_limit=" << rpmLimit
       << " heartbeat_interval=" << heartbeatInterval << "s"
       << " thread_pool_size=" << threadPoolSize
       << " log_level=" << vsmf::toString(logLevel)
       << " socket=" << socketPath
       << " log_dir=" << logDir
       << " request_timeout=" << requestTimeoutMs << "ms"
       << " publish_interval=" << publishIntervalMs << "ms"
       << " metrics_interval=" << metricsIntervalMs << "ms"
       << " queue_capacity=" << queueCapacity;
    return os.str();
}

bool ConfigManager::load(const std::string& path, std::string& err) {
    err.clear();
    {
        std::lock_guard<std::mutex> lk(mu_);
        path_ = path;
        mtime_ = util::fileMTime(path);
    }
    JsonValue doc;
    std::string perr;
    if (!JsonValue::parseFile(path, doc, perr)) {
        err = "config not loaded (" + perr + "); running on built-in defaults";
        return false;
    }
    return applyJson(doc, err);
}

bool ConfigManager::applyJson(const JsonValue& doc, std::string& err) {
    err.clear();
    if (!doc.isObject()) {
        err = "config root is not a JSON object; running on built-in defaults";
        return false;
    }

    Config c;                       // start from defaults every time so a
    std::vector<std::string> warn;  // removed key reverts instead of sticking

    getNum(doc, "speed_limit",         c.speedLimit,        1.0,   1000.0, warn);
    getNum(doc, "temperature_limit",   c.temperatureLimit, -40.0,   300.0, warn);
    getNum(doc, "battery_limit",       c.batteryLimit,      0.0,    100.0, warn);
    getNum(doc, "rpm_limit",           c.rpmLimit,        100.0,  30000.0, warn);
    getNum(doc, "heartbeat_interval",  c.heartbeatInterval, 1.0,   3600.0, warn);
    getNum(doc, "missed_heartbeats",   c.missedHeartbeats,  1.0,    100.0, warn);
    getNum(doc, "request_timeout_ms",  c.requestTimeoutMs, 10.0,  60000.0, warn);
    getNum(doc, "publish_interval_ms", c.publishIntervalMs, 10.0,  60000.0, warn);
    getNum(doc, "metrics_interval_ms", c.metricsIntervalMs, 100.0, 600000.0, warn);
    getNum(doc, "max_log_bytes",       c.maxLogBytes,   4096.0, 1024.0 * 1024 * 1024, warn);

    {
        double tp = static_cast<double>(c.threadPoolSize);
        getNum(doc, "thread_pool_size", tp,
               static_cast<double>(limits::kMinThreads),
               static_cast<double>(limits::kMaxThreads), warn);
        c.threadPoolSize = static_cast<std::size_t>(tp);
        double qc = static_cast<double>(c.queueCapacity);
        getNum(doc, "queue_capacity", qc, 16.0, static_cast<double>(limits::kMaxQueueDepth), warn);
        c.queueCapacity = static_cast<std::size_t>(qc);
    }

    getStr(doc, "socket_path", c.socketPath, 100, warn);   // sun_path is 108
    getStr(doc, "log_dir",     c.logDir,     256, warn);

    const JsonValue* lv = doc.find("log_level");
    if (lv != nullptr) {
        if (!lv->isString() || !parseLogLevel(lv->asString(), c.logLevel)) {
            warn.push_back("log_level: unrecognised, keeping INFO");
        }
    }

    // Cross-field sanity: a battery alarm above the temperature-style
    // percentage range, or a heartbeat slower than the metrics window,
    // is legal but worth surfacing to the integrator.
    if (c.heartbeatInterval * 1000 > c.metricsIntervalMs * 10) {
        warn.push_back("heartbeat_interval is very large relative to metrics_interval_ms");
    }

    std::lock_guard<std::mutex> lk(mu_);
    cfg_ = c;
    warnings_ = warn;
    return true;
}

bool ConfigManager::reloadIfChanged(std::string& err) {
    std::string p;
    std::int64_t known;
    {
        std::lock_guard<std::mutex> lk(mu_);
        p = path_;
        known = mtime_;
    }
    if (p.empty()) { err = "no config path set"; return false; }
    std::int64_t now = util::fileMTime(p);
    if (now < 0) { err = "config file disappeared: " + p; return false; }
    if (now == known) return false;                 // untouched

    JsonValue doc;
    std::string perr;
    if (!JsonValue::parseFile(p, doc, perr)) {
        // Keep serving the last good configuration - a half-saved file
        // must not knock the middleware over.
        std::lock_guard<std::mutex> lk(mu_);
        mtime_ = now;
        err = "reload rejected, keeping previous config (" + perr + ")";
        return false;
    }
    if (!applyJson(doc, err)) return false;
    std::lock_guard<std::mutex> lk(mu_);
    mtime_ = now;
    return true;
}

Config ConfigManager::get() const {
    std::lock_guard<std::mutex> lk(mu_);
    return cfg_;
}

std::string ConfigManager::path() const {
    std::lock_guard<std::mutex> lk(mu_);
    return path_;
}

std::vector<std::string> ConfigManager::warnings() const {
    std::lock_guard<std::mutex> lk(mu_);
    return warnings_;
}

}  // namespace vsmf
