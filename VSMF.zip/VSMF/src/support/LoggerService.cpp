#include "support/LoggerService.hpp"

#include <chrono>
#include <cstdio>
#include <fstream>
#include <iostream>

#include "common/Utils.hpp"

namespace vsmf {

namespace {
const char* kFileNames[4] = {"middleware.log", "performance.log", "diagnostics.log", "health.log"};
}

LoggerService::LoggerService()
    : state_(static_cast<std::uint8_t>(ServiceState::CREATED)),
      minLevel_(static_cast<std::uint8_t>(LogLevel::INFO)),
      echo_(false),
      running_(false),
      dropped_(0),
      written_(0) {
    for (std::size_t i = 0; i < kChannels; ++i) size_[i] = 0;
}

LoggerService::~LoggerService() { stop(); }

std::string LoggerService::fileFor(LogChannel ch) const {
    std::size_t i = static_cast<std::size_t>(ch);
    if (i >= kChannels) i = 0;
    return util::joinPath(dir_, kFileNames[i]);
}

bool LoggerService::configure(const std::string& logDir, LogLevel minLevel, long maxBytes,
                              std::size_t queueCapacity, std::string& err) {
    if (running_.load(std::memory_order_acquire)) { err = "cannot reconfigure a running logger"; return false; }
    if (!util::makeDirs(logDir, err)) return false;
    dir_ = logDir;
    maxBytes_ = maxBytes > 4096 ? maxBytes : 4096;
    capacity_ = queueCapacity ? queueCapacity : 1024;
    minLevel_.store(static_cast<std::uint8_t>(minLevel), std::memory_order_relaxed);
    for (std::size_t i = 0; i < kChannels; ++i) path_[i] = util::joinPath(dir_, kFileNames[i]);
    return true;
}

bool LoggerService::openStream(std::size_t idx, std::string& err) {
    if (idx >= kChannels) { err = "bad channel"; return false; }
    if (path_[idx].empty()) path_[idx] = util::joinPath(dir_, kFileNames[idx]);
    // A stream that failed or was closed earlier keeps its error bits, and
    // open() would refuse to do anything until they are cleared.
    out_[idx].clear();
    out_[idx].open(path_[idx].c_str(), std::ios::out | std::ios::app);
    if (!out_[idx].is_open()) { err = "cannot open " + path_[idx]; return false; }
    long sz = util::fileSize(path_[idx]);
    size_[idx] = sz > 0 ? sz : 0;
    return true;
}

bool LoggerService::start() {
    ServiceState st = state();
    if (st == ServiceState::RUNNING || st == ServiceState::STARTING) return true;   // idempotent
    state_.store(static_cast<std::uint8_t>(ServiceState::STARTING), std::memory_order_release);

    {
        std::lock_guard<std::mutex> lk(fileMu_);
        std::string err;
        for (std::size_t i = 0; i < kChannels; ++i) {
            if (out_[i].is_open()) continue;
            if (!openStream(i, err)) {
                // Losing the log files is bad but not fatal: fall back to
                // stderr rather than refusing to run the vehicle.
                std::cerr << "[LoggerService] " << err << " - falling back to stderr\n";
                echo_.store(true, std::memory_order_relaxed);
            }
        }
    }

    running_.store(true, std::memory_order_release);
    th_ = std::thread(&LoggerService::worker, this);
    state_.store(static_cast<std::uint8_t>(ServiceState::RUNNING), std::memory_order_release);
    log(LogLevel::INFO, name_, "logger started, level=" + std::string(vsmf::toString(minLevel())));
    return true;
}

void LoggerService::stop() {
    if (!running_.exchange(false, std::memory_order_acq_rel)) return;
    state_.store(static_cast<std::uint8_t>(ServiceState::STOPPING), std::memory_order_release);
    cv_.notify_all();
    if (th_.joinable()) th_.join();

    // Drain anything still queued so the tail of a crash is not lost.
    std::deque<Entry> rest;
    {
        std::lock_guard<std::mutex> lk(mu_);
        rest.swap(queue_);
    }
    for (std::deque<Entry>::iterator it = rest.begin(); it != rest.end(); ++it) writeEntry(*it);

    {
        std::lock_guard<std::mutex> lk(fileMu_);
        for (std::size_t i = 0; i < kChannels; ++i) {
            if (out_[i].is_open()) { out_[i].flush(); out_[i].close(); }
        }
    }
    state_.store(static_cast<std::uint8_t>(ServiceState::STOPPED), std::memory_order_release);
}

void LoggerService::log(LogLevel lvl, const std::string& source, const std::string& msg) {
    logTo(LogChannel::Middleware, lvl, source, msg);
}

void LoggerService::logTo(LogChannel ch, LogLevel lvl, const std::string& source, const std::string& msg) {
    if (static_cast<std::uint8_t>(lvl) < minLevel_.load(std::memory_order_relaxed)) return;

    Entry e;
    e.ch = ch;
    e.lvl = lvl;
    e.ts = util::wallNs();
    e.source = source;
    e.msg = util::sanitize(msg, 4096);

    if (!running_.load(std::memory_order_acquire)) {
        // Before start() / after stop(): write straight through so early
        // boot errors and shutdown messages are never silently lost.
        writeEntry(e);
        return;
    }
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (queue_.size() >= capacity_) {
            // Bounded queue: drop the OLDEST so the freshest picture of a
            // fault survives, and count the loss.
            queue_.pop_front();
            dropped_.fetch_add(1, std::memory_order_relaxed);
        }
        queue_.push_back(e);
    }
    cv_.notify_one();
}

void LoggerService::worker() {
    for (;;) {
        Entry e;
        {
            std::unique_lock<std::mutex> lk(mu_);
            cv_.wait(lk, [this] { return !queue_.empty() || !running_.load(std::memory_order_acquire); });
            if (queue_.empty()) {
                inFlight_ = false;
                drained_.notify_all();
                if (!running_.load(std::memory_order_acquire)) return;
                continue;
            }
            e = queue_.front();
            queue_.pop_front();
            inFlight_ = true;      // popped but not on disk yet
        }
        writeEntry(e);
        {
            std::lock_guard<std::mutex> lk(mu_);
            inFlight_ = false;
            if (queue_.empty()) drained_.notify_all();
        }
    }
}

void LoggerService::rotateIfNeeded(std::size_t idx) {
    // caller holds fileMu_
    if (size_[idx] < maxBytes_) return;
    if (out_[idx].is_open()) { out_[idx].flush(); out_[idx].close(); }
    std::string prev = path_[idx] + ".1";
    ::remove(prev.c_str());
    if (::rename(path_[idx].c_str(), prev.c_str()) != 0) {
        // Rotation failed (read-only fs, permissions). Keep appending
        // rather than losing the stream entirely.
        size_[idx] = 0;
    }
    std::string err;
    if (!openStream(idx, err)) echo_.store(true, std::memory_order_relaxed);
    size_[idx] = 0;
}

void LoggerService::writeEntry(const Entry& e) {
    std::size_t idx = static_cast<std::size_t>(e.ch);
    if (idx >= kChannels) idx = 0;

    std::string line;
    line.reserve(64 + e.source.size() + e.msg.size());
    line += util::formatWallTime(e.ts);
    line += " [";
    line += vsmf::toString(e.lvl);
    line += "] [";
    line += e.source;
    line += "] ";
    line += e.msg;

    std::lock_guard<std::mutex> lk(fileMu_);
    // Before start() and after stop() the streams are closed. Reopen on
    // demand so early boot errors and shutdown messages land in the file
    // instead of only on stderr, which is often redirected to /dev/null.
    if (!out_[idx].is_open()) {
        std::string openErr;
        openStream(idx, openErr);
    }
    if (out_[idx].is_open()) {
        out_[idx] << line << '\n';
        // Faults are flushed immediately, and so is anything written
        // outside the running window: there is no worker thread then to
        // drain the stream buffer, so an unflushed line would sit in
        // memory until the process exited (or died).
        if (e.lvl >= LogLevel::WARN || !running_.load(std::memory_order_acquire))
            out_[idx].flush();
        size_[idx] += static_cast<long>(line.size() + 1);
        written_.fetch_add(1, std::memory_order_relaxed);
        rotateIfNeeded(idx);
    }
    if (echo_.load(std::memory_order_relaxed) || (!out_[idx].is_open())) {
        std::cerr << line << std::endl;
    }
}

void LoggerService::flush() {
    if (running_.load(std::memory_order_acquire)) {
        std::unique_lock<std::mutex> lk(mu_);
        // Bounded wait: a wedged filesystem must not hang shutdown.
        // The queue being empty is not enough: the worker may have taken
        // an entry and not written it yet, so wait for that too. Without
        // this, a caller that logs and immediately tails the file can miss
        // its own line.
        drained_.wait_for(lk, std::chrono::milliseconds(2000),
                          [this] { return queue_.empty() && !inFlight_; });
    }
    std::lock_guard<std::mutex> lk(fileMu_);
    for (std::size_t i = 0; i < kChannels; ++i)
        if (out_[i].is_open()) out_[i].flush();
}

std::vector<std::string> LoggerService::tail(LogChannel ch, std::size_t n) const {
    std::vector<std::string> out;
    if (n == 0) return out;
    std::size_t idx = static_cast<std::size_t>(ch);
    if (idx >= kChannels) idx = 0;
    std::string p = path_[idx].empty() ? util::joinPath(dir_, kFileNames[idx]) : path_[idx];

    std::ifstream f(p.c_str());
    if (!f.is_open()) return out;
    std::deque<std::string> ring;
    std::string line;
    while (std::getline(f, line)) {
        ring.push_back(line);
        if (ring.size() > n) ring.pop_front();
    }
    out.assign(ring.begin(), ring.end());
    return out;
}

}  // namespace vsmf
