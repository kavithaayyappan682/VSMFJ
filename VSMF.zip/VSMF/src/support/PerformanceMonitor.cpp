#include "support/PerformanceMonitor.hpp"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <sstream>

#include "common/Utils.hpp"
#include "support/LoggerService.hpp"

namespace vsmf {

namespace {
const std::uint64_t kNoMin = static_cast<std::uint64_t>(-1);
}

std::string PerfSnapshot::toString() const {
    char buf[512];
    std::snprintf(buf, sizeof(buf),
                  "throughput=%.1f msg/s latency(avg/min/max/p95)=%.1f/%.1f/%.1f/%.1f us "
                  "cpu=%.1f%% rss=%lluKB queue=%zu(peak %zu) published=%llu routed=%llu "
                  "processed=%llu dropped=%llu req=%llu resp=%llu timeouts=%llu uptime=%.1fs",
                  throughputMsgPerSec, avgLatencyUs, minLatencyUs, maxLatencyUs, p95LatencyUs,
                  cpuPercent, static_cast<unsigned long long>(rssKb), queueDepth, peakQueueDepth,
                  static_cast<unsigned long long>(published), static_cast<unsigned long long>(routed),
                  static_cast<unsigned long long>(processed), static_cast<unsigned long long>(dropped),
                  static_cast<unsigned long long>(requests), static_cast<unsigned long long>(responses),
                  static_cast<unsigned long long>(timeouts), uptimeSec);
    return std::string(buf);
}

PerformanceMonitor::PerformanceMonitor()
    : running_(false), published_(0), routed_(0), processed_(0), dropped_(0),
      requests_(0), responses_(0), timeouts_(0),
      latSumNs_(0), latMinNs_(kNoMin), latMaxNs_(0), latCount_(0) {
    reservoir_.reserve(kReservoir);
    startNs_ = util::steadyNs();
}

PerformanceMonitor::~PerformanceMonitor() { stop(); }

void PerformanceMonitor::setQueueDepthProvider(DepthFn d, PeakFn p) {
    std::lock_guard<std::mutex> lk(fnMu_);
    depthFn_ = d;
    peakFn_ = p;
}

void PerformanceMonitor::setReportSink(ReportFn r) {
    std::lock_guard<std::mutex> lk(fnMu_);
    report_ = r;
}

void PerformanceMonitor::onDelivered(std::uint64_t latencyNs) {
    processed_.fetch_add(1, std::memory_order_relaxed);

    // A clock that jumped, or a message from a peer whose monotonic clock
    // is not ours, can yield a nonsense latency. Discard instead of
    // poisoning the average.
    if (latencyNs > 60ULL * 1000000000ULL) return;

    latSumNs_.fetch_add(latencyNs, std::memory_order_relaxed);
    latCount_.fetch_add(1, std::memory_order_relaxed);

    std::uint64_t prev = latMaxNs_.load(std::memory_order_relaxed);
    while (latencyNs > prev && !latMaxNs_.compare_exchange_weak(prev, latencyNs, std::memory_order_relaxed)) {}
    prev = latMinNs_.load(std::memory_order_relaxed);
    while (latencyNs < prev && !latMinNs_.compare_exchange_weak(prev, latencyNs, std::memory_order_relaxed)) {}

    std::lock_guard<std::mutex> lk(resMu_);
    if (reservoir_.size() < kReservoir) reservoir_.push_back(latencyNs);
    else { reservoir_[resPos_] = latencyNs; resPos_ = (resPos_ + 1) % kReservoir; }
}

bool PerformanceMonitor::start(int intervalMs) {
    if (running_.exchange(true, std::memory_order_acq_rel)) return false;
    if (intervalMs < 100) intervalMs = 100;
    startNs_ = util::steadyNs();
    lastSampleNs_ = startNs_;
    util::readProcCpuJiffies(lastJiffies_);
    th_ = std::thread(&PerformanceMonitor::sampler, this, intervalMs);
    return true;
}

void PerformanceMonitor::stop() {
    if (!running_.exchange(false, std::memory_order_acq_rel)) return;
    if (th_.joinable()) th_.join();
}

void PerformanceMonitor::sampler(int intervalMs) {
    const long ticks = util::clockTicksPerSec();
    while (running_.load(std::memory_order_acquire)) {
        // Sleep in slices so stop() is responsive even with a long interval.
        int remaining = intervalMs;
        while (remaining > 0 && running_.load(std::memory_order_acquire)) {
            int slice = remaining > 100 ? 100 : remaining;
            std::this_thread::sleep_for(std::chrono::milliseconds(slice));
            remaining -= slice;
        }
        if (!running_.load(std::memory_order_acquire)) break;

        std::uint64_t nowNs = util::steadyNs();
        std::uint64_t processed = processed_.load(std::memory_order_relaxed);
        std::uint64_t jiffies = 0;
        std::uint64_t rss = 0;
        bool haveCpu = util::readProcCpuJiffies(jiffies);
        bool haveRss = util::readProcRssKb(rss);

        {
            std::lock_guard<std::mutex> lk(sampMu_);
            double dt = static_cast<double>(nowNs - lastSampleNs_) / 1e9;
            if (dt > 1e-6) {
                // Counters are monotonic; guard anyway so a reset() during
                // a sample cannot produce a negative rate.
                std::uint64_t delta = processed >= lastProcessed_ ? processed - lastProcessed_ : 0;
                throughput_ = static_cast<double>(delta) / dt;
                if (haveCpu && jiffies >= lastJiffies_ && ticks > 0) {
                    double cpuSec = static_cast<double>(jiffies - lastJiffies_) / static_cast<double>(ticks);
                    cpuPercent_ = 100.0 * cpuSec / dt;
                    if (cpuPercent_ < 0.0) cpuPercent_ = 0.0;
                }
            }
            if (haveRss) rssKb_ = rss;
            lastSampleNs_ = nowNs;
            lastProcessed_ = processed;
            if (haveCpu) lastJiffies_ = jiffies;
        }

        ReportFn r;
        {
            std::lock_guard<std::mutex> lk(fnMu_);
            r = report_;
        }
        if (r) {
            try {
                r(snapshot());
            } catch (...) {
                if (logger_ != nullptr)
                    logger_->log(LogLevel::WARN, "PerformanceMonitor", "report sink threw");
            }
        }
    }
}

PerfSnapshot PerformanceMonitor::snapshot() const {
    PerfSnapshot s;
    s.published  = published_.load(std::memory_order_relaxed);
    s.routed     = routed_.load(std::memory_order_relaxed);
    s.processed  = processed_.load(std::memory_order_relaxed);
    s.dropped    = dropped_.load(std::memory_order_relaxed);
    s.requests   = requests_.load(std::memory_order_relaxed);
    s.responses  = responses_.load(std::memory_order_relaxed);
    s.timeouts   = timeouts_.load(std::memory_order_relaxed);

    std::uint64_t cnt = latCount_.load(std::memory_order_relaxed);
    std::uint64_t sum = latSumNs_.load(std::memory_order_relaxed);
    std::uint64_t mn  = latMinNs_.load(std::memory_order_relaxed);
    std::uint64_t mx  = latMaxNs_.load(std::memory_order_relaxed);
    s.avgLatencyUs = cnt ? (static_cast<double>(sum) / static_cast<double>(cnt)) / 1000.0 : 0.0;
    s.minLatencyUs = (cnt && mn != kNoMin) ? static_cast<double>(mn) / 1000.0 : 0.0;
    s.maxLatencyUs = cnt ? static_cast<double>(mx) / 1000.0 : 0.0;

    {
        std::lock_guard<std::mutex> lk(resMu_);
        if (!reservoir_.empty()) {
            std::vector<std::uint64_t> tmp(reservoir_);
            std::sort(tmp.begin(), tmp.end());
            std::size_t idx = static_cast<std::size_t>(0.95 * static_cast<double>(tmp.size()));
            if (idx >= tmp.size()) idx = tmp.size() - 1;
            s.p95LatencyUs = static_cast<double>(tmp[idx]) / 1000.0;
        }
    }
    {
        std::lock_guard<std::mutex> lk(sampMu_);
        s.throughputMsgPerSec = throughput_;
        s.cpuPercent = cpuPercent_;
        s.rssKb = rssKb_;
    }
    {
        std::lock_guard<std::mutex> lk(fnMu_);
        if (depthFn_) { try { s.queueDepth = depthFn_(); } catch (...) {} }
        if (peakFn_)  { try { s.peakQueueDepth = peakFn_(); } catch (...) {} }
    }
    s.uptimeSec = static_cast<double>(util::steadyNs() - startNs_) / 1e9;

    // The sampler thread has not produced a window yet (or the monitor is
    // running without one). Fall back to since-start averages and a live
    // /proc read so an early 'metrics' command is not all zeroes.
    if (s.throughputMsgPerSec <= 0.0 && s.uptimeSec > 0.05)
        s.throughputMsgPerSec = static_cast<double>(s.processed) / s.uptimeSec;
    if (s.rssKb == 0) {
        std::uint64_t kb = 0;
        if (util::readProcRssKb(kb)) s.rssKb = kb;
    }
    return s;
}

void PerformanceMonitor::reset() {
    published_.store(0, std::memory_order_relaxed);
    routed_.store(0, std::memory_order_relaxed);
    processed_.store(0, std::memory_order_relaxed);
    dropped_.store(0, std::memory_order_relaxed);
    requests_.store(0, std::memory_order_relaxed);
    responses_.store(0, std::memory_order_relaxed);
    timeouts_.store(0, std::memory_order_relaxed);
    latSumNs_.store(0, std::memory_order_relaxed);
    latCount_.store(0, std::memory_order_relaxed);
    latMinNs_.store(kNoMin, std::memory_order_relaxed);
    latMaxNs_.store(0, std::memory_order_relaxed);
    {
        std::lock_guard<std::mutex> lk(resMu_);
        reservoir_.clear();
        resPos_ = 0;
    }
    {
        std::lock_guard<std::mutex> lk(sampMu_);
        throughput_ = 0.0;
        lastProcessed_ = 0;
        lastSampleNs_ = util::steadyNs();
    }
}

}  // namespace vsmf
