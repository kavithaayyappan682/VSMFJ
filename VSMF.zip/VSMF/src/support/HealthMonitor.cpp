#include "support/HealthMonitor.hpp"

#include <chrono>
#include <sstream>

#include "common/Utils.hpp"
#include "support/LoggerService.hpp"

namespace vsmf {

const char* HealthMonitor::kEndpointName = "HealthMonitor";

std::string HealthReport::toString() const {
    std::ostringstream os;
    os << "overall=" << vsmf::toString(overall)
       << " healthy=" << healthy << " degraded=" << degraded << " unhealthy=" << unhealthy
       << " rounds=" << rounds;
    for (std::size_t i = 0; i < perService.size(); ++i)
        os << "\n  " << perService[i].first << ": " << vsmf::toString(perService[i].second);
    return os.str();
}

HealthMonitor::HealthMonitor(CommunicationManager& cm, ServiceRegistry& reg, ConfigManager& cfg)
    : cm_(cm), reg_(reg), cfg_(cfg), running_(false) {}

HealthMonitor::~HealthMonitor() { stop(); }

bool HealthMonitor::start(std::string& err) {
    if (running_.load(std::memory_order_acquire)) return true;
    ep_ = cm_.createEndpoint(kEndpointName, err);
    if (!ep_) return false;
    running_.store(true, std::memory_order_release);
    try {
        th_ = std::thread(&HealthMonitor::loop, this);
    } catch (const std::system_error& e) {
        running_.store(false, std::memory_order_release);
        err = std::string("cannot start heartbeat thread: ") + e.what();
        cm_.destroyEndpoint(kEndpointName);
        ep_.reset();
        return false;
    }
    return true;
}

void HealthMonitor::stop() {
    if (!running_.exchange(false, std::memory_order_acq_rel)) return;
    if (th_.joinable()) th_.join();
    if (ep_) {
        cm_.destroyEndpoint(kEndpointName);
        ep_.reset();
    }
}

void HealthMonitor::loop() {
    while (running_.load(std::memory_order_acquire)) {
        Config c = cfg_.get();
        int intervalMs = c.heartbeatInterval * 1000;
        if (intervalMs < 100) intervalMs = 100;

        checkOnce();

        int remaining = intervalMs;
        while (remaining > 0 && running_.load(std::memory_order_acquire)) {
            int slice = remaining > 100 ? 100 : remaining;
            std::this_thread::sleep_for(std::chrono::milliseconds(slice));
            remaining -= slice;
        }
    }
}

void HealthMonitor::checkOnce() {
    if (!ep_ || !ep_->isOpen()) return;
    Config c = cfg_.get();
    int timeoutMs = c.heartbeatInterval * 1000 / 2;
    if (timeoutMs < 100) timeoutMs = 100;
    if (timeoutMs > 5000) timeoutMs = 5000;
    const std::uint32_t threshold = static_cast<std::uint32_t>(c.missedHeartbeats < 1 ? 1 : c.missedHeartbeats);

    std::vector<ServiceInfo> all = reg_.list();
    HealthReport rep;

    for (std::size_t i = 0; i < all.size(); ++i) {
        const ServiceInfo& si = all[i];
        if (si.name == kEndpointName) continue;

        // Only services that claim to be up are expected to answer.
        if (si.state != ServiceState::RUNNING && si.state != ServiceState::PAUSED) {
            rep.perService.push_back(std::make_pair(si.name, HealthState::UNKNOWN));
            reg_.setHealth(si.name, HealthState::UNKNOWN);
            continue;
        }

        std::string err;
        HealthState hs;
        if (ep_->ping(si.endpoint, timeoutMs, err)) {
            reg_.touchHeartbeat(si.name, util::steadyNs());
            hs = HealthState::HEALTHY;
            ++rep.healthy;
        } else {
            std::uint32_t missed = si.missedHeartbeats + 1;
            reg_.setMissedHeartbeats(si.name, missed);
            if (missed >= threshold) {
                hs = HealthState::UNHEALTHY;
                ++rep.unhealthy;
            } else {
                hs = HealthState::DEGRADED;
                ++rep.degraded;
            }
            if (cm_.logger() != nullptr) {
                std::ostringstream os;
                os << si.name << " missed heartbeat " << missed << "/" << threshold << " (" << err << ")";
                cm_.logger()->logTo(LogChannel::Health,
                                    hs == HealthState::UNHEALTHY ? LogLevel::ERROR : LogLevel::WARN,
                                    kEndpointName, os.str());
            }
        }
        reg_.setHealth(si.name, hs);
        rep.perService.push_back(std::make_pair(si.name, hs));
    }

    rep.overall = rep.unhealthy > 0 ? HealthState::UNHEALTHY
                : rep.degraded > 0  ? HealthState::DEGRADED
                : rep.healthy > 0   ? HealthState::HEALTHY
                                    : HealthState::UNKNOWN;
    {
        std::lock_guard<std::mutex> lk(mu_);
        rep.rounds = report_.rounds + 1;
        report_ = rep;
    }

    std::ostringstream js;
    js << "{\"state\":\"" << vsmf::toString(rep.overall) << "\",\"healthy\":" << rep.healthy
       << ",\"degraded\":" << rep.degraded << ",\"unhealthy\":" << rep.unhealthy << "}";
    std::string err;
    ep_->publish(topics::kHealth, js.str(), Priority::HIGH, err);

    if (cm_.logger() != nullptr)
        cm_.logger()->logTo(LogChannel::Health, LogLevel::INFO, kEndpointName,
                            "heartbeat round: " + std::string(vsmf::toString(rep.overall)) +
                            " healthy=" + std::to_string(rep.healthy) +
                            " degraded=" + std::to_string(rep.degraded) +
                            " unhealthy=" + std::to_string(rep.unhealthy));
}

HealthReport HealthMonitor::report() const {
    std::lock_guard<std::mutex> lk(mu_);
    return report_;
}

HealthState HealthMonitor::overall() const {
    std::lock_guard<std::mutex> lk(mu_);
    return report_.overall;
}

}  // namespace vsmf
