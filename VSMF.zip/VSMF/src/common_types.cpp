#include "common/Types.hpp"
#include <algorithm>
#include <cctype>

namespace vsmf {

const char* toString(LogLevel l) noexcept {
    switch (l) {
        case LogLevel::TRACE: return "TRACE";
        case LogLevel::DEBUG: return "DEBUG";
        case LogLevel::INFO:  return "INFO";
        case LogLevel::WARN:  return "WARN";
        case LogLevel::ERROR: return "ERROR";
        case LogLevel::FATAL: return "FATAL";
    }
    return "INFO";  // unreachable for valid enum; defensive default
}

bool parseLogLevel(const std::string& s, LogLevel& out) noexcept {
    std::string u;
    u.reserve(s.size());
    for (char c : s) u.push_back(static_cast<char>(std::toupper(static_cast<unsigned char>(c))));
    if (u == "TRACE") { out = LogLevel::TRACE; return true; }
    if (u == "DEBUG") { out = LogLevel::DEBUG; return true; }
    if (u == "INFO")  { out = LogLevel::INFO;  return true; }
    if (u == "WARN" || u == "WARNING") { out = LogLevel::WARN; return true; }
    if (u == "ERROR") { out = LogLevel::ERROR; return true; }
    if (u == "FATAL") { out = LogLevel::FATAL; return true; }
    return false;
}

const char* toString(MsgType t) noexcept {
    switch (t) {
        case MsgType::HELLO:    return "HELLO";
        case MsgType::PUBLISH:  return "PUBLISH";
        case MsgType::REQUEST:  return "REQUEST";
        case MsgType::RESPONSE: return "RESPONSE";
        case MsgType::PING:     return "PING";
        case MsgType::PONG:     return "PONG";
        case MsgType::ERROR:    return "ERROR";
        case MsgType::BYE:      return "BYE";
    }
    return "UNKNOWN";
}

bool isValidMsgType(std::uint8_t raw) noexcept {
    return raw <= static_cast<std::uint8_t>(MsgType::BYE);
}

const char* toString(Priority p) noexcept {
    switch (p) {
        case Priority::LOW:      return "LOW";
        case Priority::NORMAL:   return "NORMAL";
        case Priority::HIGH:     return "HIGH";
        case Priority::CRITICAL: return "CRITICAL";
    }
    return "NORMAL";
}

bool isValidPriority(std::uint8_t raw) noexcept {
    return raw <= static_cast<std::uint8_t>(Priority::CRITICAL);
}

const char* toString(ServiceState s) noexcept {
    switch (s) {
        case ServiceState::CREATED:  return "CREATED";
        case ServiceState::STARTING: return "STARTING";
        case ServiceState::RUNNING:  return "RUNNING";
        case ServiceState::PAUSED:   return "PAUSED";
        case ServiceState::STOPPING: return "STOPPING";
        case ServiceState::STOPPED:  return "STOPPED";
        case ServiceState::FAILED:   return "FAILED";
    }
    return "UNKNOWN";
}

const char* toString(HealthState h) noexcept {
    switch (h) {
        case HealthState::UNKNOWN:   return "UNKNOWN";
        case HealthState::HEALTHY:   return "HEALTHY";
        case HealthState::DEGRADED:  return "DEGRADED";
        case HealthState::UNHEALTHY: return "UNHEALTHY";
    }
    return "UNKNOWN";
}

}  // namespace vsmf
