// =====================================================================
//  VSMF - Vehicle Service Management Framework
//  src/main.cpp
//
//  Terminal 1:  ./vsmf                 (middleware + live dashboard)
//  Terminal 2:  ./vsmf --console       (interactive command console)
//
//  Start-up order is deliberate: configuration, then logging, then the
//  execution and transport layers, then consumers, then producers, then
//  monitoring. Shutdown runs exactly backwards.
// =====================================================================
#include <atomic>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include <signal.h>
#include <unistd.h>

#include "common/Utils.hpp"
#include "core/CommunicationManager.hpp"
#include "core/DiscoveryManager.hpp"
#include "core/ServiceRegistry.hpp"
#include "data/DataGenerator.hpp"
#include "services/BatteryService.hpp"
#include "services/ControlService.hpp"
#include "services/DashboardService.hpp"
#include "services/DiagnosticService.hpp"
#include "services/EngineSensorService.hpp"
#include "services/GPSService.hpp"
#include "services/SpeedSensorService.hpp"
#include "services/VehicleControlService.hpp"
#include "support/ConfigManager.hpp"
#include "support/HealthMonitor.hpp"
#include "support/LifecycleManager.hpp"
#include "support/LoggerService.hpp"
#include "support/PerformanceMonitor.hpp"
#include "support/ThreadPool.hpp"

using namespace vsmf;

namespace {

const char* kVersion = "VSMF 1.0.0";

// Signal-handler state. Only sig_atomic_t may be touched from a handler.
volatile sig_atomic_t g_signal = 0;

void onSignal(int sig) { g_signal = sig; }

void installSignalHandlers() {
    struct sigaction sa;
    std::memset(&sa, 0, sizeof(sa));
    sa.sa_handler = onSignal;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;                 // no SA_RESTART: let poll() return EINTR
    ::sigaction(SIGINT, &sa, nullptr);
    ::sigaction(SIGTERM, &sa, nullptr);
    ::sigaction(SIGHUP, &sa, nullptr);
    util::ignoreSigPipe();
}

struct Options {
    std::string configPath = "config/vsmf_config.json";
    std::string socketOverride;
    std::string logDirOverride;
    bool        console = false;
    bool        noDashboard = false;
    int         durationSec = 0;      // 0 = run until signalled
    bool        help = false;
    bool        version = false;
};

bool parseArgs(int argc, char** argv, Options& o, std::string& err) {
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        bool needsValue = (a == "--config" || a == "-c" || a == "--socket" ||
                           a == "--duration" || a == "--log-dir");
        if (needsValue && i + 1 >= argc) { err = a + " requires a value"; return false; }

        if (a == "--console" || a == "-i") o.console = true;
        else if (a == "--no-dashboard")    o.noDashboard = true;
        else if (a == "--help" || a == "-h") o.help = true;
        else if (a == "--version" || a == "-v") o.version = true;
        else if (a == "--config" || a == "-c") o.configPath = argv[++i];
        else if (a == "--socket")  o.socketOverride = argv[++i];
        else if (a == "--log-dir") o.logDirOverride = argv[++i];
        else if (a == "--duration") {
            long long v = 0;
            if (!util::parseInt(argv[++i], v) || v < 0 || v > 86400) {
                err = "--duration needs 0..86400 seconds";
                return false;
            }
            o.durationSec = static_cast<int>(v);
        } else {
            err = "unknown option: " + a;
            return false;
        }
    }
    return true;
}

void usage() {
    std::cout <<
        kVersion << " - Service-Oriented Middleware Framework for Automotive Systems\n\n"
        "usage: vsmf [options]\n"
        "  -c, --config <file>   configuration file (default config/vsmf_config.json)\n"
        "      --socket <path>   override the Unix domain socket path\n"
        "      --log-dir <dir>   override the log directory\n"
        "  -i, --console         attach the interactive console to a running instance\n"
        "      --no-dashboard    run headless (useful under systemd)\n"
        "      --duration <sec>  run for N seconds then exit cleanly (demo/CI)\n"
        "  -h, --help            this text\n"
        "  -v, --version         version\n\n"
        "Terminal 1:  ./vsmf\n"
        "Terminal 2:  ./vsmf --console\n";
}

// ---------------------------------------------------------------------
// Terminal 2: interactive console client.
// ---------------------------------------------------------------------
int runConsole(const std::string& socketPath) {
    util::ignoreSigPipe();
    installSignalHandlers();

    std::ostringstream nameOs;
    nameOs << "console-" << static_cast<long>(::getpid());
    const std::string name = nameOs.str();

    IPCClient client;
    std::string err;
    if (!client.connect(socketPath, name, 1500, err)) {
        std::cerr << "cannot reach the VSMF middleware on " << socketPath << "\n  " << err
                  << "\nIs it running? Start it in another terminal with ./vsmf\n";
        return 2;
    }

    std::cout << kVersion << " console - connected to " << socketPath << "\n"
              << "Type 'help' for commands, 'exit' to leave the console.\n";

    std::string line;
    for (;;) {
        if (g_signal != 0) { std::cout << "\ninterrupted\n"; break; }
        std::cout << "vsmf> " << std::flush;
        if (!std::getline(std::cin, line)) { std::cout << "\n"; break; }   // EOF / Ctrl-D
        line = util::trim(line);
        if (line.empty()) continue;
        std::string lower = util::toLower(line);
        if (lower == "exit" || lower == "quit") break;

        if (!client.connected()) {
            std::cout << "connection lost; reconnecting...\n";
            if (!client.connect(socketPath, name, 1000, err)) {
                std::cerr << "reconnect failed: " << err << "\n";
                return 3;
            }
        }

        Message req(MsgType::REQUEST, name, topics::kControl, line, Priority::HIGH);
        req.destination = endpoints::kControl;
        req.correlationId = req.messageId;
        if (!client.send(req, err)) {
            std::cerr << "send failed: " << err << "\n";
            continue;
        }

        // Wait for *our* answer: anything else on the socket is ignored.
        const std::uint64_t deadline = util::steadyNs() + 10ULL * 1000000000ULL;
        bool answered = false;
        while (util::steadyNs() < deadline) {
            Message resp;
            if (!client.receive(resp, 500, err)) {
                if (err == "timeout") continue;
                std::cerr << "receive failed: " << err << "\n";
                break;
            }
            if (resp.correlationId != req.correlationId) continue;
            if (resp.type == MsgType::ERROR) std::cout << "error: " << resp.payload << "\n";
            else if (!resp.payload.empty())  std::cout << resp.payload << "\n";
            answered = true;
            break;
        }
        if (!answered) std::cout << "no response from ControlService (timed out)\n";
    }

    client.disconnect();
    std::cout << "console closed; the framework keeps running.\n";
    return 0;
}

// ---------------------------------------------------------------------
// Terminal 1: dashboard renderer.
// ---------------------------------------------------------------------
class DashboardRenderer {
public:
    DashboardRenderer(DashboardService& d, PerformanceMonitor& p, HealthMonitor& h,
                      ServiceRegistry& r, const std::string& socketPath)
        : dash_(d), perf_(p), health_(h), reg_(r), socket_(socketPath),
          tty_(::isatty(STDOUT_FILENO) == 1) {}

    void render(bool force) {
        bool dirty = dash_.consumeDirty();
        if (!dirty && !force) return;

        DashboardData d = dash_.data();
        PerfSnapshot  s = perf_.snapshot();
        HealthState   h = health_.overall();

        char buf[2048];
        std::size_t n = 0;
        if (tty_) n += static_cast<std::size_t>(std::snprintf(buf + n, sizeof(buf) - n, "\033[H\033[2J"));

        n += static_cast<std::size_t>(std::snprintf(buf + n, sizeof(buf) - n,
            "+--------------------------------------------------------------+\n"
            "|            VSMF - VEHICLE REAL-TIME DASHBOARD                |\n"
            "+--------------------------------------------------------------+\n"
            "  Speed        : %-8.1f km/h\n"
            "  RPM          : %-8.0f\n"
            "  Temperature  : %-8.1f C\n"
            "  Battery      : %-8.1f %%\n"
            "  GPS          : %-8s  (%.4f, %.4f, %u sats)\n"
            "  Health       : %-8s\n"
            "  Latency      : %-8.1f us  (p95 %.1f us)\n"
            "  Throughput   : %-8.1f msg/sec\n"
            "+--------------------------------------------------------------+\n"
            "  Services     : %zu registered      CPU %.1f%%   RSS %llu KB\n"
            "  Messages     : published %llu  processed %llu  dropped %llu\n"
            "  Updates      : %llu    Uptime %.0f s\n",
            d.speed, d.rpm, d.temperature, d.battery,
            d.gpsFix ? "Active" : "NO FIX", d.latitude, d.longitude, d.satellites,
            vsmf::toString(h),
            s.avgLatencyUs, s.p95LatencyUs, s.throughputMsgPerSec,
            reg_.size(), s.cpuPercent, static_cast<unsigned long long>(s.rssKb),
            static_cast<unsigned long long>(s.published),
            static_cast<unsigned long long>(s.processed),
            static_cast<unsigned long long>(s.dropped),
            static_cast<unsigned long long>(d.updates), s.uptimeSec));

        if (!d.lastAlert.empty() && n < sizeof(buf))
            n += static_cast<std::size_t>(std::snprintf(buf + n, sizeof(buf) - n,
                "  Last alert   : %s (%s)\n", d.lastAlert.c_str(),
                util::formatWallTime(d.lastAlertAt).c_str()));

        if (n < sizeof(buf))
            std::snprintf(buf + n, sizeof(buf) - n,
                "+--------------------------------------------------------------+\n"
                "  Terminal 2: ./vsmf --console        (socket %s)\n"
                "  Ctrl-C to stop the framework.\n", socket_.c_str());

        std::fputs(buf, stdout);
        std::fflush(stdout);
    }

private:
    DashboardService&   dash_;
    PerformanceMonitor& perf_;
    HealthMonitor&      health_;
    ServiceRegistry&    reg_;
    std::string         socket_;
    bool                tty_;
};

// ---------------------------------------------------------------------
int runMiddleware(const Options& opt) {
    installSignalHandlers();

    // --- 1. Configuration -------------------------------------------
    ConfigManager cfgMgr;
    std::string err;
    bool cfgLoaded = cfgMgr.load(opt.configPath, err);
    if (!cfgLoaded) std::cerr << "[config] " << err << "\n";
    Config cfg = cfgMgr.get();
    if (!opt.socketOverride.empty()) cfg.socketPath = opt.socketOverride;
    if (!opt.logDirOverride.empty()) cfg.logDir = opt.logDirOverride;

    // --- 2. Logging --------------------------------------------------
    LoggerService logger;
    if (!logger.configure(cfg.logDir, cfg.logLevel, cfg.maxLogBytes, cfg.queueCapacity, err)) {
        std::cerr << "[logger] " << err << " - continuing with stderr only\n";
        logger.setEchoToConsole(true);
    }
    logger.start();
    logger.log(LogLevel::INFO, "main", std::string(kVersion) + " starting");
    logger.log(LogLevel::INFO, "main", cfgLoaded ? ("configuration loaded from " + opt.configPath)
                                                 : "running on built-in defaults");
    std::vector<std::string> warns = cfgMgr.warnings();
    for (std::size_t i = 0; i < warns.size(); ++i)
        logger.log(LogLevel::WARN, "config", warns[i]);
    logger.log(LogLevel::INFO, "config", cfg.toString());

    // --- 3. Execution layer ------------------------------------------
    ThreadPool pool;
    pool.setLogger(&logger);
    if (!pool.start(cfg.threadPoolSize, cfg.queueCapacity)) {
        logger.log(LogLevel::FATAL, "main", "cannot start the thread pool");
        logger.stop();
        return 1;
    }

    // --- 4. Monitoring counters --------------------------------------
    PerformanceMonitor perf;
    perf.setLogger(&logger);
    perf.setQueueDepthProvider([&pool] { return pool.queueDepth(); },
                               [&pool] { return pool.peakDepth(); });

    // --- 5. Transport + routing --------------------------------------
    ServiceRegistry      registry;
    DiscoveryManager     discovery(registry);
    CommunicationManager comm(registry);
    comm.setLogger(&logger);
    comm.setPerf(&perf);
    comm.setThreadPool(&pool);
    if (!comm.start(cfg, err)) {
        std::cerr << "[transport] " << err << "\n";
        logger.log(LogLevel::FATAL, "main", "transport failed: " + err);
        pool.stop(false);
        logger.stop();
        return 1;
    }

    // --- 6. Services --------------------------------------------------
    DataGenerator gen;
    gen.setTargetSpeed(60.0);

    DashboardService      dashboard(comm);
    DiagnosticService     diagnostics(comm, cfgMgr);
    VehicleControlService control(comm, discovery, cfgMgr, cfg.publishIntervalMs);
    SpeedSensorService    speed(comm, gen, cfg.publishIntervalMs);
    EngineSensorService   engine(comm, gen, cfg.publishIntervalMs);
    BatteryService        battery(comm, gen, cfg.publishIntervalMs);
    GPSService            gps(comm, gen, cfg.publishIntervalMs);

    HealthMonitor  healthMon(comm, registry, cfgMgr);
    std::atomic<bool> shutdownFlag(false);

    SystemContext ctx;
    ctx.cfg = &cfgMgr;
    ctx.registry = &registry;
    ctx.discovery = &discovery;
    ctx.comm = &comm;
    ctx.pool = &pool;
    ctx.logger = &logger;
    ctx.perf = &perf;
    ctx.health = &healthMon;
    ctx.generator = &gen;
    ctx.dashboard = &dashboard;
    ctx.diagnostics = &diagnostics;
    ctx.control = &control;
    ctx.shutdownFlag = &shutdownFlag;

    LifecycleManager lifecycle(registry);
    lifecycle.setLogger(&logger);
    ctx.lifecycle = &lifecycle;

    ControlService console(comm, ctx);

    // Consumers first so no early sample is published into the void.
    IService* order[] = {&logger, &dashboard, &diagnostics, &control, &console,
                         &speed, &engine, &battery, &gps};
    for (std::size_t i = 0; i < sizeof(order) / sizeof(order[0]); ++i) {
        std::string aerr;
        if (!lifecycle.add(order[i], aerr)) logger.log(LogLevel::ERROR, "main", aerr);
    }

    std::string startErr;
    if (!lifecycle.startAll(startErr))
        logger.log(LogLevel::ERROR, "main", "degraded start: " + startErr);

    // --- 7. Monitoring ------------------------------------------------
    perf.setReportSink([&logger, &dashboard](const PerfSnapshot& s) {
        logger.logTo(LogChannel::Performance, LogLevel::INFO, "PerformanceMonitor", s.toString());
        dashboard.setPerfLine(s.avgLatencyUs, s.throughputMsgPerSec);
    });
    perf.start(cfg.metricsIntervalMs);

    if (!healthMon.start(err))
        logger.log(LogLevel::ERROR, "main", "health monitor failed to start: " + err);

    logger.log(LogLevel::INFO, "main", "VSMF is up; console socket " + cfg.socketPath);

    // --- 8. Run -------------------------------------------------------
    DashboardRenderer renderer(dashboard, perf, healthMon, registry, cfg.socketPath);
    const std::uint64_t startNs = util::steadyNs();
    const std::uint64_t stopAtNs = opt.durationSec > 0
        ? startNs + static_cast<std::uint64_t>(opt.durationSec) * 1000000000ULL : 0;
    std::uint64_t lastForced = 0;

    if (!opt.noDashboard) renderer.render(true);
    while (g_signal == 0 && !shutdownFlag.load(std::memory_order_acquire)) {
        struct timespec ts;
        ts.tv_sec = 0;
        ts.tv_nsec = 200 * 1000000L;
        ::nanosleep(&ts, nullptr);          // EINTR here just ends the nap

        std::uint64_t now = util::steadyNs();
        if (stopAtNs != 0 && now >= stopAtNs) break;
        if (!opt.noDashboard) {
            bool force = (now - lastForced) > 1000000000ULL;   // refresh at 1 Hz
            renderer.render(force);
            if (force) lastForced = now;
        }
    }

    if (g_signal != 0)
        logger.log(LogLevel::WARN, "main", "signal " + std::to_string(static_cast<int>(g_signal)) +
                                           " received, shutting down");

    // --- 9. Ordered shutdown -----------------------------------------
    std::cout << "\nshutting down..." << std::endl;
    healthMon.stop();          // stop probing before endpoints disappear
    perf.stop();
    lifecycle.stopAll();       // reverse order: producers, then consumers
    comm.stop();               // broker down, socket unlinked
    pool.stop(true);           // drain queued work
    logger.log(LogLevel::INFO, "main", "VSMF stopped cleanly");
    logger.flush();
    logger.stop();
    std::cout << "stopped." << std::endl;
    return 0;
}

}  // namespace

int main(int argc, char** argv) {
    Options opt;
    std::string err;
    if (!parseArgs(argc, argv, opt, err)) {
        std::cerr << err << "\nTry --help\n";
        return 64;                       // EX_USAGE
    }
    if (opt.help)    { usage(); return 0; }
    if (opt.version) { std::cout << kVersion << "\n"; return 0; }

    if (opt.console) {
        std::string socketPath = opt.socketOverride;
        if (socketPath.empty()) {
            // The console must talk to the same socket the middleware
            // bound, so it reads the same configuration file.
            ConfigManager cm;
            std::string cerr;
            cm.load(opt.configPath, cerr);
            socketPath = cm.get().socketPath;
        }
        return runConsole(socketPath);
    }

    try {
        return runMiddleware(opt);
    } catch (const std::exception& e) {
        std::cerr << "fatal: " << e.what() << "\n";
        return 1;
    } catch (...) {
        std::cerr << "fatal: unknown exception\n";
        return 1;
    }
}
