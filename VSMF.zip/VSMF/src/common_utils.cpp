#include "common/Utils.hpp"

#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <sstream>

#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

namespace vsmf {
namespace util {

void ignoreSigPipe() noexcept {
    struct sigaction sa;
    std::memset(&sa, 0, sizeof(sa));
    sa.sa_handler = SIG_IGN;
    ::sigaction(SIGPIPE, &sa, nullptr);
}

bool setCloExec(int fd) noexcept {
    if (fd < 0) return false;
    int flags = ::fcntl(fd, F_GETFD);
    if (flags < 0) return false;
    return ::fcntl(fd, F_SETFD, flags | FD_CLOEXEC) == 0;
}

bool setNonBlocking(int fd, bool on) noexcept {
    if (fd < 0) return false;
    int flags = ::fcntl(fd, F_GETFL);
    if (flags < 0) return false;
    int want = on ? (flags | O_NONBLOCK) : (flags & ~O_NONBLOCK);
    return ::fcntl(fd, F_SETFL, want) == 0;
}

void closeQuiet(int& fd) noexcept {
    if (fd < 0) return;
    // On Linux close() never leaves the fd open even on EINTR, so no retry.
    int saved = errno;
    ::close(fd);
    errno = saved;
    fd = -1;
}

std::ptrdiff_t readAll(int fd, void* buf, std::size_t n) noexcept {
    unsigned char* p = static_cast<unsigned char*>(buf);
    std::size_t done = 0;
    while (done < n) {
        ssize_t r = ::read(fd, p + done, n - done);
        if (r > 0) { done += static_cast<std::size_t>(r); continue; }
        if (r == 0) return 0;                       // peer closed cleanly
        if (errno == EINTR) continue;               // signal, retry
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            int rc = waitReadable(fd, 1000);
            if (rc > 0) continue;
            if (rc == 0) { errno = ETIMEDOUT; return -1; }
            return -1;
        }
        return -1;
    }
    return static_cast<std::ptrdiff_t>(n);
}

std::ptrdiff_t writeAll(int fd, const void* buf, std::size_t n) noexcept {
    const unsigned char* p = static_cast<const unsigned char*>(buf);
    std::size_t done = 0;
    while (done < n) {
        ssize_t w = ::write(fd, p + done, n - done);
        if (w > 0) { done += static_cast<std::size_t>(w); continue; }
        if (w < 0 && errno == EINTR) continue;
        if (w < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            int rc = waitWritable(fd, 1000);
            if (rc > 0) continue;
            if (rc == 0) { errno = ETIMEDOUT; return -1; }
            return -1;
        }
        return -1;   // includes EPIPE when the peer is gone
    }
    return static_cast<std::ptrdiff_t>(n);
}

static int waitFd(int fd, short events, int timeoutMs) noexcept {
    if (fd < 0) { errno = EBADF; return -1; }
    std::uint64_t deadline = steadyNs() + static_cast<std::uint64_t>(timeoutMs < 0 ? 0 : timeoutMs) * 1000000ULL;
    for (;;) {
        struct pollfd pfd;
        pfd.fd = fd;
        pfd.events = events;
        pfd.revents = 0;
        int rc = ::poll(&pfd, 1, timeoutMs);
        if (rc >= 0) {
            if (rc == 0) return 0;
            if (pfd.revents & (POLLERR | POLLNVAL)) { errno = EIO; return -1; }
            return 1;   // POLLHUP still reported as ready: read() will see EOF
        }
        if (errno != EINTR) return -1;
        if (timeoutMs < 0) continue;                       // infinite wait
        std::uint64_t now = steadyNs();
        if (now >= deadline) return 0;
        timeoutMs = static_cast<int>((deadline - now) / 1000000ULL);
    }
}

int waitReadable(int fd, int timeoutMs) noexcept { return waitFd(fd, POLLIN, timeoutMs); }
int waitWritable(int fd, int timeoutMs) noexcept { return waitFd(fd, POLLOUT, timeoutMs); }

std::uint64_t wallNs() noexcept {
    struct timespec ts;
    if (::clock_gettime(CLOCK_REALTIME, &ts) != 0) return 0;
    return static_cast<std::uint64_t>(ts.tv_sec) * 1000000000ULL + static_cast<std::uint64_t>(ts.tv_nsec);
}

std::uint64_t steadyNs() noexcept {
    struct timespec ts;
    if (::clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return 0;
    return static_cast<std::uint64_t>(ts.tv_sec) * 1000000000ULL + static_cast<std::uint64_t>(ts.tv_nsec);
}

std::string formatWallTime(std::uint64_t ns) {
    time_t secs = static_cast<time_t>(ns / 1000000000ULL);
    unsigned ms = static_cast<unsigned>((ns % 1000000000ULL) / 1000000ULL);
    struct tm tmv;
    if (::localtime_r(&secs, &tmv) == nullptr) return "1970-01-01 00:00:00.000";
    char buf[40];
    std::snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d.%03u",
                  tmv.tm_year + 1900, tmv.tm_mon + 1, tmv.tm_mday,
                  tmv.tm_hour, tmv.tm_min, tmv.tm_sec, ms);
    return std::string(buf);
}

bool makeDirs(const std::string& path, std::string& err) {
    if (path.empty()) { err = "empty path"; return false; }
    std::string cur;
    cur.reserve(path.size());
    if (path[0] == '/') cur = "/";
    std::size_t i = 0;
    while (i < path.size()) {
        std::size_t j = path.find('/', i);
        if (j == std::string::npos) j = path.size();
        std::string part = path.substr(i, j - i);
        if (!part.empty() && part != ".") {
            if (cur.size() > 1 || (cur.size() == 1 && cur[0] != '/')) cur += "/";
            cur += part;
            if (::mkdir(cur.c_str(), 0755) != 0 && errno != EEXIST) {
                err = "mkdir(" + cur + "): " + std::strerror(errno);
                return false;
            }
        }
        i = j + 1;
    }
    return true;
}

bool fileExists(const std::string& path) noexcept {
    struct stat st;
    return ::stat(path.c_str(), &st) == 0;
}

long fileSize(const std::string& path) noexcept {
    struct stat st;
    if (::stat(path.c_str(), &st) != 0) return -1;
    return static_cast<long>(st.st_size);
}

std::int64_t fileMTime(const std::string& path) noexcept {
    struct stat st;
    if (::stat(path.c_str(), &st) != 0) return -1;
    return static_cast<std::int64_t>(st.st_mtime);
}

std::string dirName(const std::string& path) {
    std::size_t p = path.find_last_of('/');
    if (p == std::string::npos) return ".";
    if (p == 0) return "/";
    return path.substr(0, p);
}

std::string joinPath(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    if (b.empty()) return a;
    if (b[0] == '/') return b;
    if (a[a.size() - 1] == '/') return a + b;
    return a + "/" + b;
}

std::string trim(const std::string& s) {
    std::size_t b = 0, e = s.size();
    while (b < e && std::isspace(static_cast<unsigned char>(s[b]))) ++b;
    while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1]))) --e;
    return s.substr(b, e - b);
}

std::vector<std::string> splitWhitespace(const std::string& s, std::size_t maxTokens) {
    std::vector<std::string> out;
    std::size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i]))) ++i;
        if (i >= s.size()) break;
        if (maxTokens != 0 && out.size() + 1 == maxTokens) {   // last token = rest
            out.push_back(trim(s.substr(i)));
            return out;
        }
        std::size_t j = i;
        while (j < s.size() && !std::isspace(static_cast<unsigned char>(s[j]))) ++j;
        out.push_back(s.substr(i, j - i));
        i = j;
    }
    return out;
}

bool parseInt(const std::string& s, long long& out) noexcept {
    if (s.empty()) return false;
    errno = 0;
    char* end = nullptr;
    long long v = std::strtoll(s.c_str(), &end, 10);
    if (errno == ERANGE || end == s.c_str()) return false;
    while (end && *end && std::isspace(static_cast<unsigned char>(*end))) ++end;
    if (end && *end != '\0') return false;
    out = v;
    return true;
}

bool parseDouble(const std::string& s, double& out) noexcept {
    if (s.empty()) return false;
    errno = 0;
    char* end = nullptr;
    double v = std::strtod(s.c_str(), &end);
    if (errno == ERANGE || end == s.c_str()) return false;
    while (end && *end && std::isspace(static_cast<unsigned char>(*end))) ++end;
    if (end && *end != '\0') return false;
    if (v != v) return false;                       // reject NaN
    out = v;
    return true;
}

std::string toLower(std::string s) {
    for (std::size_t i = 0; i < s.size(); ++i)
        s[i] = static_cast<char>(std::tolower(static_cast<unsigned char>(s[i])));
    return s;
}

std::string sanitize(const std::string& s, std::size_t maxLen) {
    std::string out;
    out.reserve(s.size() < maxLen ? s.size() : maxLen);
    for (std::size_t i = 0; i < s.size() && out.size() < maxLen; ++i) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        out.push_back((c < 0x20 || c == 0x7f) ? ' ' : s[i]);
    }
    return out;
}

long clockTicksPerSec() noexcept {
    long t = ::sysconf(_SC_CLK_TCK);
    return t > 0 ? t : 100;
}

bool readProcCpuJiffies(std::uint64_t& jiffies) noexcept {
    std::ifstream f("/proc/self/stat");
    if (!f.is_open()) return false;
    std::string line;
    if (!std::getline(f, line)) return false;
    // Field 2 (comm) can contain spaces and ')', so scan from the LAST ')'.
    std::size_t rp = line.find_last_of(')');
    if (rp == std::string::npos || rp + 2 >= line.size()) return false;
    std::istringstream is(line.substr(rp + 2));
    std::string tok;
    unsigned long long utime = 0, stime = 0;
    // The token after comm is field 3 (state); utime is field 14, stime 15.
    for (int i = 3; i <= 15; ++i) {
        if (!(is >> tok)) return false;
        if (i == 14 || i == 15) {
            errno = 0;
            char* end = nullptr;
            unsigned long long v = std::strtoull(tok.c_str(), &end, 10);
            if (errno == ERANGE || end == tok.c_str()) return false;
            if (i == 14) utime = v; else stime = v;
        }
    }
    jiffies = static_cast<std::uint64_t>(utime + stime);
    return true;
}

bool readProcRssKb(std::uint64_t& rssKb) noexcept {
    std::ifstream f("/proc/self/statm");
    if (!f.is_open()) return false;
    unsigned long long totalPages = 0, residentPages = 0;
    if (!(f >> totalPages >> residentPages)) return false;
    long ps = ::sysconf(_SC_PAGESIZE);
    if (ps <= 0) ps = 4096;
    rssKb = static_cast<std::uint64_t>(residentPages) * static_cast<std::uint64_t>(ps) / 1024ULL;
    return true;
}

}  // namespace util
}  // namespace vsmf
