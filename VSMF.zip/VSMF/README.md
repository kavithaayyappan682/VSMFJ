# VSMF — Vehicle Service Management Framework

A service-oriented middleware framework for automotive systems on embedded Linux.
Independent vehicle services publish, subscribe and call each other over Unix
domain sockets through a central broker, with configuration, logging, health
monitoring and performance measurement built in.

- **Language / standard:** C++17
- **Toolchain:** GCC/G++ 7.5.0
- **Target OS:** Ubuntu 18.04.6 LTS
- **IPC:** Unix domain sockets
- **Configuration:** JSON (`config/vsmf_config.json`)
- **Unit tests:** Google Test
- **External dependencies:** none (the JSON parser is part of the project)

---

## 1. Build and run

```bash
make                # builds ./vsmf
make run            # Terminal 1: middleware + live dashboard
make console        # Terminal 2: interactive console
make demo           # headless 12-second run, for CI
make test           # builds and runs the Google Test suite
make clean
```

### The two-terminal demo

**Terminal 1** — the framework and the live dashboard:

```
$ ./vsmf
+--------------------------------------------------------------+
|            VSMF - VEHICLE REAL-TIME DASHBOARD                |
+--------------------------------------------------------------+
  Speed        : 60.7     km/h
  RPM          : 1166
  Temperature  : 58.2     C
  Battery      : 99.8     %
  GPS          : Active    (13.0831, 80.2712, 9 sats)
  Health       : HEALTHY
  Latency      : 77.3     us  (p95 167.9 us)
  Throughput   : 42.4     msg/sec
+--------------------------------------------------------------+
  Services     : 8 registered      CPU 0.4%   RSS 5244 KB
  Messages     : published 80  processed 244  dropped 0
+--------------------------------------------------------------+
```

The panel refreshes whenever a service publishes and at least once a second.
When standard output is not a terminal (a pipe, a log file, systemd) the ANSI
clear-screen is dropped automatically and the panel is simply appended.

**Terminal 2** — the interactive console, a *separate process* that connects to
the same socket, so every command is real IPC:

```
$ ./vsmf --console
vsmf> services
vsmf> discover BatteryService
vsmf> publish_speed 210
vsmf> battery
vsmf> diagnostics
vsmf> metrics
vsmf> logs diagnostics 5
vsmf> status
vsmf> restart DiagnosticService
vsmf> exit
```

| Command | Effect |
|---|---|
| `services` | every registered service with kind, state and health |
| `discover <name>` | resolve a service through the DiscoveryManager |
| `publish_speed <kph>` | inject a speed value and publish it on `vehicle.speed` |
| `battery` | request/response call to BatteryService over the socket |
| `diagnostics` | current fault flags, configured limits, recent alerts |
| `metrics` | throughput, latency (avg/min/max/p95), CPU, RSS, queue depth |
| `logs [channel] [n]` | tail `middleware`, `performance`, `diagnostics` or `health` |
| `status` | vehicle-control decision, dashboard snapshot, transport state |
| `health` | heartbeat report, per service |
| `config` / `reload` | show the effective configuration / re-read the file |
| `start`/`stop`/`pause`/`resume`/`restart <name>` | lifecycle control |
| `shutdown` | stop the whole framework |
| `exit` | leave the console; the framework keeps running |

### Command-line options

```
-c, --config <file>   configuration file (default config/vsmf_config.json)
    --socket <path>   override the Unix domain socket path
    --log-dir <dir>   override the log directory
-i, --console         attach the interactive console to a running instance
    --no-dashboard    run headless
    --duration <sec>  run for N seconds then exit cleanly (demo/CI)
-h, --help            usage
-v, --version         version
```

---

## 2. Directory layout

```
VSMF/
├── include/
│   ├── common/      Types.hpp  Utils.hpp  IService.hpp
│   ├── core/        ServiceRegistry  DiscoveryManager  CommunicationManager
│   │                MessageRouter    PubSubManager     RequestResponseManager
│   │                IPCManager
│   ├── data/        Message.hpp  DataGenerator.hpp
│   ├── services/    ServiceBase, four producers, three consumers, ControlService
│   └── support/     ConfigManager  LoggerService  ThreadPool
│                    HealthMonitor  LifecycleManager  PerformanceMonitor  Json
├── src/             mirror of include/, plus main.cpp
├── tests/           Google Test suite (134 cases)
├── config/          vsmf_config.json
├── logs/            middleware.log  performance.log  diagnostics.log  health.log
├── docs/            ARCHITECTURE.md  EDGE_CASES.md
├── Makefile
└── README.md
```

---

## 3. Configuration

`config/vsmf_config.json`:

```json
{
  "speed_limit": 180,
  "temperature_limit": 100,
  "battery_limit": 15,
  "heartbeat_interval": 2,
  "thread_pool_size": 4,
  "log_level": "INFO"
}
```

The DiagnosticService reads its thresholds from the ConfigManager on every
sample, never from compiled-in constants, so `reload` changes fault behaviour
at runtime. Additional optional keys (`rpm_limit`, `missed_heartbeats`,
`socket_path`, `log_dir`, `request_timeout_ms`, `publish_interval_ms`,
`metrics_interval_ms`, `queue_capacity`, `max_log_bytes`) all have documented
defaults; anything missing, malformed or out of range is replaced by its
default and reported as a warning rather than stopping the boot.

---

## 4. Message flows

### Publish / subscribe

```
SpeedSensorService
   └─ CommunicationManager ─ MessageRouter ─ PubSubManager ─ IPCManager
        └─ UDS ─┬─ DashboardService
                ├─ DiagnosticService
                ├─ VehicleControlService
                └─ LoggerService
```

### Request / response

```
VehicleControlService ─ DiscoveryManager (finds BatteryService)
   └─ CommunicationManager ─ RequestResponseManager ─ IPCManager
        └─ UDS ─ BatteryService ─ response ─ back along the same path
```

Both directions really traverse the socket: the broker is a separate hop, not a
shortcut through shared memory, which is what makes the console in Terminal 2 an
ordinary peer.

---

## 5. Logs

| File | Contents |
|---|---|
| `logs/middleware.log` | lifecycle, registration, transport, warnings and errors |
| `logs/performance.log` | periodic throughput, latency, CPU, RSS, queue depth |
| `logs/diagnostics.log` | fault alerts with severity and threshold |
| `logs/health.log` | heartbeat rounds and per-service health |

Logging is asynchronous and bounded: under overload the oldest entries are
dropped and counted rather than allowed to grow without limit or to block the
publisher. Files rotate to `.log.1` at the configured size, and WARN or worse is
flushed immediately.

---

## 6. Tests

```bash
make install-gtest    # once, on Ubuntu: gtest ships as source only
make test
```

134 cases across 26 suites cover all twenty-one components: the wire format at
every truncation offset, the JSON parser's malformed-input matrix and recursion
guard, configuration clamping and hot reload, thread-pool backpressure and
priority eviction, logger rotation and bounded drops, the registry, discovery,
pub/sub wildcards, request/response timeouts and cancellation, socket takeover
and hostile frame lengths, all seven vehicle services, the health monitor, the
console command surface, and two whole-system integration tests.

The suite is order-independent (`--gtest_shuffle`) and has no fixed sleeps in
its assertions.

---

## 7. Documentation

- `docs/ARCHITECTURE.md` — components, threading model, wire format, boot and
  shutdown ordering, and the reasoning behind the significant design choices.
- `docs/EDGE_CASES.md` — the failure modes that were designed for, and how each
  one is handled.
