// =====================================================================
//  System tests
//
//  Every other test file links against VSMF's object files and drives
//  its C++ classes directly. This file does not: it execs the actual
//  ./vsmf executable that `make` produces, exactly as an operator would
//  from a shell (README.md §1), and observes it only from the outside -
//  argv in, stdout/stderr and exit code out, real files on disk, real
//  signals. That is the only way to test the things main.cpp itself is
//  responsible for: argument parsing, exit codes, process lifetime,
//  and the two-terminal deployment model.
//
//  Requires ./vsmf to already be built (the `test` Makefile target
//  depends on it - see the Makefile).
// =====================================================================
#include <gtest/gtest.h>

#include <string>
#include <vector>

#include "TestUtil.hpp"
#include "common/Utils.hpp"

using namespace vsmf;
using namespace vsmftest;

namespace {

const char* kBin = "./vsmf";

bool binaryExists() { return util::fileExists(kBin); }

// The middleware logs "VSMF is up" through LoggerService, which writes to
// the log file, not to the piped stdout ChildProcess captures - so
// readiness is detected the way a real deployment tool would: the moment
// IPCManager has bound and is listening on the socket path.
bool waitUntilListening(const std::string& sock, int timeoutMs) {
    return waitUntil([&sock] { return util::fileExists(sock); }, timeoutMs);
}

}  // namespace

// =====================================================================
//  1. Argument parsing and the documented exit codes (EDGE_CASES.md
//     §11: "Unknown options and bad argument values exit with EX_USAGE
//     (64) ... never with a stack trace").
// =====================================================================

TEST(System_CommandLine, HelpExitsZeroAndListsEveryDocumentedOption) {
    ASSERT_TRUE(binaryExists()) << "build ./vsmf first (make)";
    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--help"}));
    int code = -1;
    ASSERT_TRUE(p.waitExit(5000, &code));
    EXPECT_EQ(0, code);
    // README.md §1's option table, verbatim in usage().
    for (const char* opt : {"--config", "--socket", "--log-dir", "--console",
                            "--no-dashboard", "--duration", "--help", "--version"})
        EXPECT_NE(std::string::npos, p.output().find(opt)) << "missing from --help: " << opt;
}

TEST(System_CommandLine, VersionExitsZeroAndPrintsAVersionString) {
    ASSERT_TRUE(binaryExists());
    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--version"}));
    int code = -1;
    ASSERT_TRUE(p.waitExit(5000, &code));
    EXPECT_EQ(0, code);
    EXPECT_NE(std::string::npos, p.output().find("VSMF"));
}

TEST(System_CommandLine, UnknownOptionExitsWithExUsageNotAStackTrace) {
    ASSERT_TRUE(binaryExists());
    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--this-flag-does-not-exist"}));
    int code = -1;
    ASSERT_TRUE(p.waitExit(5000, &code));
    EXPECT_EQ(64, code);   // EX_USAGE, documented in EDGE_CASES.md #11
    EXPECT_EQ(std::string::npos, p.output().find("terminate"));
    EXPECT_EQ(std::string::npos, p.output().find("Segmentation"));
}

TEST(System_CommandLine, OptionMissingItsRequiredValueExitsWithExUsage) {
    ASSERT_TRUE(binaryExists());
    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--config"}));   // no path follows
    int code = -1;
    ASSERT_TRUE(p.waitExit(5000, &code));
    EXPECT_EQ(64, code);
}

TEST(System_CommandLine, DurationOutOfRangeExitsWithExUsage) {
    ASSERT_TRUE(binaryExists());
    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--duration", "999999"}));   // > 86400 s
    int code = -1;
    ASSERT_TRUE(p.waitExit(5000, &code));
    EXPECT_EQ(64, code);
}

// =====================================================================
//  2. A full boot/run/shutdown cycle of the real binary (the `make demo`
//     scenario): config, logging, transport and every documented service
//     coming up together, then an ordered, quiet shutdown.
// =====================================================================

TEST(System_Demo, HeadlessDurationRunExitsZeroAndWritesEveryDocumentedLog) {
    ASSERT_TRUE(binaryExists());
    std::string logDir = uniqueDir("sys_demo_logs");
    std::string sock = uniquePath("sys_demo", ".sock");
    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--no-dashboard", "--duration", "3",
                         "--log-dir", logDir, "--socket", sock}));
    int code = -1;
    ASSERT_TRUE(p.waitExit(10000, &code)) << "vsmf did not exit within its --duration budget";
    EXPECT_EQ(0, code);

    // README.md §5: the four documented log files.
    EXPECT_TRUE(util::fileExists(logDir + "/middleware.log"));
    EXPECT_TRUE(util::fileExists(logDir + "/performance.log"));
    EXPECT_TRUE(util::fileExists(logDir + "/health.log"));

    std::string middleware = readFile(logDir + "/middleware.log");
    EXPECT_NE(std::string::npos, middleware.find("VSMF"));
    EXPECT_NE(std::string::npos, middleware.find("starting"));
    EXPECT_NE(std::string::npos, middleware.find("stopped cleanly"));
    removeTree(logDir);
}

TEST(System_Demo, CustomConfigFileIsHonouredByTheRunningProcess) {
    // A functional, end-to-end check that --config really is read by the
    // shipped binary: a very tight speed limit must produce an over-speed
    // alert in diagnostics.log during a normal headless run (the built-in
    // DataGenerator drifts toward 60 km/h on its own - see
    // docs data/DataGenerator.hpp - so no operator input is needed).
    ASSERT_TRUE(binaryExists());
    std::string logDir = uniqueDir("sys_cfg_logs");
    std::string sock = uniquePath("sys_cfg", ".sock");
    std::string cfgPath = uniquePath("sys_cfg_file", ".json");
    ASSERT_TRUE(writeFile(cfgPath, "{\"speed_limit\":1,\"publish_interval_ms\":50}"));

    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--no-dashboard", "--duration", "3", "--log-dir", logDir,
                         "--socket", sock, "--config", cfgPath}));
    int code = -1;
    ASSERT_TRUE(p.waitExit(10000, &code));
    EXPECT_EQ(0, code);

    std::string diagLog = readFile(logDir + "/diagnostics.log");
    EXPECT_NE(std::string::npos, diagLog.find("over-speed"))
        << "a 1 km/h limit must be exceeded by ordinary simulated traffic";
    removeTree(logDir);
    std::remove(cfgPath.c_str());
}

TEST(System_Demo, MalformedConfigFileStillBootsOnDefaultsWithAWarning) {
    // EDGE_CASES.md §3: "Missing file, unreadable file, corrupt file ->
    // documented defaults, boot continues, warning logged." Verified here
    // against the real binary, not just ConfigManager in isolation.
    ASSERT_TRUE(binaryExists());
    std::string logDir = uniqueDir("sys_badcfg_logs");
    std::string sock = uniquePath("sys_badcfg", ".sock");
    std::string cfgPath = uniquePath("sys_badcfg_file", ".json");
    ASSERT_TRUE(writeFile(cfgPath, "{ this is not valid json"));

    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--no-dashboard", "--duration", "2", "--log-dir", logDir,
                         "--socket", sock, "--config", cfgPath}));
    int code = -1;
    ASSERT_TRUE(p.waitExit(8000, &code));
    EXPECT_EQ(0, code) << "a corrupt config file must not stop the vehicle from booting";

    std::string middleware = readFile(logDir + "/middleware.log");
    EXPECT_NE(std::string::npos, middleware.find("built-in defaults"));
    removeTree(logDir);
    std::remove(cfgPath.c_str());
}

// =====================================================================
//  3. Two-terminal deployment: a real ./vsmf --console child process
//     driving a real ./vsmf middleware child process, exactly as
//     README.md §1 documents Terminal 1 / Terminal 2.
// =====================================================================

TEST(System_Console, ConsoleReportsClearlyWhenNoBrokerIsRunning) {
    // README.md §11 / EDGE_CASES.md: "The console reports clearly when no
    // broker is running."
    ASSERT_TRUE(binaryExists());
    std::string sock = uniquePath("sys_nobroker", ".sock");
    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--console", "--socket", sock}));
    int code = -1;
    ASSERT_TRUE(p.waitExit(5000, &code));
    EXPECT_EQ(2, code);
    EXPECT_NE(std::string::npos, p.output().find("Is it running"));
}

TEST(System_Console, TwoTerminalSessionRunsRealCommandsOverTheRealSocket) {
    ASSERT_TRUE(binaryExists());
    std::string logDir = uniqueDir("sys_console_logs");
    std::string sock = uniquePath("sys_console", ".sock");

    // Terminal 1: the middleware, no fixed --duration - it is stopped by
    // signal below, the way an operator's Ctrl-C works.
    ChildProcess mw;
    ASSERT_TRUE(mw.start({kBin, "--no-dashboard", "--log-dir", logDir, "--socket", sock}));
    ASSERT_TRUE(waitUntilListening(sock, 8000)) << mw.output();

    // Terminal 2: a real, separate console process, talking to Terminal 1
    // purely over the Unix domain socket.
    ChildProcess console;
    ASSERT_TRUE(console.start({kBin, "--console", "--socket", sock}));
    ASSERT_TRUE(console.waitForOutput("vsmf>", 5000)) << console.output();

    ASSERT_TRUE(console.writeLine("services"));
    ASSERT_TRUE(console.waitForOutput("SpeedSensorService", 5000)) << console.output();

    ASSERT_TRUE(console.writeLine("publish_speed 42"));
    ASSERT_TRUE(console.waitForOutput("42", 5000));

    ASSERT_TRUE(console.writeLine("battery"));
    ASSERT_TRUE(console.waitForOutput("BatteryService responded", 5000)) << console.output();

    ASSERT_TRUE(console.writeLine("exit"));
    int consoleCode = -1;
    ASSERT_TRUE(console.waitExit(5000, &consoleCode));
    EXPECT_EQ(0, consoleCode);
    EXPECT_NE(std::string::npos, console.output().find("framework keeps running"));

    // Terminal 1 must genuinely still be up after Terminal 2 left: it
    // takes an explicit signal, not just the console disconnecting, to
    // bring it down.
    mw.sendSignal(SIGTERM);
    int mwCode = -1;
    ASSERT_TRUE(mw.waitExit(8000, &mwCode));
    EXPECT_EQ(0, mwCode);
    removeTree(logDir);
}

TEST(System_Console, ASecondInstanceOnTheSameSocketIsRefusedNotAllowedToStealTraffic) {
    // EDGE_CASES.md §1: "A second instance on the same socket: refused
    // with a clear message instead of silently stealing traffic."
    ASSERT_TRUE(binaryExists());
    std::string logDir1 = uniqueDir("sys_dup1_logs");
    std::string logDir2 = uniqueDir("sys_dup2_logs");
    std::string sock = uniquePath("sys_dup", ".sock");

    ChildProcess first;
    ASSERT_TRUE(first.start({kBin, "--no-dashboard", "--log-dir", logDir1, "--socket", sock}));
    ASSERT_TRUE(waitUntilListening(sock, 8000)) << first.output();

    ChildProcess second;
    ASSERT_TRUE(second.start({kBin, "--no-dashboard", "--duration", "2",
                              "--log-dir", logDir2, "--socket", sock}));
    int secondCode = -1;
    ASSERT_TRUE(second.waitExit(8000, &secondCode));
    EXPECT_NE(0, secondCode);   // refused, not a silent takeover

    // The first instance is the one still actually serving the socket.
    ChildProcess console;
    ASSERT_TRUE(console.start({kBin, "--console", "--socket", sock}));
    ASSERT_TRUE(console.waitForOutput("vsmf>", 5000));
    ASSERT_TRUE(console.writeLine("services"));
    ASSERT_TRUE(console.waitForOutput("SpeedSensorService", 5000));
    console.writeLine("exit");
    console.waitExit(3000);

    first.sendSignal(SIGTERM);
    int firstCode = -1;
    ASSERT_TRUE(first.waitExit(8000, &firstCode));
    EXPECT_EQ(0, firstCode);
    removeTree(logDir1);
    removeTree(logDir2);
}

// =====================================================================
//  4. Process-level shutdown: SIGINT/SIGTERM handling (EDGE_CASES.md
//     §11), exercised against the real process and its real signal
//     handler, not a unit test of the handler function alone.
// =====================================================================

TEST(System_Shutdown, SigtermStopsAnUnboundedRunCleanlyAndQuickly) {
    ASSERT_TRUE(binaryExists());
    std::string logDir = uniqueDir("sys_sigterm_logs");
    std::string sock = uniquePath("sys_sigterm", ".sock");
    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--no-dashboard", "--log-dir", logDir, "--socket", sock}));
    ASSERT_TRUE(waitUntilListening(sock, 8000)) << p.output();

    p.sendSignal(SIGTERM);
    int code = -1;
    ASSERT_TRUE(p.waitExit(5000, &code)) << "SIGTERM must be handled promptly (no SA_RESTART, "
                                            "per EDGE_CASES.md #11), not ignored";
    EXPECT_EQ(0, code);
    EXPECT_NE(std::string::npos, p.output().find("shutting down"));
    EXPECT_NE(std::string::npos, p.output().find("stopped"));

    std::string middleware = readFile(logDir + "/middleware.log");
    EXPECT_NE(std::string::npos, middleware.find("signal"));
    removeTree(logDir);
}

TEST(System_Shutdown, SigintIsHandledTheSameWayAsSigterm) {
    ASSERT_TRUE(binaryExists());
    std::string logDir = uniqueDir("sys_sigint_logs");
    std::string sock = uniquePath("sys_sigint", ".sock");
    ChildProcess p;
    ASSERT_TRUE(p.start({kBin, "--no-dashboard", "--log-dir", logDir, "--socket", sock}));
    ASSERT_TRUE(waitUntilListening(sock, 8000)) << p.output();

    p.sendSignal(SIGINT);
    int code = -1;
    ASSERT_TRUE(p.waitExit(5000, &code));
    EXPECT_EQ(0, code);
    removeTree(logDir);
}
