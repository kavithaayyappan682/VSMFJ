// =====================================================================
//  Integration tests
//
//  tests/test_services.cpp already contains two whole-system integration
//  tests ("Integration.TheWholeFrameworkRunsPublishSubscribeAndRequest
//  Response" and "...RepeatedStartStopCyclesDoNotLeakEndpointsOrThreads")
//  that boot every component together, the way main.cpp does.
//
//  This file complements those with narrower integration tests: each one
//  wires together two or three real, non-mocked components over the
//  actual Unix domain socket and checks the *seam* between them - the
//  place a unit test of either component alone cannot see:
//
//    - ConfigManager's hot reload actually changing DiagnosticService's
//      live behaviour, with no restart,
//    - LoggerService staying line-safe under concurrent writers coming
//      from several real services at once,
//    - ThreadPool backpressure surfacing correctly through
//      CommunicationManager into PerformanceMonitor's counters, with the
//      broker surviving the flood,
//    - DiscoveryManager finding a service again after LifecycleManager
//      restarts it, without VehicleControlService being told directly,
//    - HealthMonitor's report and ControlService's console text agreeing
//      as LifecycleManager pauses and resumes a service,
//    - a paused service answering RequestResponseManager gracefully
//      instead of forcing the caller to time out.
// =====================================================================
#include <gtest/gtest.h>

#include <atomic>
#include <string>
#include <vector>

#include "TestUtil.hpp"
#include "core/CommunicationManager.hpp"
#include "core/DiscoveryManager.hpp"
#include "core/ServiceRegistry.hpp"
#include "data/DataGenerator.hpp"
#include "services/BatteryService.hpp"
#include "services/ControlService.hpp"
#include "services/DashboardService.hpp"
#include "services/DiagnosticService.hpp"
#include "services/EngineSensorService.hpp"
#include "services/GPSService.hpp"
#include "services/SpeedSensorService.hpp"
#include "services/VehicleControlService.hpp"
#include "support/ConfigManager.hpp"
#include "support/HealthMonitor.hpp"
#include "support/LifecycleManager.hpp"
#include "support/LoggerService.hpp"
#include "support/PerformanceMonitor.hpp"
#include "support/ThreadPool.hpp"

using namespace vsmf;
using namespace vsmftest;

namespace {

// A running broker with its own thread pool, torn down in the destructor.
// `threads`/`capacity` are exposed so the backpressure test can start a
// deliberately undersized pool.
struct IntegrationRig {
    ServiceRegistry      reg;
    DiscoveryManager     disc;
    CommunicationManager cm;
    ThreadPool           pool;
    ConfigManager        cfgMgr;
    DataGenerator        gen;
    std::string          sock;
    bool                 up = false;
    std::string          err;

    explicit IntegrationRig(std::size_t threads = 4, std::size_t capacity = 4096)
        : disc(reg), cm(reg), sock(uniquePath("integ_rig", ".sock")) {
        pool.start(threads, capacity);
        cm.setThreadPool(&pool);
        Config cfg;
        cfg.socketPath = sock;
        cfg.requestTimeoutMs = 1500;
        up = cm.start(cfg, err);
    }
    ~IntegrationRig() { cm.stop(); }
};

}  // namespace

// =====================================================================
//  1. ConfigManager <-> DiagnosticService: a hot reload changes live
//     threshold behaviour without restarting the consumer.
// =====================================================================

TEST(Integration_ConfigLive, ReloadedSpeedLimitAppliesToTheNextSampleImmediately) {
    IntegrationRig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string path = uniquePath("integ_cfg", ".json");
    ASSERT_TRUE(writeFile(path, "{\"speed_limit\":150}"));
    std::string err;
    ASSERT_TRUE(r.cfgMgr.load(path, err)) << err;

    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());
    EndpointPtr pub = r.cm.createEndpoint("SpeedProbe", err);
    ASSERT_TRUE(pub) << err;

    // 100 km/h is under the initial 150 km/h limit: no alert yet.
    ASSERT_TRUE(pub->publish(topics::kSpeed, "{\"speed\":100.0}", Priority::HIGH, err));
    sleepMs(300);
    EXPECT_EQ(0u, diag.alertCount());

    // Tighten the limit on disk and reload - the running DiagnosticService
    // is never restarted, only ConfigManager::get() changes underneath it.
    sleepMs(1100);   // mtime has 1 s resolution
    ASSERT_TRUE(writeFile(path, "{\"speed_limit\":50}"));
    ASSERT_TRUE(r.cfgMgr.reloadIfChanged(err)) << err;

    // The same 100 km/h reading now exceeds the new limit; a fresh sample
    // (not the stale one) is what proves the reload really took effect.
    ASSERT_TRUE(pub->publish(topics::kSpeed, "{\"speed\":100.0}", Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() > 0; }, 4000));
    EXPECT_NE(std::string::npos, diag.recentAlerts(1).front().text.find("50.0"));
    diag.stop();
    std::remove(path.c_str());
}

TEST(Integration_ConfigLive, BadReloadLeavesTheDiagnosticThresholdUnchanged) {
    IntegrationRig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string path = uniquePath("integ_cfg_bad", ".json");
    ASSERT_TRUE(writeFile(path, "{\"speed_limit\":50}"));
    std::string err;
    ASSERT_TRUE(r.cfgMgr.load(path, err)) << err;

    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());
    EndpointPtr pub = r.cm.createEndpoint("SpeedProbe2", err);
    ASSERT_TRUE(pub) << err;

    sleepMs(1100);
    ASSERT_TRUE(writeFile(path, "{not valid json"));    // a half-written edit
    EXPECT_FALSE(r.cfgMgr.reloadIfChanged(err));         // rejected, per EDGE_CASES.md

    // The last good configuration (limit 50) must still be the one in
    // force downstream in DiagnosticService.
    ASSERT_TRUE(pub->publish(topics::kSpeed, "{\"speed\":80.0}", Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() > 0; }, 4000));
    EXPECT_NE(std::string::npos, diag.recentAlerts(1).front().text.find("50.0"));
    diag.stop();
    std::remove(path.c_str());
}

// =====================================================================
//  2. LoggerService under concurrent real services: every line intact.
// =====================================================================

TEST(Integration_Logging, ConcurrentServicesProduceIntactSingleLineEntries) {
    IntegrationRig r;
    ASSERT_TRUE(r.up) << r.err;
    LoggerService logger;
    std::string logDir = uniqueDir("integ_logs");
    std::string err;
    ASSERT_TRUE(logger.configure(logDir, LogLevel::TRACE, 1 << 20, 8192, err)) << err;
    ASSERT_TRUE(logger.start());
    r.cm.setLogger(&logger);

    // Four real producers hammering the same LoggerService concurrently -
    // the scenario the "IsSafeFromManyThreadsAtOnce" unit test approximates
    // with synthetic threads, but here the writers are the actual
    // ServiceBase::log() call sites going through the real transport.
    SpeedSensorService  speed(r.cm, r.gen, 15);
    EngineSensorService engine(r.cm, r.gen, 15);
    BatteryService      battery(r.cm, r.gen, 15);
    GPSService          gps(r.cm, r.gen, 15);
    ASSERT_TRUE(speed.start());
    ASSERT_TRUE(engine.start());
    ASSERT_TRUE(battery.start());
    ASSERT_TRUE(gps.start());

    sleepMs(500);
    logger.flush();
    std::vector<std::string> lines = logger.tail(LogChannel::Middleware, 500);
    EXPECT_FALSE(lines.empty());
    for (std::size_t i = 0; i < lines.size(); ++i) {
        // A corrupted interleaving would show up as an embedded newline
        // (impossible for a std::string produced by getline, so this
        // instead checks the documented invariant that every entry has a
        // level tag and a source field - a torn write would drop them).
        EXPECT_NE(std::string::npos, lines[i].find('['));
    }

    gps.stop();
    battery.stop();
    engine.stop();
    speed.stop();
    logger.stop();
    removeTree(logDir);
}

// =====================================================================
//  3. ThreadPool <-> CommunicationManager <-> PerformanceMonitor:
//     backpressure under flood is visible end to end, and the broker
//     survives and keeps serving traffic afterwards.
// =====================================================================

TEST(Integration_Backpressure, FloodingAnUndersizedPoolDropsAndCountsButNeverBlocksTheBroker) {
    // A deliberately tiny pool: one worker, an eight-item queue.
    IntegrationRig r(1, 16);
    ASSERT_TRUE(r.up) << r.err;

    PerformanceMonitor perf;
    r.cm.setPerf(&perf);

    // A slow subscriber: each delivery holds the sole worker thread long
    // enough that the queue is guaranteed to fill under a fast flood.
    std::string err;
    EndpointPtr sub = r.cm.createEndpoint("SlowSubscriber", err);
    ASSERT_TRUE(sub) << err;
    std::atomic<int> handled(0);
    sub->setHandler([&handled](const Message&) {
        sleepMs(20);
        handled.fetch_add(1);
    });
    ASSERT_TRUE(sub->subscribe(topics::kSpeed, err)) << err;

    EndpointPtr pub = r.cm.createEndpoint("FloodPublisher", err);
    ASSERT_TRUE(pub) << err;
    for (int i = 0; i < 300; ++i)
        pub->publish(topics::kSpeed, "{\"speed\":1.0}", Priority::NORMAL, err);

    // The flood must not have wedged anything: the publisher call above
    // returned promptly (submit() never blocks), and the broker is still
    // answerable right now.
    EXPECT_TRUE(waitUntil([&r] { return r.pool.dropped() > 0; }, 4000))
        << "an undersized pool under a fast flood should drop, per EDGE_CASES.md #4";
    EXPECT_GT(perf.snapshot().dropped, 0u);

    // And the broker still works normally for new traffic afterwards.
    EndpointPtr pub2 = r.cm.createEndpoint("PostFloodPublisher", err);
    ASSERT_TRUE(pub2) << err;
    int before = handled.load();
    ASSERT_TRUE(pub2->publish(topics::kSpeed, "{\"speed\":2.0}", Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&handled, before] { return handled.load() > before; }, 4000));
}

// =====================================================================
//  4. DiscoveryManager <-> LifecycleManager: a service is discoverable
//     again after being restarted, with nobody telling the caller so.
// =====================================================================

TEST(Integration_Discovery, ServiceIsReDiscoverableAfterALifecycleRestart) {
    IntegrationRig r;
    ASSERT_TRUE(r.up) << r.err;
    LifecycleManager lifecycle(r.reg);
    BatteryService    battery(r.cm, r.gen, 30);
    std::string err;
    ASSERT_TRUE(lifecycle.add(&battery, err)) << err;
    ASSERT_TRUE(lifecycle.startAll(err)) << err;

    ServiceInfo before;
    ASSERT_TRUE(r.disc.discover("BatteryService", before, err)) << err;

    ASSERT_TRUE(lifecycle.restart("BatteryService", err)) << err;
    EXPECT_EQ(ServiceState::RUNNING, battery.state());

    // VehicleControlService never talks to LifecycleManager directly -
    // this is exactly the discover-fresh-every-tick pattern in
    // VehicleControlService::onTick(), reproduced here against the real
    // registry so the restart-then-rediscover seam is exercised end to
    // end rather than assumed.
    ServiceInfo after;
    EXPECT_TRUE(waitUntil([&] { return r.disc.discover("BatteryService", after, err); }, 3000)) << err;
    EXPECT_EQ(before.endpoint, after.endpoint);   // same identity, freshly usable

    VehicleControlService vc(r.cm, r.disc, r.cfgMgr, 40);
    ASSERT_TRUE(vc.start());
    EXPECT_TRUE(waitUntil([&vc] { return vc.requests() > 0; }, 6000));
    EXPECT_EQ(0u, vc.failures());
    vc.stop();
    lifecycle.stopAll();
}

// =====================================================================
//  5. HealthMonitor <-> LifecycleManager <-> ControlService: pausing and
//     resuming a service is reflected consistently everywhere at once.
// =====================================================================

TEST(Integration_Health, PauseAndResumeAgreesAcrossHealthAndConsole) {
    IntegrationRig r;
    ASSERT_TRUE(r.up) << r.err;
    LifecycleManager lifecycle(r.reg);
    DiagnosticService diag(r.cm, r.cfgMgr);
    std::string err;
    ASSERT_TRUE(lifecycle.add(&diag, err)) << err;
    ASSERT_TRUE(lifecycle.startAll(err)) << err;

    HealthMonitor health(r.cm, r.reg, r.cfgMgr);
    ASSERT_TRUE(health.start(err)) << err;
    health.checkOnce();
    EXPECT_EQ(HealthState::HEALTHY, health.overall());

    SystemContext ctx;
    ctx.cfg = &r.cfgMgr;
    ctx.registry = &r.reg;
    ctx.discovery = &r.disc;
    ctx.comm = &r.cm;
    ctx.pool = &r.pool;
    ctx.health = &health;
    ctx.lifecycle = &lifecycle;
    ctx.generator = &r.gen;
    ctx.diagnostics = &diag;
    ControlService console(r.cm, ctx);
    ASSERT_TRUE(console.start());

    // A paused service still answers PING at transport level (per
    // EDGE_CASES.md #9), so pausing must not, by itself, make the fleet
    // unhealthy - but the console's own service listing must show PAUSED.
    EXPECT_NE(std::string::npos, console.execute("pause DiagnosticService").find("pause"));
    EXPECT_EQ(ServiceState::PAUSED, diag.state());
    health.checkOnce();
    EXPECT_EQ(HealthState::HEALTHY, health.overall());
    EXPECT_NE(std::string::npos, console.execute("services").find("PAUSED"));

    ASSERT_TRUE(lifecycle.resume("DiagnosticService", err)) << err;
    EXPECT_EQ(ServiceState::RUNNING, diag.state());
    health.checkOnce();
    EXPECT_EQ(HealthState::HEALTHY, health.overall());
    EXPECT_NE(std::string::npos, console.execute("services").find("RUNNING"));

    console.stop();
    health.stop();
    lifecycle.stopAll();
}

// =====================================================================
//  6. RequestResponseManager <-> LifecycleManager: a paused service fails
//     the caller fast and cleanly instead of making it wait out a
//     timeout, and traffic recovers the moment it resumes.
// =====================================================================

TEST(Integration_RequestResponse, PausingTheCalleeFailsTheCallerFastInsteadOfHanging) {
    IntegrationRig r;
    ASSERT_TRUE(r.up) << r.err;
    LifecycleManager lifecycle(r.reg);
    BatteryService    battery(r.cm, r.gen, 30);
    std::string err;
    ASSERT_TRUE(lifecycle.add(&battery, err)) << err;
    ASSERT_TRUE(lifecycle.startAll(err)) << err;

    VehicleControlService vc(r.cm, r.disc, r.cfgMgr, 40);
    ASSERT_TRUE(vc.start());
    EXPECT_TRUE(waitUntil([&vc] { return vc.requests() > 0 && vc.failures() == 0; }, 6000));

    ASSERT_TRUE(lifecycle.pause("BatteryService", err)) << err;
    std::uint64_t failuresBeforeWait = vc.failures();
    // The whole point of the documented behaviour is that this does NOT
    // take up to VehicleControlService's request timeout to observe.
    std::uint64_t t0 = util::steadyNs();
    EXPECT_TRUE(waitUntil([&vc, failuresBeforeWait] { return vc.failures() > failuresBeforeWait; }, 2000));
    std::uint64_t elapsedMs = (util::steadyNs() - t0) / 1000000ULL;
    EXPECT_LT(elapsedMs, 2000u);

    ASSERT_TRUE(lifecycle.resume("BatteryService", err)) << err;
    std::uint64_t requestsBeforeResume = vc.requests();
    EXPECT_TRUE(waitUntil([&vc, requestsBeforeResume] {
        return vc.requests() > requestsBeforeResume && vc.status().find("NORMAL") != std::string::npos;
    }, 6000));

    vc.stop();
    lifecycle.stopAll();
}
