// =====================================================================
//  Functional tests
//
//  Where tests/test_core.cpp, tests/test_support.cpp, tests/test_services.cpp
//  and tests/test_data_config.cpp verify that individual components behave
//  correctly (unit level), this file verifies that the framework does what
//  README.md, docs/ARCHITECTURE.md and docs/EDGE_CASES.md say it does, from
//  the point of view of an integrator who only reads the documentation:
//
//    - every "out-of-range value is clamped" row in the configuration
//      table in README.md §3,
//    - the documented severity ("CRITICAL"/"WARNING"/"INFO") and 2 %
//      hysteresis behaviour of every diagnostic in docs/EDGE_CASES.md §8,
//    - the documented limp-mode decision rule for VehicleControlService,
//    - the full command surface documented in README.md §1's command
//      table, exercised through requirement-shaped scenarios rather than
//      one command at a time.
//
//  Tests here treat components as black boxes: they drive them the way a
//  real deployment would (through the socket, through the console, through
//  the JSON config file on disk) and assert on documented, user-visible
//  outcomes, not on internal state.
// =====================================================================
#include <gtest/gtest.h>

#include <string>
#include <vector>

#include "TestUtil.hpp"
#include "core/CommunicationManager.hpp"
#include "core/DiscoveryManager.hpp"
#include "core/ServiceRegistry.hpp"
#include "data/DataGenerator.hpp"
#include "services/BatteryService.hpp"
#include "services/ControlService.hpp"
#include "services/DashboardService.hpp"
#include "services/DiagnosticService.hpp"
#include "services/VehicleControlService.hpp"
#include "support/ConfigManager.hpp"
#include "support/LifecycleManager.hpp"
#include "support/LoggerService.hpp"
#include "support/PerformanceMonitor.hpp"
#include "support/ThreadPool.hpp"

using namespace vsmf;
using namespace vsmftest;

namespace {

// A minimal running broker, mirroring the Rig helper in test_services.cpp
// but kept local so this file has no compile-time dependency on it.
struct FunctionalRig {
    ServiceRegistry      reg;
    DiscoveryManager     disc;
    CommunicationManager cm;
    ThreadPool           pool;
    ConfigManager        cfgMgr;
    DataGenerator        gen;
    std::string          sock;
    bool                 up = false;
    std::string          err;

    FunctionalRig() : disc(reg), cm(reg), sock(uniquePath("func_rig", ".sock")) {
        pool.start(4, 4096);
        cm.setThreadPool(&pool);
        Config cfg;
        cfg.socketPath = sock;
        cfg.requestTimeoutMs = 1500;
        up = cm.start(cfg, err);
    }
    ~FunctionalRig() { cm.stop(); }
};

// Finds a returned warning that mentions `key`; empty string if none.
std::string findWarning(const std::vector<std::string>& warnings, const std::string& key) {
    for (std::size_t i = 0; i < warnings.size(); ++i)
        if (warnings[i].find(key) != std::string::npos) return warnings[i];
    return "";
}

}  // namespace

// =====================================================================
//  1. Configuration: every clamp documented in README.md §3 /
//     EDGE_CASES.md §3, exercised through the on-disk JSON file exactly
//     the way an integrator would edit it.
// =====================================================================

TEST(Functional_Configuration, MissingFileFallsBackToDocumentedDefaults) {
    ConfigManager cm;
    std::string err;
    EXPECT_FALSE(cm.load("/nonexistent/path/does-not-exist.json", err));
    EXPECT_FALSE(err.empty());

    // The defaults quoted in README.md §3.
    Config c = cm.get();
    EXPECT_DOUBLE_EQ(180.0, c.speedLimit);
    EXPECT_DOUBLE_EQ(100.0, c.temperatureLimit);
    EXPECT_DOUBLE_EQ(15.0, c.batteryLimit);
    EXPECT_EQ(2, c.heartbeatInterval);
    EXPECT_EQ(4u, c.threadPoolSize);
    EXPECT_EQ(LogLevel::INFO, c.logLevel);
}

TEST(Functional_Configuration, EveryDocumentedExampleOutOfRangeValueIsClamped) {
    // The four examples named verbatim in EDGE_CASES.md §3: "negative
    // speed limit, 100 000 threads, zero heartbeat interval, 900 %
    // battery limit". Each must be clamped, not rejected, and the boot
    // must still succeed with a warning naming the offending key.
    std::string path = uniquePath("func_clamp", ".json");
    ASSERT_TRUE(writeFile(path,
        "{\"speed_limit\":-50,\"thread_pool_size\":100000,"
        "\"heartbeat_interval\":0,\"battery_limit\":900}"));

    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(path, err)) << err;   // clamped, not a load failure

    Config c = cm.get();
    EXPECT_GE(c.speedLimit, 1.0);                       // clamped to the [1, 1000] floor
    EXPECT_LE(c.threadPoolSize, limits::kMaxThreads);    // clamped to the [1, 64] ceiling
    EXPECT_GE(c.heartbeatInterval, 1);                   // clamped to the [1 s, ...] floor
    EXPECT_LE(c.batteryLimit, 100.0);                    // clamped to the [0, 100] ceiling

    std::vector<std::string> warn = cm.warnings();
    EXPECT_FALSE(findWarning(warn, "speed_limit").empty());
    EXPECT_FALSE(findWarning(warn, "thread_pool_size").empty());
    EXPECT_FALSE(findWarning(warn, "heartbeat_interval").empty());
    EXPECT_FALSE(findWarning(warn, "battery_limit").empty());
    std::remove(path.c_str());
}

TEST(Functional_Configuration, EveryOptionalKeyClampsToItsDocumentedRange) {
    // The remaining optional keys named in README.md §3.
    std::string path = uniquePath("func_clamp2", ".json");
    ASSERT_TRUE(writeFile(path,
        "{\"rpm_limit\":1,\"missed_heartbeats\":0,\"request_timeout_ms\":1,"
        "\"publish_interval_ms\":1,\"metrics_interval_ms\":1,\"max_log_bytes\":1,"
        "\"queue_capacity\":1}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(path, err)) << err;

    Config c = cm.get();
    EXPECT_GE(c.rpmLimit, 100.0);
    EXPECT_GE(c.missedHeartbeats, 1);
    EXPECT_GE(c.requestTimeoutMs, 10);
    EXPECT_GE(c.publishIntervalMs, 10);
    EXPECT_GE(c.metricsIntervalMs, 100);
    EXPECT_GE(c.maxLogBytes, 4096L);
    EXPECT_GE(c.queueCapacity, 16u);
    EXPECT_FALSE(cm.warnings().empty());
    std::remove(path.c_str());
}

TEST(Functional_Configuration, WrongTypedValuesAreIgnoredInFavourOfTheDefault) {
    std::string path = uniquePath("func_wrongtype", ".json");
    ASSERT_TRUE(writeFile(path,
        "{\"speed_limit\":\"fast\",\"battery_limit\":true,\"log_level\":42}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(path, err)) << err;

    Config c = cm.get();
    EXPECT_DOUBLE_EQ(180.0, c.speedLimit);      // unchanged default
    EXPECT_DOUBLE_EQ(15.0, c.batteryLimit);     // unchanged default
    EXPECT_EQ(LogLevel::INFO, c.logLevel);      // unchanged default
    EXPECT_FALSE(cm.warnings().empty());
    std::remove(path.c_str());
}

TEST(Functional_Configuration, UnrecognisedLogLevelKeepsInfoAsDocumented) {
    std::string path = uniquePath("func_loglevel", ".json");
    ASSERT_TRUE(writeFile(path, "{\"log_level\":\"VERY_LOUD\"}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(path, err));
    EXPECT_EQ(LogLevel::INFO, cm.get().logLevel);
    EXPECT_FALSE(findWarning(cm.warnings(), "log_level").empty());
    std::remove(path.c_str());
}

TEST(Functional_Configuration, RemovingAKeyOnReloadRevertsToDefaultRatherThanSticking) {
    // "a removed key reverts instead of sticking" - src/support/ConfigManager.cpp.
    std::string path = uniquePath("func_revert", ".json");
    ASSERT_TRUE(writeFile(path, "{\"speed_limit\":42}"));
    ConfigManager cm;
    std::string err;
    ASSERT_TRUE(cm.load(path, err));
    EXPECT_DOUBLE_EQ(42.0, cm.get().speedLimit);

    sleepMs(1100);   // mtime has 1 s resolution
    ASSERT_TRUE(writeFile(path, "{\"battery_limit\":20}"));   // speed_limit gone
    ASSERT_TRUE(cm.reloadIfChanged(err)) << err;
    EXPECT_DOUBLE_EQ(180.0, cm.get().speedLimit);    // back to the documented default
    EXPECT_DOUBLE_EQ(20.0, cm.get().batteryLimit);
    std::remove(path.c_str());
}

// =====================================================================
//  2. Diagnostics: every fault type in EDGE_CASES.md §8, its documented
//     severity, and the 2 % hysteresis band, driven over the real socket.
// =====================================================================

TEST(Functional_Diagnostics, OverTemperatureIsCriticalAndClearsWithHysteresis) {
    FunctionalRig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string path = uniquePath("func_temp", ".json");
    ASSERT_TRUE(writeFile(path, "{\"temperature_limit\":100}"));
    std::string err;
    ASSERT_TRUE(r.cfgMgr.load(path, err)) << err;

    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());
    EndpointPtr pub = r.cm.createEndpoint("FakeEngine", err);
    ASSERT_TRUE(pub) << err;

    ASSERT_TRUE(pub->publish(topics::kEngine, "{\"temperature\":120.0,\"rpm\":2000}",
                             Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() > 0; }, 4000));
    Alert a = diag.recentAlerts(1).front();
    EXPECT_EQ("CRITICAL", a.severity);
    EXPECT_NE(std::string::npos, a.text.find("over-temperature"));

    // Just inside the limit does not clear it (2 % hysteresis, per spec).
    ASSERT_TRUE(pub->publish(topics::kEngine, "{\"temperature\":99.0,\"rpm\":2000}", Priority::HIGH, err));
    sleepMs(250);
    EXPECT_EQ(1u, diag.alertCount());

    // Below limit * (1 - 0.02) really does clear it.
    ASSERT_TRUE(pub->publish(topics::kEngine, "{\"temperature\":95.0,\"rpm\":2000}", Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() >= 2; }, 4000));
    EXPECT_EQ("INFO", diag.recentAlerts(1).front().severity);
    diag.stop();
    std::remove(path.c_str());
}

TEST(Functional_Diagnostics, OverRevIsWarningSeverityNotCritical) {
    FunctionalRig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string path = uniquePath("func_rpm", ".json");
    ASSERT_TRUE(writeFile(path, "{\"rpm_limit\":6000}"));
    std::string err;
    ASSERT_TRUE(r.cfgMgr.load(path, err)) << err;

    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());
    EndpointPtr pub = r.cm.createEndpoint("FakeEngine2", err);
    ASSERT_TRUE(pub) << err;

    ASSERT_TRUE(pub->publish(topics::kEngine, "{\"temperature\":70,\"rpm\":6800}", Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() > 0; }, 4000));
    Alert a = diag.recentAlerts(1).front();
    EXPECT_EQ("WARNING", a.severity);
    EXPECT_NE(std::string::npos, a.text.find("over-rev"));
    diag.stop();
    std::remove(path.c_str());
}

TEST(Functional_Diagnostics, LowBatteryIsCriticalAndRecoveryIsReported) {
    FunctionalRig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string path = uniquePath("func_batt", ".json");
    ASSERT_TRUE(writeFile(path, "{\"battery_limit\":15}"));
    std::string err;
    ASSERT_TRUE(r.cfgMgr.load(path, err)) << err;

    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());
    EndpointPtr pub = r.cm.createEndpoint("FakeBattery", err);
    ASSERT_TRUE(pub) << err;

    ASSERT_TRUE(pub->publish(topics::kBattery, "{\"battery\":10.0}", Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() > 0; }, 4000));
    EXPECT_EQ("CRITICAL", diag.recentAlerts(1).front().severity);

    // Recovery well above limit * (1 + 0.02).
    ASSERT_TRUE(pub->publish(topics::kBattery, "{\"battery\":50.0}", Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() >= 2; }, 4000));
    Alert recov = diag.recentAlerts(1).front();
    EXPECT_EQ("INFO", recov.severity);
    EXPECT_NE(std::string::npos, recov.text.find("recovered"));
    diag.stop();
    std::remove(path.c_str());
}

TEST(Functional_Diagnostics, GpsFixLossAndRestorationAreReported) {
    FunctionalRig r;
    ASSERT_TRUE(r.up) << r.err;
    DiagnosticService diag(r.cm, r.cfgMgr);
    ASSERT_TRUE(diag.start());
    std::string err;
    EndpointPtr pub = r.cm.createEndpoint("FakeGps", err);
    ASSERT_TRUE(pub) << err;

    // Fewer than 4 satellites is documented as "no fix".
    ASSERT_TRUE(pub->publish(topics::kGps, "{\"satellites\":2,\"lat\":13.0,\"lon\":80.0}",
                             Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() > 0; }, 4000));
    EXPECT_NE(std::string::npos, diag.recentAlerts(1).front().text.find("lost"));

    ASSERT_TRUE(pub->publish(topics::kGps, "{\"satellites\":9,\"lat\":13.0,\"lon\":80.0}",
                             Priority::HIGH, err));
    EXPECT_TRUE(waitUntil([&diag] { return diag.alertCount() >= 2; }, 4000));
    EXPECT_NE(std::string::npos, diag.recentAlerts(1).front().text.find("restored"));
    diag.stop();
}

// =====================================================================
//  3. VehicleControlService: the documented limp-mode decision rule.
// =====================================================================

TEST(Functional_VehicleControl, EngagesLimpModeOnlyWhenBatteryIsBelowLimit) {
    FunctionalRig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string path = uniquePath("func_limp", ".json");
    ASSERT_TRUE(writeFile(path, "{\"battery_limit\":15}"));
    std::string err;
    ASSERT_TRUE(r.cfgMgr.load(path, err)) << err;

    // Fast-forward the model directly rather than waiting on real time:
    // only SpeedSensorService normally advances DataGenerator::step(), so
    // driving it here simulates a long, faulted drive cycle in a single
    // test tick. 60 x 5 s steps under the battery fault reliably takes
    // the pack from 100 % to well under the 15 % limit.
    r.gen.injectFault(false, /*batteryFault=*/true);
    for (int i = 0; i < 60; ++i) r.gen.step(5.0);
    ASSERT_LT(r.gen.current().batteryPct, 15.0);

    BatteryService battery(r.cm, r.gen, 30);
    ASSERT_TRUE(battery.start());

    VehicleControlService vc(r.cm, r.disc, r.cfgMgr, 40);
    ASSERT_TRUE(vc.start());

    // A fault injection drains toward empty; the framework must report
    // limp mode via its own request/response protocol - not an internal
    // getter - exactly as VehicleControlService::onMessage() answers a
    // REQUEST with {"limp_mode": true|false}.
    EndpointPtr caller = r.cm.createEndpoint("LimpModeObserver", err);
    ASSERT_TRUE(caller) << err;

    bool sawLimp = waitUntil([&] {
        Message resp;
        std::string rerr;
        if (!caller->request(vc.name(), topics::kControl, "{}", 1000, resp, rerr))
            return false;
        return resp.payload.find("\"limp_mode\":true") != std::string::npos;
    }, 8000);
    EXPECT_TRUE(sawLimp) << "battery below the configured limit must engage limp mode";
    EXPECT_NE(std::string::npos, vc.status().find("LIMP"));

    battery.stop();
    vc.stop();
    std::remove(path.c_str());
}

TEST(Functional_VehicleControl, HealthyBatteryNeverEngagesLimpMode) {
    FunctionalRig r;
    ASSERT_TRUE(r.up) << r.err;
    std::string path = uniquePath("func_nolimp", ".json");
    ASSERT_TRUE(writeFile(path, "{\"battery_limit\":15}"));
    std::string err;
    ASSERT_TRUE(r.cfgMgr.load(path, err)) << err;

    BatteryService battery(r.cm, r.gen, 30);   // healthy, un-faulted pack
    ASSERT_TRUE(battery.start());
    VehicleControlService vc(r.cm, r.disc, r.cfgMgr, 40);
    ASSERT_TRUE(vc.start());

    EXPECT_TRUE(waitUntil([&vc] { return vc.requests() > 0; }, 6000));
    sleepMs(400);
    EXPECT_NE(std::string::npos, vc.status().find("NORMAL"));

    battery.stop();
    vc.stop();
    std::remove(path.c_str());
}

// =====================================================================
//  4. The console command surface, driven as documented scenarios
//     rather than one command per assertion (see README.md §1 table).
// =====================================================================

namespace {

// The full SystemContext a deployed console runs against, built the same
// way runMiddleware() in src/main.cpp assembles it.
struct FunctionalConsole {
    LoggerService         logger;
    PerformanceMonitor    perf;
    FunctionalRig         rig;
    LifecycleManager      lifecycle;
    DashboardService      dashboard;
    DiagnosticService     diagnostics;
    VehicleControlService control;
    BatteryService        battery;
    HealthMonitor         health;
    std::atomic<bool>     shutdownFlag;
    SystemContext         ctx;
    std::string           logDir;
    std::string           cfgPath;

    FunctionalConsole()
        : lifecycle(rig.reg),
          dashboard(rig.cm),
          diagnostics(rig.cm, rig.cfgMgr),
          control(rig.cm, rig.disc, rig.cfgMgr, 100),
          battery(rig.cm, rig.gen, 50),
          health(rig.cm, rig.reg, rig.cfgMgr),
          shutdownFlag(false),
          logDir(uniqueDir("func_console_logs")),
          cfgPath(uniquePath("func_console_cfg", ".json")) {
        writeFile(cfgPath, "{\"speed_limit\":180,\"battery_limit\":15}");
        std::string err;
        rig.cfgMgr.load(cfgPath, err);
        logger.configure(logDir, LogLevel::TRACE, 1 << 20, 4096, err);
        logger.start();

        ctx.cfg = &rig.cfgMgr;
        ctx.registry = &rig.reg;
        ctx.discovery = &rig.disc;
        ctx.comm = &rig.cm;
        ctx.pool = &rig.pool;
        ctx.logger = &logger;
        ctx.perf = &perf;
        ctx.health = &health;
        ctx.lifecycle = &lifecycle;
        ctx.generator = &rig.gen;
        ctx.dashboard = &dashboard;
        ctx.diagnostics = &diagnostics;
        ctx.control = &control;
        ctx.shutdownFlag = &shutdownFlag;
    }
    ~FunctionalConsole() {
        lifecycle.stopAll();
        health.stop();
        logger.stop();
        removeTree(logDir);
        std::remove(cfgPath.c_str());
    }
};

}  // namespace

TEST(Functional_Console, ConfigThenEditThenReloadShowsTheNewValue) {
    // Documented workflow: `config` shows the live configuration, an
    // operator edits the file on disk, `reload` re-reads it, `config`
    // reflects the change - all through the console, as a field
    // technician would actually use it.
    FunctionalConsole c;
    ASSERT_TRUE(c.rig.up) << c.rig.err;
    ControlService console(c.rig.cm, c.ctx);
    std::string err;
    ASSERT_TRUE(c.lifecycle.add(&console, err)) << err;
    ASSERT_TRUE(console.start());

    std::string before = console.execute("config");
    EXPECT_NE(std::string::npos, before.find("speed_limit=180"));

    sleepMs(1100);
    ASSERT_TRUE(writeFile(c.cfgPath, "{\"speed_limit\":222,\"battery_limit\":15}"));
    std::string reloadResult = console.execute("reload");
    EXPECT_FALSE(reloadResult.empty());

    std::string after = console.execute("config");
    EXPECT_NE(std::string::npos, after.find("speed_limit=222"));
}

TEST(Functional_Console, PublishSpeedThenDiagnosticsShowsTheResultingAlert) {
    // Documented workflow: an operator injects a speed with
    // `publish_speed`, the DiagnosticService raises an alert per the
    // configured limit, and `diagnostics` reports it back.
    FunctionalConsole c;
    ASSERT_TRUE(c.rig.up) << c.rig.err;
    std::string err;
    ASSERT_TRUE(c.lifecycle.add(&c.diagnostics, err)) << err;
    ControlService console(c.rig.cm, c.ctx);
    ASSERT_TRUE(c.lifecycle.add(&console, err)) << err;
    ASSERT_TRUE(c.lifecycle.startAll(err)) << err;

    // 220 km/h is above the 180 km/h limit configured for FunctionalConsole
    // but still inside DataGenerator::kMaxSpeedKph (260), so the operator
    // override is accepted rather than rejected as physically implausible.
    std::string setResult = console.execute("publish_speed 220");
    EXPECT_EQ(std::string::npos, setResult.find("rejected"));
    EXPECT_TRUE(waitUntil(
        [&console] { return console.execute("diagnostics").find("over-speed") != std::string::npos; },
        4000));
}

TEST(Functional_Console, BatteryQueryFailsGracefullyWhenTheServiceIsNotRunning) {
    // Documented: an undeliverable REQUEST gets an immediate error rather
    // than the caller hanging out its timeout - verified end-to-end
    // through the console's own text response, not the transport layer.
    FunctionalConsole c;
    ASSERT_TRUE(c.rig.up) << c.rig.err;
    // Deliberately never start BatteryService, so BatteryService cannot
    // be discovered.
    ControlService console(c.rig.cm, c.ctx);
    std::string err;
    ASSERT_TRUE(c.lifecycle.add(&console, err)) << err;
    ASSERT_TRUE(console.start());

    std::string result = console.execute("battery");
    EXPECT_FALSE(result.empty());
    EXPECT_NE(std::string::npos, result.find("BatteryService"));
    EXPECT_EQ(std::string::npos, result.find("responded"));   // no fabricated reading
}

TEST(Functional_Console, LifecycleVerbsMatchTheDocumentedStateMachine) {
    // README.md §1: start/stop/pause/resume/restart <name>.
    FunctionalConsole c;
    ASSERT_TRUE(c.rig.up) << c.rig.err;
    ControlService console(c.rig.cm, c.ctx);
    std::string err;
    ASSERT_TRUE(c.lifecycle.add(&c.diagnostics, err)) << err;
    ASSERT_TRUE(c.lifecycle.add(&console, err)) << err;
    ASSERT_TRUE(c.lifecycle.startAll(err)) << err;

    EXPECT_EQ(ServiceState::RUNNING, c.diagnostics.state());
    console.execute("pause DiagnosticService");
    EXPECT_EQ(ServiceState::PAUSED, c.diagnostics.state());
    console.execute("stop DiagnosticService");
    EXPECT_EQ(ServiceState::STOPPED, c.diagnostics.state());
    console.execute("start DiagnosticService");
    EXPECT_EQ(ServiceState::RUNNING, c.diagnostics.state());
    console.execute("restart DiagnosticService");
    EXPECT_EQ(ServiceState::RUNNING, c.diagnostics.state());
}
